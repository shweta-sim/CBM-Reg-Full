(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"step3_selectproduct_atlas_", frames: [[0,0,1333,296],[1350,837,144,84],[1492,477,272,157],[1214,477,276,160],[1357,716,133,63],[624,678,203,118],[0,846,136,80],[872,532,122,72],[1766,477,264,153],[0,786,288,58],[2003,170,31,18],[2003,190,31,18],[2003,210,31,18],[1766,632,237,139],[620,532,250,144],[1020,830,175,71],[253,890,97,47],[2003,81,25,31],[352,891,97,47],[2003,114,25,31],[451,891,97,47],[354,511,264,153],[290,799,154,89],[872,606,118,70],[1642,706,107,64],[1918,872,97,58],[928,838,86,52],[1732,875,75,46],[903,678,65,40],[627,893,54,34],[2003,0,43,27],[2003,147,33,21],[2019,268,22,15],[2030,81,11,9],[0,652,211,120],[420,678,202,119],[829,724,189,112],[1020,724,176,104],[1816,773,164,97],[446,799,151,90],[1496,837,138,82],[1357,639,126,75],[138,846,113,68],[1816,872,100,60],[1357,781,87,53],[550,893,75,46],[1982,773,62,38],[735,893,49,31],[2003,55,36,24],[2019,250,24,16],[2030,92,11,9],[213,666,205,118],[1642,773,172,100],[624,798,161,93],[1198,829,150,87],[787,838,139,81],[1915,369,128,74],[1642,636,116,68],[1214,412,105,62],[1636,875,94,56],[928,892,83,49],[829,678,72,43],[1982,813,61,37],[683,893,50,31],[2003,29,39,24],[2003,230,28,18],[2019,285,17,12],[2030,103,6,6],[1915,257,102,110],[998,524,200,198],[1214,298,92,112],[1492,636,148,199],[354,298,374,211],[998,298,214,224],[0,298,352,352],[730,298,266,232],[1915,0,86,255],[1200,639,155,188],[1335,0,578,475]]}
];


// symbols:



(lib.CachedBmp_140 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_139 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_138 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_137 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_136 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_135 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_134 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_133 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_132 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_131 = function() {
	this.initialize(img.CachedBmp_131);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2096,1335);


(lib.CachedBmp_130 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.imgbggrid = function() {
	this.initialize(img.imgbggrid);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4132,2198);


(lib.imgcashback = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.imgfibo = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.imgfunds = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.imgjames = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.imglicensespack = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.imgtradingaccount = function() {
	this.initialize(ss["step3_selectproduct_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.tradingaccount = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgtradingaccount();
	this.instance.setTransform(0,0,0.504,0.504);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,291.3,239.4);


(lib.texttitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_140();
	this.instance.setTransform(10,-3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,-3,666.5,148);


(lib.textrebates = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_139();
	this.instance.setTransform(4.6,73.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4.6,73.6,72,42);


(lib.textmonthlycashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_138();
	this.instance.setTransform(-27.25,55.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.2,55.3,136,78.50000000000001);


(lib.textlp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_137();
	this.instance.setTransform(29.9,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(29.9,0,138,80);


(lib.textjames = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_136();
	this.instance.setTransform(-24,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24,0,66.5,31.5);


(lib.textcommissions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_135();
	this.instance.setTransform(-10.2,65.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,65.1,101.5,59);


(lib.textbroker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_134();
	this.instance.setTransform(6.65,74.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.7,74.7,68,40);


(lib.textbanks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_133();
	this.instance.setTransform(68.3,22,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.3,22,61.000000000000014,36);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,374,211);


(lib.mccashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgcashback();
	this.instance.setTransform(0,0,0.6694,0.6696);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143.3,150);


(lib.managedfund = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_132();
	this.instance.setTransform(13.95,-2.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(14,-2.3,132,76.5);


(lib.logoicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(89,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89,88,200,198);


(lib.liquidityproviders = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(109,131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109,131,92,112);


(lib.licencsespack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imglicensespack();
	this.instance.setTransform(58.05,32.4,0.512,0.512);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(58.1,32.4,79.30000000000001,96.29999999999998);


(lib.james = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.imgjames();
	this.instance.setTransform(-3,15.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,15.3,86,255);


(lib.grid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgbggrid();
	this.instance.setTransform(0,0,0.4647,0.4646);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,1021.3);


(lib.funds = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_130();
	this.instance.setTransform(-1.1,-28.7,0.4617,0.4617);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.imgfunds();
	this.instance_1.setTransform(0,0,0.45,0.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.1,-28.7,133,133.1);


(lib.fibo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgfibo();
	this.instance.setTransform(0,0,0.45,0.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,158.4,158.4);


(lib.dotpink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_129();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.dotorange = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_128();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.dotblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_127();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.cbmgeneration = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_126();
	this.instance.setTransform(-9.65,65.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.6,65.4,118.5,69.5);


(lib.buycashbacklicenses = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_125();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,125,72);


(lib.btnreplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay.svg
	this.instance = new lib.CachedBmp_119();
	this.instance.setTransform(132.55,72,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_118();
	this.instance_1.setTransform(81.1,68.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_123();
	this.instance_2.setTransform(132.55,72,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_120();
	this.instance_3.setTransform(81.1,68.05,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_122();
	this.instance_4.setTransform(81.1,68.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_124();
	this.instance_5.setTransform(68.5,62.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4},{t:this.instance_2}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.5,62.7,87.5,35.5);


(lib.broker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-12,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-17,148,199);


(lib.banks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(38,37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,37,102,110);


(lib.infographic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.textmonthlycashback("synched",0);
	this.instance.setTransform(589,570.75,0.9025,0.9025,0,0,0,40.6,94.5);

	this.instance_1 = new lib.Symbol1("synched",0);
	this.instance_1.setTransform(923,803.5,0.9025,0.9025,0,0,0,187.1,104);

	this.instance_2 = new lib.dotpink("synched",0);
	this.instance_2.setTransform(910.35,692.75,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_3 = new lib.dotpink("synched",0);
	this.instance_3.setTransform(1170.25,650.55,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_4 = new lib.fibo("synched",0);
	this.instance_4.setTransform(1302.3,825.95,0.9025,0.9025,0,0,0,79.2,79.2);

	this.instance_5 = new lib.mccashback("synched",0);
	this.instance_5.setTransform(1423.05,702.05,0.731,0.731,0,0,0,71.5,75);

	this.instance_6 = new lib.dotorange("synched",0);
	this.instance_6.setTransform(1226.95,617.45,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_7 = new lib.textrebates("synched",0);
	this.instance_7.setTransform(1381.9,484,0.9025,0.9025,0,0,0,40.7,94.5);

	this.instance_8 = new lib.textcommissions("synched",0);
	this.instance_8.setTransform(1518.85,247.5,0.9025,0.9025,0,0,0,40.6,94.7);

	this.instance_9 = new lib.textbanks("synched",0);
	this.instance_9.setTransform(1667.55,254.45,0.9025,0.9025,0,0,0,98.9,39.9);

	this.instance_10 = new lib.banks("synched",0);
	this.instance_10.setTransform(1630.3,207.35,0.9025,0.9025,0,0,0,94.5,91.5);

	this.instance_11 = new lib.textlp("synched",0);
	this.instance_11.setTransform(1500.65,93.8,0.9025,0.9025,0,0,0,98.9,39.9);

	this.instance_12 = new lib.liquidityproviders("synched",0);
	this.instance_12.setTransform(1527.35,138.8,0.9025,0.9025,0,0,0,154.5,187.6);

	this.instance_13 = new lib.managedfund("synched",0);
	this.instance_13.setTransform(1247.55,164.15,0.9025,0.9025,0,0,0,62.6,36.1);

	this.instance_14 = new lib.dotorange("synched",0);
	this.instance_14.setTransform(1171.65,131,0.6552,0.6552,0,0,0,7.7,4.5);

	this.instance_15 = new lib.textbroker("synched",0);
	this.instance_15.setTransform(1333.4,382.65,0.9025,0.9025,0,0,0,40.7,94.7);

	this.instance_16 = new lib.broker("synched",0);
	this.instance_16.setTransform(1411.95,283.15,0.9025,0.9025,0,0,0,61.9,82.8);

	this.instance_17 = new lib.funds("synched",0);
	this.instance_17.setTransform(1091.65,97.25,1.083,1.083,0,0,0,60,52.2);

	this.instance_18 = new lib.dotpink("synched",0);
	this.instance_18.setTransform(993.35,328.35,0.4193,0.4193,0,0,0,7.4,4.4);

	this.instance_19 = new lib.tradingaccount("synched",0);
	this.instance_19.setTransform(1064.6,298.6,0.9025,0.9025,0,0,0,145.7,119.7);

	this.instance_20 = new lib.dotblue("synched",0);
	this.instance_20.setTransform(874.2,429.75,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_21 = new lib.buycashbacklicenses("synched",0);
	this.instance_21.setTransform(743.5,629.45,0.9025,0.9025,0,0,0,62.6,36.1);

	this.instance_22 = new lib.licencsespack("synched",0);
	this.instance_22.setTransform(865.05,654,0.9025,0.9025,0,0,0,98.3,81.5);

	this.instance_23 = new lib.dotpink("synched",0);
	this.instance_23.setTransform(1001.95,552.2,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_24 = new lib.dotpink("synched",0);
	this.instance_24.setTransform(775.85,551.75,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_25 = new lib.cbmgeneration("synched",0);
	this.instance_25.setTransform(968.8,471.4,0.9025,0.9025,0,0,0,49.6,100);

	this.instance_26 = new lib.logoicon("synched",0);
	this.instance_26.setTransform(1121.6,560.35,0.9001,0.8999,0,0,0,190.3,182.4);

	this.instance_27 = new lib.dotpink("synched",0);
	this.instance_27.setTransform(872.05,496.5,0.6552,0.6552,0,0,0,7.7,4.5);

	this.instance_28 = new lib.textjames("synched",0);
	this.instance_28.setTransform(769.85,383.15,0.9025,0.9025,0,0,0,17.4,15.7);

	this.instance_29 = new lib.james();
	this.instance_29.setTransform(826.45,441.85,0.9025,0.9025,0,0,0,44,125);

	this.instance_30 = new lib.grid("synched",0);
	this.instance_30.setTransform(953.1,507,0.9927,0.9927,0,0,0,960.1,510.7);

	this.instance_31 = new lib.CachedBmp_131();
	this.instance_31.setTransform(493.75,130.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.infographic, new cjs.Rectangle(0,0,1906,1013.9), null);


// stage content:
(lib.step3selectproduct = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_88 = function() {
		this.stop();
		
		this.replayBtn.addEventListener("click", fl_ClickToGoToAndPlayAtFrame1.bind(this));
		function fl_ClickToGoToAndPlayAtFrame1()
		{
			this.gotoAndPlay(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(88).call(this.frame_88).wait(1));

	// Btn_Replay
	this.replayBtn = new lib.btnreplay();
	this.replayBtn.name = "replayBtn";
	this.replayBtn.setTransform(1627,72.75,1,1,0,0,0,112,80.3);
	this.replayBtn.alpha = 0;
	this.replayBtn._off = true;
	new cjs.ButtonHelper(this.replayBtn, 0, 1, 2, false, new lib.btnreplay(), 3);

	this.timeline.addTween(cjs.Tween.get(this.replayBtn).wait(73).to({_off:false},0).to({x:1637,alpha:1},15).wait(1));

	// Text_Buy_Cashback
	this.instance = new lib.buycashbacklicenses("synched",0);
	this.instance.setTransform(652.65,701.05,0.9025,0.9025,0,0,0,62.5,36.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({regX:62.6,x:655.45,y:698.35,alpha:1},15).wait(60));

	// Img_Licence_Pack
	this.instance_1 = new lib.licencsespack("synched",0);
	this.instance_1.setTransform(777,728.3,0.9025,0.9025,0,0,0,98.3,81.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({y:717.6,alpha:1},15).to({y:722.9},6).wait(54));

	// Line_Pink_Dotted
	this.instance_2 = new lib.CachedBmp_71();
	this.instance_2.setTransform(911.95,619.15,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_72();
	this.instance_3.setTransform(906.4,619.35,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_73();
	this.instance_4.setTransform(900.85,619.35,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_74();
	this.instance_5.setTransform(895.3,619.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_75();
	this.instance_6.setTransform(889.75,619.35,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_76();
	this.instance_7.setTransform(884.2,619.35,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_77();
	this.instance_8.setTransform(878.65,619.35,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_78();
	this.instance_9.setTransform(873.1,619.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_79();
	this.instance_10.setTransform(867.6,619.35,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_80();
	this.instance_11.setTransform(862.05,619.35,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_81();
	this.instance_12.setTransform(856.5,619.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_82();
	this.instance_13.setTransform(850.95,619.35,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_83();
	this.instance_14.setTransform(845.4,619.35,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_84();
	this.instance_15.setTransform(839.85,619.35,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_85();
	this.instance_16.setTransform(834.3,619.35,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_86();
	this.instance_17.setTransform(828.75,619.15,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_87();
	this.instance_18.setTransform(812.65,619.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},19).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).wait(54));

	// Dot_Pink
	this.instance_19 = new lib.dotpink("synched",0);
	this.instance_19.setTransform(913.95,621.1,0.2707,0.2707,0,0,0,7.5,4.5);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(4).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:914,y:621.15},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:913.9,y:621.1},5).wait(70));

	// Line_Pink
	this.instance_20 = new lib.CachedBmp_88();
	this.instance_20.setTransform(630.35,651.1,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_89();
	this.instance_21.setTransform(630.35,651.1,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_90();
	this.instance_22.setTransform(630.35,651.1,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_91();
	this.instance_23.setTransform(630.35,651.1,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_92();
	this.instance_24.setTransform(630.35,651.1,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_93();
	this.instance_25.setTransform(630.35,651.1,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_94();
	this.instance_26.setTransform(630.35,651.1,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_95();
	this.instance_27.setTransform(630.35,651.1,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_96();
	this.instance_28.setTransform(630.35,651.1,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_97();
	this.instance_29.setTransform(630.35,651.1,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_98();
	this.instance_30.setTransform(630.35,651.1,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_99();
	this.instance_31.setTransform(630.35,651.1,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_100();
	this.instance_32.setTransform(630.35,651.1,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_101();
	this.instance_33.setTransform(630.35,651.1,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_102();
	this.instance_34.setTransform(630.35,651.1,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_103();
	this.instance_35.setTransform(630.35,651.1,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_104();
	this.instance_36.setTransform(630.3,651.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},29).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).wait(44));

	// Line_Pink
	this.instance_37 = new lib.CachedBmp_105();
	this.instance_37.setTransform(683.65,619.15,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_106();
	this.instance_38.setTransform(678.3,619.15,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_107();
	this.instance_39.setTransform(673,619.15,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_108();
	this.instance_40.setTransform(667.65,619.15,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_109();
	this.instance_41.setTransform(662.3,619.15,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_110();
	this.instance_42.setTransform(657,619.15,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_111();
	this.instance_43.setTransform(651.65,619.15,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_112();
	this.instance_44.setTransform(646.3,619.15,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_113();
	this.instance_45.setTransform(640.95,619.15,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_114();
	this.instance_46.setTransform(635.65,619.15,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_115();
	this.instance_47.setTransform(630.3,619.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_37}]},19).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).wait(60));

	// Dot_Pink
	this.instance_48 = new lib.dotpink("synched",0);
	this.instance_48.setTransform(687.8,620.6,0.2707,0.2707,0,0,0,7.4,4);
	this.instance_48._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(4).to({_off:false},0).to({regX:7.6,regY:4.3,scaleX:0.9151,scaleY:0.9151,y:620.65},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552},5).wait(70));

	// Text_CBM_Registration
	this.instance_49 = new lib.cbmgeneration("synched",0);
	this.instance_49.setTransform(880.75,540.3,0.9025,0.9025,0,0,0,49.6,100);

	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(89));

	// Logo_CBM
	this.instance_50 = new lib.logoicon("synched",0);
	this.instance_50.setTransform(1033.55,629.25,0.9001,0.8999,0,0,0,190.3,182.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_50).wait(89));

	// Pink_Line
	this.instance_51 = new lib.CachedBmp_116();
	this.instance_51.setTransform(911.5,490.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(89));

	// Pink_Line
	this.instance_52 = new lib.CachedBmp_117();
	this.instance_52.setTransform(782.45,490.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_52).wait(89));

	// Dot_Pink
	this.instance_53 = new lib.dotpink("synched",0);
	this.instance_53.setTransform(784,565.4,0.6552,0.6552,0,0,0,7.7,4.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(89));

	// txt_james
	this.instance_54 = new lib.textjames("synched",0);
	this.instance_54.setTransform(674.6,450.35,0.9025,0.9025,0,0,0,9.4,13.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_54).wait(89));

	// james
	this.instance_55 = new lib.james();
	this.instance_55.setTransform(738.4,510.75,0.9025,0.9025,0,0,0,44,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_55).wait(89));

	// Bg Grid
	this.instance_56 = new lib.grid("synched",0);
	this.instance_56.setTransform(865.05,575.9,0.9927,0.9927,0,0,0,960.1,510.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_56).wait(89));

	// txt-title
	this.instance_57 = new lib.texttitle("synched",0);
	this.instance_57.setTransform(362.2,112.3,0.9025,0.9025,0,0,0,344.8,69.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_57).wait(89));

	// Infographic
	this.instance_58 = new lib.infographic();
	this.instance_58.setTransform(864.95,575.8,1,1,0,0,0,953,506.9);
	this.instance_58.alpha = 0.0703;

	this.timeline.addTween(cjs.Tween.get(this.instance_58).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(872,586.9,946,495.9);
// library properties:
lib.properties = {
	id: 'EA5571A2295DF7458D9934B992E3E739',
	width: 1920,
	height: 1080,
	fps: 90,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"step3-selectproduct/images/CachedBmp_131.png", id:"CachedBmp_131"},
		{src:"step3-selectproduct/images/imgbggrid.png", id:"imgbggrid"},
		{src:"step3-selectproduct/images/step3_selectproduct_atlas_.png", id:"step3_selectproduct_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EA5571A2295DF7458D9934B992E3E739'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;