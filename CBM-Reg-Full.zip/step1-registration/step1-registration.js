(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"step1_registration_atlas_", frames: [[0,530,1333,296],[0,0,1282,528],[754,1013,736,283],[0,1013,752,283],[0,1413,2041,102],[0,1517,1981,102],[0,1298,1846,113],[0,828,1971,183],[0,1621,1973,102],[1335,477,587,339],[1284,0,578,475]]},
		{name:"step1_registration_atlas_2", frames: [[1159,864,557,283],[0,1459,557,283],[0,864,584,283],[586,864,571,283],[530,1149,697,228],[1080,1451,828,181],[1114,313,828,181],[0,1848,1481,102],[0,760,1661,102],[0,656,1741,102],[0,0,564,329],[566,0,546,318],[0,1149,528,308],[566,320,510,297],[0,1744,1541,102],[1229,1149,517,300],[0,331,555,323],[1114,0,536,311],[559,1379,519,301],[1543,1634,502,291]]},
		{name:"step1_registration_atlas_3", frames: [[1470,513,547,228],[468,562,547,228],[908,1006,490,228],[1400,1006,479,228],[1470,283,568,228],[481,1296,478,228],[0,1296,479,228],[0,1236,1906,58],[0,1610,1846,58],[420,1914,1618,58],[0,1550,1847,58],[502,0,491,287],[995,283,473,276],[0,566,455,265],[0,833,436,255],[0,1670,418,244],[1253,1670,400,234],[0,0,500,291],[1481,0,483,281],[0,293,466,271],[1371,743,449,261],[961,1296,432,252],[420,1670,415,242],[995,0,484,281],[502,289,467,271],[457,792,449,261],[1395,1296,432,251],[837,1670,414,241],[1017,561,352,352]]},
		{name:"step1_registration_atlas_4", frames: [[0,1745,368,213],[0,1314,373,216],[1717,983,275,160],[1180,767,520,118],[399,572,433,173],[0,0,539,173],[1616,1469,361,118],[1554,0,445,173],[541,0,512,175],[1055,0,497,175],[384,956,357,207],[1078,887,321,188],[1180,570,339,195],[1078,1077,538,106],[731,1185,538,106],[731,1293,538,106],[400,297,1377,58],[400,177,1541,58],[384,747,358,207],[1521,561,335,194],[1271,1185,312,181],[1315,1712,289,168],[743,969,333,191],[1016,1401,304,181],[638,1766,295,175],[1016,1760,285,170],[1585,1882,276,164],[1614,1589,267,159],[0,642,382,223],[767,357,363,213],[1496,357,345,202],[376,1370,327,192],[705,1401,309,181],[1322,1540,290,170],[1616,1307,272,160],[400,237,1421,58],[0,175,398,232],[0,867,382,222],[400,357,365,213],[381,1165,348,203],[744,774,331,193],[1401,887,314,183],[1016,1584,297,174],[1303,1882,280,164],[0,409,397,231],[0,1091,379,221],[1132,357,362,211],[834,572,344,200],[376,1564,327,190],[705,1584,309,180],[1322,1368,292,170],[1618,1145,274,160],[0,1532,374,211],[1717,757,214,224],[370,1756,266,232]]},
		{name:"step1_registration_atlas_5", frames: [[1562,1120,256,63],[1223,898,195,114],[0,1166,180,85],[250,204,184,108],[1820,1120,165,97],[268,0,202,202],[1465,152,432,87],[2012,130,31,18],[1896,992,31,18],[563,1040,31,18],[1232,302,175,71],[1901,846,97,47],[702,156,25,31],[507,1681,97,47],[702,189,25,31],[606,1681,97,47],[737,0,264,153],[0,157,248,144],[944,446,232,134],[380,584,215,125],[1700,782,199,116],[0,953,183,107],[898,1119,167,97],[0,1253,150,88],[1486,1368,134,79],[256,1478,118,70],[1657,1618,101,60],[1149,1681,85,51],[717,1398,69,42],[861,548,53,32],[1781,1185,36,23],[2025,572,20,14],[1882,1219,154,89],[586,1398,129,78],[1056,1475,121,73],[884,1549,113,68],[1335,1595,105,64],[1442,1595,97,59],[1536,1679,89,55],[861,447,81,50],[747,1736,73,45],[1980,44,66,41],[537,711,58,36],[1899,151,50,32],[1161,200,42,27],[436,204,34,22],[916,548,26,18],[577,749,18,13],[1298,375,10,9],[529,1478,118,70],[351,1578,107,64],[969,1619,97,58],[1610,957,86,52],[735,775,75,46],[649,1478,65,40],[730,1063,54,34],[1409,332,43,27],[1899,218,33,21],[1505,765,22,15],[1246,375,11,9],[1292,656,211,120],[1019,781,202,119],[834,902,189,112],[1755,1014,176,104],[345,1122,164,97],[1231,1220,151,90],[649,1314,138,82],[0,1427,126,75],[1542,1549,113,68],[218,1619,100,60],[1610,902,87,53],[1968,1734,75,46],[1400,526,62,38],[1178,446,49,31],[345,1063,36,24],[436,297,24,16],[1259,375,11,9],[1292,778,205,118],[987,200,172,100],[182,1165,161,93],[152,1260,150,87],[789,1314,139,81],[1056,1399,128,74],[649,1549,116,68],[597,584,105,62],[320,1644,94,56],[1409,1714,83,49],[1335,1550,72,43],[962,1016,61,37],[1899,185,50,31],[1409,361,39,24],[449,541,28,18],[1178,512,17,12],[987,192,6,6],[1704,241,246,142],[1704,385,239,137],[1688,524,224,128],[220,711,209,120],[1700,900,194,112],[1395,1014,179,103],[511,1164,164,95],[498,1261,149,86],[789,1397,135,78],[717,1477,120,70],[1768,1617,105,61],[193,1681,90,53],[369,1736,75,45],[834,1219,60,36],[450,1312,45,28],[1980,130,30,19],[250,171,15,11],[2040,150,6,69],[1455,155,6,58],[729,156,6,47],[987,155,6,35],[995,155,6,24],[995,181,6,13],[0,0,266,155],[987,302,243,142],[1178,526,220,128],[635,834,197,115],[1025,1015,174,102],[345,1221,151,89],[1757,1398,128,76],[1878,1616,105,63],[0,1701,82,50],[1019,712,59,36],[677,1194,36,23],[1934,218,13,10],[767,1549,115,68],[376,1508,119,68],[635,775,98,57],[1888,1734,78,46],[1989,1550,57,35],[962,1094,37,23],[1197,512,17,12],[1205,0,258,153],[737,155,248,148],[0,303,239,143],[1232,387,230,137],[0,448,221,132],[1688,654,211,126],[0,713,202,121],[405,897,193,116],[600,951,184,110],[387,1015,174,105],[563,1063,165,99],[898,1218,156,94],[1901,666,147,89],[1700,1312,138,83],[926,1397,128,78],[1757,1476,119,72],[999,1550,110,67],[1111,1618,101,61],[1316,1661,91,56],[1894,1681,82,51],[822,1736,73,45],[1486,1312,64,40],[1423,1478,54,34],[786,951,45,29],[345,1089,36,24],[449,561,27,18],[1186,285,17,13],[1455,215,8,7],[1056,1221,151,88],[1202,1398,131,76],[1604,1478,119,69],[220,646,107,63],[97,1646,94,56],[1236,1719,82,49],[947,834,70,42],[586,1349,58,35],[677,1164,46,28],[436,228,33,21],[2025,556,21,14],[1334,375,9,8],[1395,1119,165,98],[1552,1280,146,86],[450,1349,134,80],[1479,1449,123,73],[238,1550,111,67],[460,1619,100,60],[858,1680,89,54],[1149,1734,77,47],[1223,824,66,40],[705,1681,54,34],[1622,1368,43,27],[436,274,31,21],[2025,588,20,14],[1345,375,9,8],[0,1504,117,70],[110,1580,106,64],[1080,582,96,58],[1062,1681,85,52],[1026,1735,74,46],[71,1756,64,39],[446,1736,53,33],[1161,229,42,27],[702,246,32,21],[2025,522,21,15],[1310,375,10,9],[1724,0,254,149],[241,315,236,139],[861,582,217,128],[1499,782,199,118],[1505,656,181,107],[1067,1122,162,97],[1056,1311,144,86],[128,1431,126,75],[1768,1550,108,65],[1627,1680,89,54],[1644,1736,71,44],[311,1754,53,33],[563,1015,35,23],[250,157,16,12],[1423,1524,117,69],[0,1576,108,64],[766,1619,100,59],[969,1679,91,54],[1320,1719,82,49],[1494,1736,73,44],[1978,1681,65,40],[1989,1587,56,35],[812,648,47,30],[944,415,38,25],[2000,878,30,20],[2025,539,21,15],[1717,1736,71,42],[1404,1765,65,38],[1987,1181,59,35],[1726,1185,53,32],[511,1122,47,28],[1161,258,41,25],[947,878,35,22],[304,1284,29,19],[1161,285,23,15],[916,568,17,12],[1272,375,11,9],[1562,1185,162,93],[0,1343,135,82],[274,1399,126,77],[1878,1476,118,72],[1224,1550,109,66],[1214,1618,100,61],[1442,1656,92,56],[1809,1681,83,51],[168,1736,74,46],[1980,87,65,41],[834,1257,57,36],[329,646,48,31],[944,305,39,26],[984,878,31,20],[1529,765,22,15],[702,292,13,10],[1236,1681,53,34],[2000,846,46,30],[944,333,39,26],[702,222,32,22],[759,1099,25,18],[2025,620,19,14],[1934,230,12,9],[0,582,218,129],[431,775,202,120],[1025,902,187,111],[0,1062,171,102],[677,1219,155,93],[1202,1312,140,84],[930,1314,124,75],[1657,1550,109,66],[960,1477,93,57],[1809,1734,77,47],[1400,566,62,38],[1223,866,46,29],[600,897,30,20],[250,184,15,11],[839,1477,119,70],[1878,1550,109,64],[868,1619,99,59],[416,1681,89,53],[861,499,79,47],[0,1753,69,42],[1987,1143,59,36],[329,679,49,30],[944,361,39,25],[1840,1312,29,19],[2025,636,19,14],[1205,155,248,145],[1464,387,232,135],[479,315,221,129],[1080,656,210,123],[204,833,199,116],[1420,902,188,110],[1576,1014,177,104],[730,1119,166,98],[1395,1219,155,91],[304,1312,144,85],[1344,1397,133,79],[1179,1476,122,72],[834,834,111,66],[562,1619,100,60],[1718,1680,89,54],[507,1730,78,47],[380,541,67,41],[1985,1624,56,35],[786,982,45,29],[304,1260,35,22],[405,833,24,16],[717,292,13,10],[587,1730,78,47],[1569,1736,73,44],[1223,781,67,41],[962,1055,61,37],[529,1431,55,34],[1178,479,49,31],[402,1399,43,27],[537,749,38,24],[436,251,32,21],[649,1261,26,17],[2025,604,20,14],[786,1016,174,101],[1726,1219,154,91],[1901,757,147,87],[1344,1312,140,83],[1622,1397,133,79],[402,1431,125,75],[1303,1478,118,70],[1111,1550,111,66],[431,711,104,62],[1541,1619,97,58],[766,1680,90,54],[285,1702,82,50],[949,1735,75,46],[1980,0,68,42],[1400,606,61,38],[717,1442,54,33],[1019,750,47,29],[944,388,39,25],[702,269,32,21],[649,1280,25,17],[1553,765,18,13],[1285,375,11,9],[472,0,263,154],[1455,241,247,144],[479,447,230,135],[597,648,213,125],[0,836,196,115],[1214,1014,179,106],[1231,1122,162,96],[1882,1310,145,86],[1887,1398,128,76],[497,1550,111,67],[0,1642,95,57],[667,1730,78,47],[1987,1104,61,37],[1409,302,44,28],[730,1099,27,18],[1322,375,10,8],[1465,0,257,150],[702,305,240,140],[1464,524,222,130],[812,712,205,120],[198,951,187,110],[173,1063,170,100],[1896,900,152,90],[137,1349,135,80],[119,1508,117,70],[664,1619,100,60],[84,1704,82,50],[244,1754,65,40],[812,680,47,30],[600,919,30,20],[1232,375,12,10],[1933,992,102,110],[1003,0,200,198],[1945,408,92,112],[711,447,148,199],[472,156,228,157],[380,456,84,83],[1914,524,109,140],[1952,151,86,255],[223,456,155,188]]}
];


// symbols:



(lib.CachedBmp_4509 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4508 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4507 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4506 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4505 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4504 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4503 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4502 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4501 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4500 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4499 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4498 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4497 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4496 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4495 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4494 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4493 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4492 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4491 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4490 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4489 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4488 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4487 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4486 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4485 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4484 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4483 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4482 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4481 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4480 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4479 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4478 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4477 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4476 = function() {
	this.initialize(img.CachedBmp_4476);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3144,2002);


(lib.CachedBmp_4475 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4474 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4473 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4472 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4471 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4470 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4469 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4467 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4468 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4465 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4464 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4463 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4461 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4459 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4462 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4457 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4456 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4455 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4454 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4453 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4452 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4451 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4450 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4449 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4448 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4447 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4446 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4445 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4444 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4443 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4442 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4441 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4440 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4439 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4438 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4437 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4436 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4435 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4434 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4433 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4432 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4431 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4430 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4429 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4428 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4427 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4426 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4425 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4424 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4423 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4422 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4421 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4420 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4419 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4418 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4417 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4416 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4415 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4414 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4413 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4412 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4411 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4410 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4409 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4408 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4407 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4406 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4405 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4404 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4403 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4402 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4401 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4400 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4399 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4398 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4397 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4396 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4395 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4394 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4393 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4392 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4391 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4390 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4389 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4388 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4387 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4386 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4385 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4384 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4383 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4382 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4381 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4380 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4379 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4378 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4377 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4376 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4375 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4374 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4373 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4372 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4371 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4370 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4369 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4368 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4367 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4366 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4365 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4364 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4363 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4362 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4361 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4360 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4359 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4358 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4357 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4356 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4355 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4354 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4353 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4352 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4351 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4350 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4349 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4348 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4347 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4346 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4345 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4344 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4343 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4342 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4341 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4340 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4339 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4338 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4337 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4336 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4335 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4334 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4333 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4332 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4331 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4330 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4329 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4328 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4327 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4326 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4325 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4324 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4323 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4322 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4321 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4320 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4319 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4318 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4317 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4316 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4315 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4314 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4313 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4312 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4311 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4310 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4309 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4308 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4307 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4306 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4305 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4304 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4303 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4302 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4301 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4300 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4299 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4298 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4297 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4296 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4295 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4294 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4293 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4292 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4291 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4290 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4289 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4288 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4287 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4286 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4285 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4284 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4283 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4282 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4281 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4280 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4279 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4278 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4277 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4276 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4275 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4274 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4273 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4272 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4271 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4270 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4269 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4268 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(179);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4267 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(180);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4266 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(181);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4265 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(182);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4264 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(183);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4263 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(184);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4262 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(185);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4261 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(186);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4260 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(187);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4259 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(188);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4258 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(189);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4257 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(190);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4256 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(191);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4255 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(192);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4254 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(193);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4253 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(194);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4252 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(195);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4251 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(196);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4250 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(197);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4249 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(198);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4248 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(199);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4247 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(200);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4246 = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4245 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4244 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4243 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4242 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4241 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4240 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4239 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4238 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4237 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4236 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4235 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4234 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4233 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4232 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4231 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4230 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4229 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4228 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(201);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4227 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(202);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4226 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(203);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4225 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(204);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4224 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(205);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4223 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(206);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4222 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(207);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4221 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(208);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4220 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(209);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4219 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(210);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4218 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(211);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4217 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(212);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4216 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(213);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4215 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(214);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4214 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4213 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4212 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(215);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4211 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(216);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4210 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(217);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4209 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(218);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4208 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(219);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4207 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(220);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4206 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(221);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4205 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(222);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4204 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(223);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4203 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(224);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4202 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(225);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4201 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(226);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4200 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(227);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4199 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(228);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4198 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(229);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4197 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(230);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4196 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(231);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4195 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(232);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4194 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(233);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4193 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(234);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4192 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(235);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4191 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(236);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4190 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(237);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4189 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(238);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4188 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(239);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4187 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(240);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4186 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(241);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4185 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(242);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4184 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(243);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4183 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(244);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4182 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(245);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4181 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(246);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4180 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(247);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4179 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(248);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4178 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(249);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4177 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(250);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4176 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(251);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4175 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(252);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4174 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(253);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4173 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(254);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4172 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(255);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4171 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(256);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4170 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(257);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4169 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(258);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4168 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(259);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4167 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(260);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4166 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(261);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4165 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(262);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4164 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(263);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4163 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(264);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4162 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(265);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4161 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(266);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4160 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(267);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4159 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(268);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4158 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(269);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4157 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(270);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4156 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(271);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4155 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(272);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4154 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(273);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4153 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(274);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4152 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(275);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4151 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(276);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4150 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(277);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4149 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(278);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4148 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(279);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4147 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(280);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4146 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(281);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4145 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(282);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4144 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(283);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4143 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(284);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4142 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(285);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4141 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(286);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4140 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(287);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4139 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(288);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4138 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(289);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4137 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(290);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4136 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(291);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4135 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(292);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4134 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(293);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4133 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(294);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4132 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(295);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4131 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(296);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4130 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(297);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4129 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(298);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4128 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(299);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4127 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(300);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4126 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(301);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4125 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(302);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4124 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(303);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4123 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(304);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4122 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(305);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4121 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(306);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4120 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(307);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4119 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(308);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4118 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(309);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4117 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(310);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4116 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(311);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4115 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(312);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4114 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(313);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4113 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(314);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4112 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(315);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4111 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(316);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4110 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(317);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4109 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(318);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4108 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(319);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4107 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(320);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4106 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(321);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4105 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(322);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4104 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(323);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4103 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(324);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4102 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(325);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4101 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(326);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4100 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(327);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4099 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(328);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4098 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(329);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4097 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(330);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4096 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(331);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4095 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(332);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4094 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(333);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4093 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(334);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4092 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(335);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4091 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(336);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4090 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(337);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4089 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(338);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4088 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(339);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4087 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(340);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4086 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4085 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4084 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4083 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4082 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4081 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4080 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4079 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4078 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4077 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4076 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4075 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4074 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4073 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4072 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4071 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(341);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4070 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(342);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4069 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(343);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4068 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(344);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4067 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(345);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4066 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(346);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4065 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(347);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4064 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(348);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4063 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(349);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4062 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(350);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4061 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(351);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4060 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(352);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4059 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(353);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4058 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(354);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4057 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(355);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4056 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(356);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4055 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4054 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4053 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4052 = function() {
	this.initialize(ss["step1_registration_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4051 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4050 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4049 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4048 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4047 = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4046 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4045 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4044 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4043 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4042 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4041 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4040 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4039 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4038 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(357);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4037 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(358);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4036 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(359);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4035 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(360);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4034 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(361);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4033 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(362);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4032 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(363);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4031 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(364);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4030 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(365);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4029 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(366);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4028 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(367);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4027 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(368);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4026 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(369);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4025 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(370);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4024 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(371);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(372);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(373);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(374);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(375);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(376);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(377);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(378);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.imgbggrid = function() {
	this.initialize(img.imgbggrid);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4132,2198);


(lib.imgcashback = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.imgfibo = function() {
	this.initialize(ss["step1_registration_atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.imgfunds = function() {
	this.initialize(ss["step1_registration_atlas_4"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.imgjames = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(379);
}).prototype = p = new cjs.Sprite();



(lib.imglicensespack = function() {
	this.initialize(ss["step1_registration_atlas_5"]);
	this.gotoAndStop(380);
}).prototype = p = new cjs.Sprite();



(lib.imgtradingaccount = function() {
	this.initialize(ss["step1_registration_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtmeetjames = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4509();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,128,31.5);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4508();
	this.instance.setTransform(-136.75,-56.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.7,-56.9,273.5,114);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4507();
	this.instance.setTransform(-136.75,-56.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-136.7,-56.9,273.5,114);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4506();
	this.instance.setTransform(-139.2,-70.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-139.2,-70.6,278.5,141.5);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4505();
	this.instance.setTransform(-139.2,-70.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-139.2,-70.6,278.5,141.5);


(lib.tradingaccount = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgtradingaccount();
	this.instance.setTransform(0,0,0.504,0.504);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,291.3,239.4);


(lib.thumbsup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,109,140);


(lib.texttitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4504();
	this.instance.setTransform(10,-3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,-3,666.5,148);


(lib.textrebates = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4503();
	this.instance.setTransform(4.6,73.5,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4.6,73.5,72,42.099999999999994);


(lib.textmonthlycashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4502();
	this.instance.setTransform(-27.25,55.25,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.2,55.3,135.9,78.60000000000001);


(lib.textlp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4501();
	this.instance.setTransform(29.9,0,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(29.9,0,137.79999999999998,79.8);


(lib.textjames = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4500();
	this.instance.setTransform(-23.95,0,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.9,0,66.5,31.4);


(lib.textcommissions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4499();
	this.instance.setTransform(-10.15,65.05,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.1,65.1,101.5,59.10000000000001);


(lib.textbroker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4498();
	this.instance.setTransform(6.65,74.65,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.7,74.7,67.89999999999999,39.89999999999999);


(lib.textbanks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4497();
	this.instance.setTransform(68.3,21.95,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.3,22,61.000000000000014,35.8);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4496();
	this.instance.setTransform(0,0,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320.5,132);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4495();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,245,114);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4494();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,368,141.5);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4493();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239.5,114);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4492();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,292,141.5);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4491();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,285.5,141.5);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4490();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,348.5,114);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4489();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,376,141.5);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4488();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,284,114);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4487();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239,114);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4486();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,59);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4485();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,216.5,86.5);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4484();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,269.5,86.5);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4483();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239.5,114);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4482();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,180.5,59);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4481();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,222.5,86.5);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4480();
	this.instance.setTransform(-3.75,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,0,256,87.5);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4479();
	this.instance.setTransform(0,3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,3,248.5,87.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,374,211);


(lib.speechbubble2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(114,79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(114,79,228,157);


(lib.mccashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgcashback();
	this.instance.setTransform(0,0,0.6694,0.6696);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143.3,150);


(lib.managedfund = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4478();
	this.instance.setTransform(13.9,-2.3,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,-2.3,131.9,76.5);


(lib.logoicon2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap22();
	this.instance.setTransform(8,8);

	this.instance_1 = new lib.CachedBmp_4477();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,101,101);


(lib.logoicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(89,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89,88,200,198);


(lib.liquidityproviders = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap11();
	this.instance.setTransform(109,131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109,131,92,112);


(lib.licencsespack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imglicensespack();
	this.instance.setTransform(58.05,32.4,0.512,0.512);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(58.1,32.4,79.30000000000001,96.29999999999998);


(lib.james = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.imgjames();
	this.instance.setTransform(-3,15.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,15.3,86,255);


(lib.grid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgbggrid();
	this.instance.setTransform(0,0,0.4647,0.4646);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,1021.3);


(lib.funds = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_4475();
	this.instance.setTransform(-1.1,-28.7,0.3078,0.3078);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.imgfunds();
	this.instance_1.setTransform(0,0,0.45,0.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.1,-28.7,133,133.1);


(lib.fibo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgfibo();
	this.instance.setTransform(0,0,0.45,0.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,158.4,158.4);


(lib.dotpink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4474();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.dotorange = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4473();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.dotblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4472();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.5,9);


(lib.cbmgeneration = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4471();
	this.instance.setTransform(-9.6,65.35,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.6,65.4,118.6,69.4);


(lib.buycashbacklicenses = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4470();
	this.instance.setTransform(0,0,0.3693,0.3693);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,125.2,72);


(lib.btnreplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay.svg
	this.instance = new lib.CachedBmp_4464();
	this.instance.setTransform(132.55,72,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_4463();
	this.instance_1.setTransform(81.1,68.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_4468();
	this.instance_2.setTransform(132.55,72,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4465();
	this.instance_3.setTransform(81.1,68.05,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_4467();
	this.instance_4.setTransform(81.1,68.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_4469();
	this.instance_5.setTransform(68.5,62.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4},{t:this.instance_2}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.5,62.7,87.5,35.5);


(lib.btnregister = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.CachedBmp_4457();
	this.instance.setTransform(-34.25,66.55,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_4456();
	this.instance_1.setTransform(-107.05,47.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_4459();
	this.instance_2.setTransform(-34.25,66.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4462();
	this.instance_3.setTransform(-107.05,47.1,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_4461();
	this.instance_4.setTransform(-34.25,66.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_3},{t:this.instance_4}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-107,47.1,414,90.5);


(lib.broker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-12,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-17,148,199);


(lib.banks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(38,37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,37,102,110);


(lib.infographic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.textmonthlycashback("synched",0);
	this.instance.setTransform(588.95,570.85,0.9025,0.9025,0,0,0,40.6,94.7);

	this.instance_1 = new lib.Symbol1("synched",0);
	this.instance_1.setTransform(922.95,803.45,0.9025,0.9025,0,0,0,187.1,104);

	this.instance_2 = new lib.dotpink("synched",0);
	this.instance_2.setTransform(910.45,692.75,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_3 = new lib.dotpink("synched",0);
	this.instance_3.setTransform(1170.35,650.5,0.6552,0.6552,0,0,0,7.7,4.5);

	this.instance_4 = new lib.fibo("synched",0);
	this.instance_4.setTransform(1302.3,825.95,0.9025,0.9025,0,0,0,79.3,79.3);

	this.instance_5 = new lib.mccashback("synched",0);
	this.instance_5.setTransform(1423.1,701.95,0.731,0.731,0,0,0,71.6,75);

	this.instance_6 = new lib.dotorange("synched",0);
	this.instance_6.setTransform(1227.05,617.45,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_7 = new lib.textrebates("synched",0);
	this.instance_7.setTransform(1381.9,484.1,0.9025,0.9025,0,0,0,40.8,94.7);

	this.instance_8 = new lib.textcommissions("synched",0);
	this.instance_8.setTransform(1518.8,247.45,0.9025,0.9025,0,0,0,40.6,94.7);

	this.instance_9 = new lib.textbanks("synched",0);
	this.instance_9.setTransform(1667.5,254.5,0.9025,0.9025,0,0,0,98.9,40);

	this.instance_10 = new lib.banks("synched",0);
	this.instance_10.setTransform(1630.25,207.35,0.9025,0.9025,0,0,0,94.5,91.6);

	this.instance_11 = new lib.textlp("synched",0);
	this.instance_11.setTransform(1500.7,93.85,0.9025,0.9025,0,0,0,99,40);

	this.instance_12 = new lib.liquidityproviders("synched",0);
	this.instance_12.setTransform(1527.35,138.75,0.9025,0.9025,0,0,0,154.6,187.5);

	this.instance_13 = new lib.managedfund("synched",0);
	this.instance_13.setTransform(1247.5,164.1,0.9025,0.9025,0,0,0,62.6,36.1);

	this.instance_14 = new lib.dotorange("synched",0);
	this.instance_14.setTransform(1171.6,131,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_15 = new lib.textbroker("synched",0);
	this.instance_15.setTransform(1333.4,382.6,0.9025,0.9025,0,0,0,40.8,94.7);

	this.instance_16 = new lib.broker("synched",0);
	this.instance_16.setTransform(1411.9,283.15,0.9025,0.9025,0,0,0,61.9,82.9);

	this.instance_17 = new lib.funds("synched",0);
	this.instance_17.setTransform(1091.6,97.3,1.083,1.083,0,0,0,60,52.3);

	this.instance_18 = new lib.dotpink("synched",0);
	this.instance_18.setTransform(993.35,328.35,0.4193,0.4193,0,0,0,7.5,4.5);

	this.instance_19 = new lib.tradingaccount("synched",0);
	this.instance_19.setTransform(1064.55,298.6,0.9025,0.9025,0,0,0,145.7,119.8);

	this.instance_20 = new lib.dotblue("synched",0);
	this.instance_20.setTransform(874.3,429.75,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_21 = new lib.buycashbacklicenses("synched",0);
	this.instance_21.setTransform(743.45,629.45,0.9025,0.9025,0,0,0,62.6,36.2);

	this.instance_22 = new lib.licencsespack("synched",0);
	this.instance_22.setTransform(865.1,654.05,0.9025,0.9025,0,0,0,98.4,81.6);

	this.instance_23 = new lib.dotpink("synched",0);
	this.instance_23.setTransform(1002.05,552.2,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_24 = new lib.dotpink("synched",0);
	this.instance_24.setTransform(775.8,551.7,0.6552,0.6552,0,0,0,7.5,4.5);

	this.instance_25 = new lib.cbmgeneration("synched",0);
	this.instance_25.setTransform(968.75,471.45,0.9025,0.9025,0,0,0,49.6,100.1);

	this.instance_26 = new lib.logoicon("synched",0);
	this.instance_26.setTransform(1121.55,560.4,0.9001,0.8999,0,0,0,190.3,182.5);

	this.instance_27 = new lib.dotpink("synched",0);
	this.instance_27.setTransform(872,496.5,0.6552,0.6552,0,0,0,7.7,4.6);

	this.instance_28 = new lib.textjames("synched",0);
	this.instance_28.setTransform(769.9,383.2,0.9025,0.9025,0,0,0,17.5,15.8);

	this.instance_29 = new lib.james();
	this.instance_29.setTransform(826.4,441.8,0.9025,0.9025,0,0,0,44,125);

	this.instance_30 = new lib.grid("synched",0);
	this.instance_30.setTransform(953.1,507,0.9927,0.9927,0,0,0,960.1,510.7);

	this.instance_31 = new lib.CachedBmp_4476();
	this.instance_31.setTransform(493.7,130.25,0.3333,0.3333);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.infographic, new cjs.Rectangle(0,0,1905.9,1013.8), null);


// stage content:
(lib.step1registration = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_5277 = function() {
		this.stop();
		
		this.replayBtn.addEventListener("click", fl_ClickToGoToAndPlayAtFrame1.bind(this));
		function fl_ClickToGoToAndPlayAtFrame1()
		{
			this.gotoAndPlay(0);
		}
		
		this.letsregisterBtn.addEventListener("click", fl_ClickToGoToWebPage_1);
		
		function fl_ClickToGoToWebPage_1() {
			window.open("step1-registration.php", "_self");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(5277).call(this.frame_5277).wait(1));

	// Btn_Replay
	this.replayBtn = new lib.btnreplay();
	this.replayBtn.name = "replayBtn";
	this.replayBtn.setTransform(1817,72.75,1,1,0,0,0,112,80.3);
	this.replayBtn.alpha = 0;
	this.replayBtn._off = true;
	new cjs.ButtonHelper(this.replayBtn, 0, 1, 2, false, new lib.btnreplay(), 3);

	this.timeline.addTween(cjs.Tween.get(this.replayBtn).wait(5262).to({_off:false},0).to({x:1827,alpha:1},15).wait(1));

	// Layer_9
	this.letsregisterBtn = new lib.btnregister();
	this.letsregisterBtn.name = "letsregisterBtn";
	this.letsregisterBtn.setTransform(972.1,630.25,1,1,0,0,0,112,80.3);
	this.letsregisterBtn._off = true;
	new cjs.ButtonHelper(this.letsregisterBtn, 0, 1, 2, false, new lib.btnregister(), 3);

	this.timeline.addTween(cjs.Tween.get(this.letsregisterBtn).wait(5251).to({_off:false},0).to({y:590.25},10,cjs.Ease.get(0.5)).wait(17));

	// Layer_7
	this.instance = new lib.Symbol24("synched",0);
	this.instance.setTransform(959.95,538.95,2,2,0,0,0,160.2,66);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5206).to({_off:false},0).to({scaleX:0.64,scaleY:0.64,y:538.9},15,cjs.Ease.get(0.5)).wait(30).to({startPosition:0},0).to({y:498.9},10,cjs.Ease.get(0.5)).wait(17));

	// Layer_32
	this.instance_1 = new lib.textmonthlycashback("synched",0);
	this.instance_1.setTransform(507.25,639.65,0.9025,0.9025,0,0,0,40.6,94.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5100).to({_off:false},0).to({x:500.95,alpha:1},10).to({_off:true},71).wait(97));

	// Layer_29
	this.instance_2 = new lib.CachedBmp_4024();
	this.instance_2.setTransform(405.7,714.65,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4025();
	this.instance_3.setTransform(405.7,709.65,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_4026();
	this.instance_4.setTransform(405.7,704.6,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_4027();
	this.instance_5.setTransform(405.7,699.6,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_4028();
	this.instance_6.setTransform(405.7,694.55,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_4029();
	this.instance_7.setTransform(405.7,689.55,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_4030();
	this.instance_8.setTransform(405.7,684.5,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_4031();
	this.instance_9.setTransform(405.7,679.5,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_4032();
	this.instance_10.setTransform(405.7,674.5,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_4033();
	this.instance_11.setTransform(405.7,669.45,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_4034();
	this.instance_12.setTransform(405.7,664.45,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_4035();
	this.instance_13.setTransform(405.7,659.4,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_4036();
	this.instance_14.setTransform(405.7,654.4,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_4037();
	this.instance_15.setTransform(405.7,649.35,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_4038();
	this.instance_16.setTransform(405.7,644.35,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_4039();
	this.instance_17.setTransform(405.7,639.35,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_4040();
	this.instance_18.setTransform(405.7,634.3,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_4041();
	this.instance_19.setTransform(405.7,629.3,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_4042();
	this.instance_20.setTransform(405.7,624.25,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_4043();
	this.instance_21.setTransform(405.7,619.25,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_4044();
	this.instance_22.setTransform(405.7,614.2,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_4045();
	this.instance_23.setTransform(405.7,609.2,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_4046();
	this.instance_24.setTransform(405.7,604.15,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_4047();
	this.instance_25.setTransform(405.7,599.15,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_4048();
	this.instance_26.setTransform(405.7,594.15,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_4049();
	this.instance_27.setTransform(405.7,589.1,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_4050();
	this.instance_28.setTransform(405.7,584.1,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_4051();
	this.instance_29.setTransform(405.7,579.05,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_4052();
	this.instance_30.setTransform(405.7,574.05,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_4053();
	this.instance_31.setTransform(405.7,569,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_4054();
	this.instance_32.setTransform(405.7,564,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_4055();
	this.instance_33.setTransform(405.7,558.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},5069).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[]},81).wait(97));

	// Layer_30
	this.instance_34 = new lib.CachedBmp_4056();
	this.instance_34.setTransform(659.1,862.45,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_4057();
	this.instance_35.setTransform(650.65,857.6,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_4058();
	this.instance_36.setTransform(642.2,852.7,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_4059();
	this.instance_37.setTransform(633.75,847.85,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_4060();
	this.instance_38.setTransform(625.3,843,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_4061();
	this.instance_39.setTransform(616.85,838.1,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_4062();
	this.instance_40.setTransform(608.4,833.25,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_4063();
	this.instance_41.setTransform(599.95,828.4,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_4064();
	this.instance_42.setTransform(591.55,823.55,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_4065();
	this.instance_43.setTransform(583.1,818.65,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_4066();
	this.instance_44.setTransform(574.65,813.8,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_4067();
	this.instance_45.setTransform(566.2,808.95,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_4068();
	this.instance_46.setTransform(557.75,804.05,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_4069();
	this.instance_47.setTransform(549.3,799.2,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_4070();
	this.instance_48.setTransform(540.85,794.35,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_4071();
	this.instance_49.setTransform(532.4,789.5,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_4072();
	this.instance_50.setTransform(523.95,784.6,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_4073();
	this.instance_51.setTransform(515.5,779.75,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_4074();
	this.instance_52.setTransform(507.05,774.9,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_4075();
	this.instance_53.setTransform(498.6,770,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_4076();
	this.instance_54.setTransform(490.15,765.15,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_4077();
	this.instance_55.setTransform(481.7,760.3,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_4078();
	this.instance_56.setTransform(473.25,755.4,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_4079();
	this.instance_57.setTransform(464.85,750.55,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_4080();
	this.instance_58.setTransform(456.4,745.7,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_4081();
	this.instance_59.setTransform(447.95,740.85,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_4082();
	this.instance_60.setTransform(439.5,735.95,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_4083();
	this.instance_61.setTransform(431.05,731.1,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_4084();
	this.instance_62.setTransform(422.6,726.25,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_4085();
	this.instance_63.setTransform(414.15,721.35,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_4086();
	this.instance_64.setTransform(405.7,716.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_34}]},5039).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).to({state:[{t:this.instance_60}]},1).to({state:[{t:this.instance_61}]},1).to({state:[{t:this.instance_62}]},1).to({state:[{t:this.instance_63}]},1).to({state:[{t:this.instance_64}]},1).to({state:[]},112).wait(97));

	// Layer_25
	this.instance_65 = new lib.Symbol1("synched",0);
	this.instance_65.setTransform(834.95,885.95,0.9025,0.9025,0,0,0,187.1,104);
	this.instance_65.alpha = 0;
	this.instance_65._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_65).wait(5024).to({_off:false},0).to({y:868.35,alpha:1},10).to({y:872.4},5).to({_off:true},142).wait(97));

	// Layer_28
	this.instance_66 = new lib.CachedBmp_4087();
	this.instance_66.setTransform(854,780.7,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_4088();
	this.instance_67.setTransform(850.4,780.7,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_4089();
	this.instance_68.setTransform(846.85,780.7,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_4090();
	this.instance_69.setTransform(843.25,780.7,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_4091();
	this.instance_70.setTransform(839.65,780.7,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_4092();
	this.instance_71.setTransform(836.1,780.7,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_4093();
	this.instance_72.setTransform(832.5,780.7,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_4094();
	this.instance_73.setTransform(828.9,780.7,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_4095();
	this.instance_74.setTransform(825.35,780.7,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_4096();
	this.instance_75.setTransform(821.75,780.7,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_4097();
	this.instance_76.setTransform(818.2,780.7,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_4098();
	this.instance_77.setTransform(814.6,780.7,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_4099();
	this.instance_78.setTransform(811,780.7,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_4100();
	this.instance_79.setTransform(807.45,780.7,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_4101();
	this.instance_80.setTransform(803.85,780.7,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_4102();
	this.instance_81.setTransform(800.25,780.7,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_4103();
	this.instance_82.setTransform(796.7,780.7,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_4104();
	this.instance_83.setTransform(793.1,780.7,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_4105();
	this.instance_84.setTransform(789.5,780.7,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_4106();
	this.instance_85.setTransform(785.95,780.7,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_4107();
	this.instance_86.setTransform(782.35,780.7,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_4108();
	this.instance_87.setTransform(772.5,780.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_66}]},5004).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[{t:this.instance_69}]},1).to({state:[{t:this.instance_70}]},1).to({state:[{t:this.instance_71}]},1).to({state:[{t:this.instance_72}]},1).to({state:[{t:this.instance_73}]},1).to({state:[{t:this.instance_74}]},1).to({state:[{t:this.instance_75}]},1).to({state:[{t:this.instance_76}]},1).to({state:[{t:this.instance_77}]},1).to({state:[{t:this.instance_78}]},1).to({state:[{t:this.instance_79}]},1).to({state:[{t:this.instance_80}]},1).to({state:[{t:this.instance_81}]},1).to({state:[{t:this.instance_82}]},1).to({state:[{t:this.instance_83}]},1).to({state:[{t:this.instance_84}]},1).to({state:[{t:this.instance_85}]},1).to({state:[{t:this.instance_86}]},1).to({state:[{t:this.instance_87}]},1).to({state:[]},156).wait(97));

	// Layer_27
	this.instance_88 = new lib.CachedBmp_4109();
	this.instance_88.setTransform(820.2,760.05,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_4110();
	this.instance_89.setTransform(820.2,760.05,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_4111();
	this.instance_90.setTransform(820.2,760.05,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_4112();
	this.instance_91.setTransform(820.2,760.05,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_4113();
	this.instance_92.setTransform(820.2,760.05,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_4114();
	this.instance_93.setTransform(820.2,760.1,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_4115();
	this.instance_94.setTransform(820.15,760.1,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_4116();
	this.instance_95.setTransform(820.15,760.1,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_4117();
	this.instance_96.setTransform(820.15,760.1,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_4118();
	this.instance_97.setTransform(820.15,760.1,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_4119();
	this.instance_98.setTransform(820.15,760.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_88}]},4994).to({state:[{t:this.instance_89}]},1).to({state:[{t:this.instance_90}]},1).to({state:[{t:this.instance_91}]},1).to({state:[{t:this.instance_92}]},1).to({state:[{t:this.instance_93}]},1).to({state:[{t:this.instance_94}]},1).to({state:[{t:this.instance_95}]},1).to({state:[{t:this.instance_96}]},1).to({state:[{t:this.instance_97}]},1).to({state:[{t:this.instance_98}]},1).to({state:[]},177).wait(97));

	// Dot_Pink
	this.instance_99 = new lib.dotpink("synched",0);
	this.instance_99.setTransform(822.35,761.65,0.2707,0.2707,0,0,0,7.8,4.5);
	this.instance_99._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_99).wait(4979).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:822.4,y:761.7},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:822.3,y:761.65},5).to({_off:true},187).wait(97));

	// Layer_24
	this.instance_100 = new lib.CachedBmp_4120();
	this.instance_100.setTransform(1133.35,749.45,0.5,0.5);

	this.instance_101 = new lib.CachedBmp_4121();
	this.instance_101.setTransform(1127.85,749.45,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_4122();
	this.instance_102.setTransform(1122.35,749.45,0.5,0.5);

	this.instance_103 = new lib.CachedBmp_4123();
	this.instance_103.setTransform(1116.9,749.45,0.5,0.5);

	this.instance_104 = new lib.CachedBmp_4124();
	this.instance_104.setTransform(1111.4,749.45,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_4125();
	this.instance_105.setTransform(1105.9,749.45,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_4126();
	this.instance_106.setTransform(1100.4,749.45,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_4127();
	this.instance_107.setTransform(1094.9,749.45,0.5,0.5);

	this.instance_108 = new lib.CachedBmp_4128();
	this.instance_108.setTransform(1089.45,749.45,0.5,0.5);

	this.instance_109 = new lib.CachedBmp_4129();
	this.instance_109.setTransform(1083.95,749.45,0.5,0.5);

	this.instance_110 = new lib.CachedBmp_4130();
	this.instance_110.setTransform(1078.45,749.45,0.5,0.5);

	this.instance_111 = new lib.CachedBmp_4131();
	this.instance_111.setTransform(1072.95,749.45,0.5,0.5);

	this.instance_112 = new lib.CachedBmp_4132();
	this.instance_112.setTransform(1067.45,749.45,0.5,0.5);

	this.instance_113 = new lib.CachedBmp_4133();
	this.instance_113.setTransform(1062,749.45,0.5,0.5);

	this.instance_114 = new lib.CachedBmp_4134();
	this.instance_114.setTransform(1056.5,749.45,0.5,0.5);

	this.instance_115 = new lib.CachedBmp_4135();
	this.instance_115.setTransform(1051,749.45,0.5,0.5);

	this.instance_116 = new lib.CachedBmp_4136();
	this.instance_116.setTransform(1045.5,749.45,0.5,0.5);

	this.instance_117 = new lib.CachedBmp_4137();
	this.instance_117.setTransform(1040,749.45,0.5,0.5);

	this.instance_118 = new lib.CachedBmp_4138();
	this.instance_118.setTransform(1034.55,749.45,0.5,0.5);

	this.instance_119 = new lib.CachedBmp_4139();
	this.instance_119.setTransform(1029.05,749.45,0.5,0.5);

	this.instance_120 = new lib.CachedBmp_4140();
	this.instance_120.setTransform(1023.55,749.45,0.5,0.5);

	this.instance_121 = new lib.CachedBmp_4141();
	this.instance_121.setTransform(1015.7,749.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_100}]},5004).to({state:[{t:this.instance_101}]},1).to({state:[{t:this.instance_102}]},1).to({state:[{t:this.instance_103}]},1).to({state:[{t:this.instance_104}]},1).to({state:[{t:this.instance_105}]},1).to({state:[{t:this.instance_106}]},1).to({state:[{t:this.instance_107}]},1).to({state:[{t:this.instance_108}]},1).to({state:[{t:this.instance_109}]},1).to({state:[{t:this.instance_110}]},1).to({state:[{t:this.instance_111}]},1).to({state:[{t:this.instance_112}]},1).to({state:[{t:this.instance_113}]},1).to({state:[{t:this.instance_114}]},1).to({state:[{t:this.instance_115}]},1).to({state:[{t:this.instance_116}]},1).to({state:[{t:this.instance_117}]},1).to({state:[{t:this.instance_118}]},1).to({state:[{t:this.instance_119}]},1).to({state:[{t:this.instance_120}]},1).to({state:[{t:this.instance_121}]},1).to({state:[]},156).wait(97));

	// Layer_22
	this.instance_122 = new lib.CachedBmp_4142();
	this.instance_122.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_123 = new lib.CachedBmp_4143();
	this.instance_123.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_124 = new lib.CachedBmp_4144();
	this.instance_124.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_125 = new lib.CachedBmp_4145();
	this.instance_125.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_126 = new lib.CachedBmp_4146();
	this.instance_126.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_127 = new lib.CachedBmp_4147();
	this.instance_127.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_128 = new lib.CachedBmp_4148();
	this.instance_128.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_129 = new lib.CachedBmp_4149();
	this.instance_129.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_130 = new lib.CachedBmp_4150();
	this.instance_130.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_131 = new lib.CachedBmp_4151();
	this.instance_131.setTransform(1080.15,717.6,0.5,0.5);

	this.instance_132 = new lib.CachedBmp_4152();
	this.instance_132.setTransform(1080.15,717.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_122}]},4994).to({state:[{t:this.instance_123}]},1).to({state:[{t:this.instance_124}]},1).to({state:[{t:this.instance_125}]},1).to({state:[{t:this.instance_126}]},1).to({state:[{t:this.instance_127}]},1).to({state:[{t:this.instance_128}]},1).to({state:[{t:this.instance_129}]},1).to({state:[{t:this.instance_130}]},1).to({state:[{t:this.instance_131}]},1).to({state:[{t:this.instance_132}]},1).to({state:[]},177).wait(97));

	// Dot_Pink
	this.instance_133 = new lib.dotpink("synched",0);
	this.instance_133.setTransform(1082.25,719.4,0.2707,0.2707,0,0,0,7.8,4.3);
	this.instance_133._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_133).wait(4979).to({_off:false},0).to({regX:7.6,scaleX:0.9151,scaleY:0.9151},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:1082.2,y:719.45},5).to({_off:true},187).wait(97));

	// txt
	this.instance_134 = new lib.Symbol23("synched",0);
	this.instance_134.setTransform(455.6,296.5,1,1,0,0,0,122.5,56.9);
	this.instance_134.alpha = 0;
	this.instance_134._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_134).wait(4884).to({_off:false},0).to({y:306.5,alpha:1},10).wait(245).to({startPosition:0},0).to({y:296.5,alpha:0},10).to({_off:true},1).wait(128));

	// Speech_Bubble
	this.instance_135 = new lib.speechbubble2("synched",0);
	this.instance_135.setTransform(462.45,421.5,1.4184,1.4184,0,0,0,227.6,236);
	this.instance_135._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_135).wait(4874).to({_off:false},0).to({y:431.5},10).wait(255).to({startPosition:0},0).to({y:421.5},10).to({_off:true},1).wait(128));

	// Logo_Icon
	this.instance_136 = new lib.logoicon2("synched",0);
	this.instance_136.setTransform(462.3,747.45,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_136._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_136).wait(4843).to({_off:false},0).to({y:487.45},31,cjs.Ease.get(0.5)).wait(275).to({startPosition:0},0).to({regX:50,scaleX:0.9927,scaleY:0.9927,x:462.25,y:487.5},10).to({regX:50.1,scaleX:0.4964,scaleY:0.4964,y:487.45,alpha:0},5).to({_off:true},1).wait(113));

	// Img_Fibo
	this.instance_137 = new lib.fibo("synched",0);
	this.instance_137.setTransform(1214.2,894.8,0.2707,0.2707,-90,0,0,79.4,79);
	this.instance_137.alpha = 0;
	this.instance_137._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_137).wait(4773).to({_off:false},0).to({regX:79.3,regY:79.2,scaleX:0.9476,scaleY:0.9476,rotation:0,x:1214.25,y:894.85,alpha:1},11).to({regX:79.2,scaleX:0.9025,scaleY:0.9025},5).to({_off:true},392).wait(97));

	// Img_CashBack
	this.instance_138 = new lib.mccashback("synched",0);
	this.instance_138.setTransform(1335,787,0.731,0.731,0,0,0,71.5,75);
	this.instance_138.alpha = 0;
	this.instance_138._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_138).wait(4740).to({_off:false},0).to({regY:75.1,y:765.75,alpha:1},8).to({regY:75,y:770.95},5).to({_off:true},428).wait(97));

	// Line_Orange
	this.instance_139 = new lib.CachedBmp_4153();
	this.instance_139.setTransform(1378.7,801.9,0.5,0.5);

	this.instance_140 = new lib.CachedBmp_4154();
	this.instance_140.setTransform(1370.9,801.9,0.5,0.5);

	this.instance_141 = new lib.CachedBmp_4155();
	this.instance_141.setTransform(1363.1,801.9,0.5,0.5);

	this.instance_142 = new lib.CachedBmp_4156();
	this.instance_142.setTransform(1355.25,801.9,0.5,0.5);

	this.instance_143 = new lib.CachedBmp_4157();
	this.instance_143.setTransform(1347.45,801.9,0.5,0.5);

	this.instance_144 = new lib.CachedBmp_4158();
	this.instance_144.setTransform(1339.65,801.9,0.5,0.5);

	this.instance_145 = new lib.CachedBmp_4159();
	this.instance_145.setTransform(1331.85,801.9,0.5,0.5);

	this.instance_146 = new lib.CachedBmp_4160();
	this.instance_146.setTransform(1324,801.9,0.5,0.5);

	this.instance_147 = new lib.CachedBmp_4161();
	this.instance_147.setTransform(1316.2,801.9,0.5,0.5);

	this.instance_148 = new lib.CachedBmp_4162();
	this.instance_148.setTransform(1308.4,801.9,0.5,0.5);

	this.instance_149 = new lib.CachedBmp_4163();
	this.instance_149.setTransform(1300.6,801.9,0.5,0.5);

	this.instance_150 = new lib.CachedBmp_4164();
	this.instance_150.setTransform(1292.75,801.9,0.5,0.5);

	this.instance_151 = new lib.CachedBmp_4165();
	this.instance_151.setTransform(1284.95,801.9,0.5,0.5);

	this.instance_152 = new lib.CachedBmp_4166();
	this.instance_152.setTransform(1277.15,801.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_139}]},4760).to({state:[{t:this.instance_140}]},1).to({state:[{t:this.instance_141}]},1).to({state:[{t:this.instance_142}]},1).to({state:[{t:this.instance_143}]},1).to({state:[{t:this.instance_144}]},1).to({state:[{t:this.instance_145}]},1).to({state:[{t:this.instance_146}]},1).to({state:[{t:this.instance_147}]},1).to({state:[{t:this.instance_148}]},1).to({state:[{t:this.instance_149}]},1).to({state:[{t:this.instance_150}]},1).to({state:[{t:this.instance_151}]},1).to({state:[{t:this.instance_152}]},1).to({state:[]},408).wait(97));

	// Line_Orange
	this.instance_153 = new lib.CachedBmp_4167();
	this.instance_153.setTransform(1359.85,787.75,0.5,0.5);

	this.instance_154 = new lib.CachedBmp_4168();
	this.instance_154.setTransform(1359.85,787.75,0.5,0.5);

	this.instance_155 = new lib.CachedBmp_4169();
	this.instance_155.setTransform(1359.85,787.75,0.5,0.5);

	this.instance_156 = new lib.CachedBmp_4170();
	this.instance_156.setTransform(1359.85,787.8,0.5,0.5);

	this.instance_157 = new lib.CachedBmp_4171();
	this.instance_157.setTransform(1359.8,787.8,0.5,0.5);

	this.instance_158 = new lib.CachedBmp_4172();
	this.instance_158.setTransform(1359.8,787.8,0.5,0.5);

	this.instance_159 = new lib.CachedBmp_4173();
	this.instance_159.setTransform(1359.8,787.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_153}]},4754).to({state:[{t:this.instance_154}]},1).to({state:[{t:this.instance_155}]},1).to({state:[{t:this.instance_156}]},1).to({state:[{t:this.instance_157}]},1).to({state:[{t:this.instance_158}]},1).to({state:[{t:this.instance_159}]},1).to({state:[]},421).wait(97));

	// Line_Orange
	this.instance_160 = new lib.CachedBmp_4174();
	this.instance_160.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_161 = new lib.CachedBmp_4175();
	this.instance_161.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_162 = new lib.CachedBmp_4176();
	this.instance_162.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_163 = new lib.CachedBmp_4177();
	this.instance_163.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_164 = new lib.CachedBmp_4178();
	this.instance_164.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_165 = new lib.CachedBmp_4179();
	this.instance_165.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_166 = new lib.CachedBmp_4180();
	this.instance_166.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_167 = new lib.CachedBmp_4181();
	this.instance_167.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_168 = new lib.CachedBmp_4182();
	this.instance_168.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_169 = new lib.CachedBmp_4183();
	this.instance_169.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_170 = new lib.CachedBmp_4184();
	this.instance_170.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_171 = new lib.CachedBmp_4185();
	this.instance_171.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_172 = new lib.CachedBmp_4186();
	this.instance_172.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_173 = new lib.CachedBmp_4187();
	this.instance_173.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_174 = new lib.CachedBmp_4188();
	this.instance_174.setTransform(1224.9,699.4,0.5,0.5);

	this.instance_175 = new lib.CachedBmp_4189();
	this.instance_175.setTransform(1224.9,699.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_160}]},4725).to({state:[{t:this.instance_161}]},1).to({state:[{t:this.instance_162}]},1).to({state:[{t:this.instance_163}]},1).to({state:[{t:this.instance_164}]},1).to({state:[{t:this.instance_165}]},1).to({state:[{t:this.instance_166}]},1).to({state:[{t:this.instance_167}]},1).to({state:[{t:this.instance_168}]},1).to({state:[{t:this.instance_169}]},1).to({state:[{t:this.instance_170}]},1).to({state:[{t:this.instance_171}]},1).to({state:[{t:this.instance_172}]},1).to({state:[{t:this.instance_173}]},1).to({state:[{t:this.instance_174}]},1).to({state:[{t:this.instance_175}]},1).to({state:[]},441).wait(97));

	// Line_Orange
	this.instance_176 = new lib.CachedBmp_4190();
	this.instance_176.setTransform(1192.65,715.85,0.5,0.5);

	this.instance_177 = new lib.CachedBmp_4191();
	this.instance_177.setTransform(1192.65,714.2,0.5,0.5);

	this.instance_178 = new lib.CachedBmp_4192();
	this.instance_178.setTransform(1192.65,712.55,0.5,0.5);

	this.instance_179 = new lib.CachedBmp_4193();
	this.instance_179.setTransform(1192.65,710.95,0.5,0.5);

	this.instance_180 = new lib.CachedBmp_4194();
	this.instance_180.setTransform(1192.65,709.3,0.5,0.5);

	this.instance_181 = new lib.CachedBmp_4195();
	this.instance_181.setTransform(1192.65,707.65,0.5,0.5);

	this.instance_182 = new lib.CachedBmp_4196();
	this.instance_182.setTransform(1192.6,706,0.5,0.5);

	this.instance_183 = new lib.CachedBmp_4197();
	this.instance_183.setTransform(1192.6,704.35,0.5,0.5);

	this.instance_184 = new lib.CachedBmp_4198();
	this.instance_184.setTransform(1192.6,702.75,0.5,0.5);

	this.instance_185 = new lib.CachedBmp_4199();
	this.instance_185.setTransform(1192.6,701.1,0.5,0.5);

	this.instance_186 = new lib.CachedBmp_4200();
	this.instance_186.setTransform(1192.6,699.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_176}]},4715).to({state:[{t:this.instance_177}]},1).to({state:[{t:this.instance_178}]},1).to({state:[{t:this.instance_179}]},1).to({state:[{t:this.instance_180}]},1).to({state:[{t:this.instance_181}]},1).to({state:[{t:this.instance_182}]},1).to({state:[{t:this.instance_183}]},1).to({state:[{t:this.instance_184}]},1).to({state:[{t:this.instance_185}]},1).to({state:[{t:this.instance_186}]},1).to({state:[]},456).wait(97));

	// Line_Orange
	this.instance_187 = new lib.CachedBmp_4201();
	this.instance_187.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_188 = new lib.CachedBmp_4202();
	this.instance_188.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_189 = new lib.CachedBmp_4203();
	this.instance_189.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_190 = new lib.CachedBmp_4204();
	this.instance_190.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_191 = new lib.CachedBmp_4205();
	this.instance_191.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_192 = new lib.CachedBmp_4206();
	this.instance_192.setTransform(1137.15,685.5,0.5,0.5);

	this.instance_193 = new lib.CachedBmp_4207();
	this.instance_193.setTransform(1137.1,685.55,0.5,0.5);

	this.instance_194 = new lib.CachedBmp_4208();
	this.instance_194.setTransform(1137.1,685.55,0.5,0.5);

	this.instance_195 = new lib.CachedBmp_4209();
	this.instance_195.setTransform(1137.1,685.55,0.5,0.5);

	this.instance_196 = new lib.CachedBmp_4210();
	this.instance_196.setTransform(1137.1,685.55,0.5,0.5);

	this.instance_197 = new lib.CachedBmp_4211();
	this.instance_197.setTransform(1137.1,685.55,0.5,0.5);

	this.instance_198 = new lib.CachedBmp_4212();
	this.instance_198.setTransform(1137.1,685.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_187}]},4704).to({state:[{t:this.instance_188}]},1).to({state:[{t:this.instance_189}]},1).to({state:[{t:this.instance_190}]},1).to({state:[{t:this.instance_191}]},1).to({state:[{t:this.instance_192}]},1).to({state:[{t:this.instance_193}]},1).to({state:[{t:this.instance_194}]},1).to({state:[{t:this.instance_195}]},1).to({state:[{t:this.instance_196}]},1).to({state:[{t:this.instance_197}]},1).to({state:[{t:this.instance_198}]},1).to({state:[]},466).wait(97));

	// Dot_Orange
	this.instance_199 = new lib.dotorange("synched",0);
	this.instance_199.setTransform(1138.95,686.35,0.2707,0.2707,0,0,0,7.5,4.5);
	this.instance_199._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_199).wait(4699).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:1139,y:686.4},5).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:1138.9,y:686.35},5).to({_off:true},472).wait(97));

	// tooltip
	this.instance_200 = new lib.CachedBmp_4214();
	this.instance_200.setTransform(605.05,979.8,0.5,0.5);

	this.instance_201 = new lib.CachedBmp_4213();
	this.instance_201.setTransform(574.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_201},{t:this.instance_200}]},4549).to({state:[]},270).to({state:[]},362).wait(97));

	// txt
	this.instance_202 = new lib.Symbol22("synched",0);
	this.instance_202.setTransform(455.55,500.2,1,1,0,0,0,183.9,70.6);
	this.instance_202.alpha = 0;
	this.instance_202._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_202).wait(4539).to({_off:false},0).to({y:510.2,alpha:1},10).wait(270).to({startPosition:0},0).to({y:500.2,alpha:0},10).to({_off:true},1).wait(448));

	// Speech_Bubble
	this.instance_203 = new lib.speechbubble2("synched",0);
	this.instance_203.setTransform(462.45,691.35,1.4327,1.4327,0,0,0,227.6,235.9);
	this.instance_203._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_203).wait(4529).to({_off:false},0).to({regY:236,scaleX:1.97,scaleY:1.97,y:691.5},10).wait(280).to({startPosition:0},0).to({y:681.5},10).to({_off:true},1).wait(448));

	// Logo_Icon
	this.instance_204 = new lib.logoicon2("synched",0);
	this.instance_204.setTransform(462.3,747.45,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_204._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_204).wait(4500).to({_off:false},0).to({_off:true},343).wait(435));

	// Text_Rebates
	this.instance_205 = new lib.textrebates("synched",0);
	this.instance_205.setTransform(1309.1,545.35,0.9025,0.9025,0,0,0,40.6,94.7);
	this.instance_205.alpha = 0;
	this.instance_205._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_205).wait(4454).to({_off:false},0).to({regX:40.7,regY:94.5,x:1293.85,y:552.9,alpha:1},10).to({_off:true},717).wait(97));

	// Line_Blue
	this.instance_206 = new lib.CachedBmp_4215();
	this.instance_206.setTransform(1411.5,458.6,0.5,0.5);

	this.instance_207 = new lib.CachedBmp_4216();
	this.instance_207.setTransform(1402.35,458.6,0.5,0.5);

	this.instance_208 = new lib.CachedBmp_4217();
	this.instance_208.setTransform(1393.25,458.6,0.5,0.5);

	this.instance_209 = new lib.CachedBmp_4218();
	this.instance_209.setTransform(1384.1,458.6,0.5,0.5);

	this.instance_210 = new lib.CachedBmp_4219();
	this.instance_210.setTransform(1374.95,458.6,0.5,0.5);

	this.instance_211 = new lib.CachedBmp_4220();
	this.instance_211.setTransform(1365.85,458.6,0.5,0.5);

	this.instance_212 = new lib.CachedBmp_4221();
	this.instance_212.setTransform(1356.7,458.6,0.5,0.5);

	this.instance_213 = new lib.CachedBmp_4222();
	this.instance_213.setTransform(1347.55,458.6,0.5,0.5);

	this.instance_214 = new lib.CachedBmp_4223();
	this.instance_214.setTransform(1338.45,458.6,0.5,0.5);

	this.instance_215 = new lib.CachedBmp_4224();
	this.instance_215.setTransform(1329.3,458.6,0.5,0.5);

	this.instance_216 = new lib.CachedBmp_4225();
	this.instance_216.setTransform(1320.15,458.6,0.5,0.5);

	this.instance_217 = new lib.CachedBmp_4226();
	this.instance_217.setTransform(1311.05,458.6,0.5,0.5);

	this.instance_218 = new lib.CachedBmp_4227();
	this.instance_218.setTransform(1301.9,458.6,0.5,0.5);

	this.instance_219 = new lib.CachedBmp_4228();
	this.instance_219.setTransform(1292.75,458.6,0.5,0.5);

	this.instance_220 = new lib.CachedBmp_4229();
	this.instance_220.setTransform(1283.65,458.6,0.5,0.5);

	this.instance_221 = new lib.CachedBmp_4230();
	this.instance_221.setTransform(1274.5,458.6,0.5,0.5);

	this.instance_222 = new lib.CachedBmp_4231();
	this.instance_222.setTransform(1265.35,458.6,0.5,0.5);

	this.instance_223 = new lib.CachedBmp_4232();
	this.instance_223.setTransform(1256.25,458.6,0.5,0.5);

	this.instance_224 = new lib.CachedBmp_4233();
	this.instance_224.setTransform(1247.1,458.6,0.5,0.5);

	this.instance_225 = new lib.CachedBmp_4234();
	this.instance_225.setTransform(1237.95,458.6,0.5,0.5);

	this.instance_226 = new lib.CachedBmp_4235();
	this.instance_226.setTransform(1228.85,458.6,0.5,0.5);

	this.instance_227 = new lib.CachedBmp_4236();
	this.instance_227.setTransform(1219.7,458.6,0.5,0.5);

	this.instance_228 = new lib.CachedBmp_4237();
	this.instance_228.setTransform(1210.55,458.6,0.5,0.5);

	this.instance_229 = new lib.CachedBmp_4238();
	this.instance_229.setTransform(1201.45,458.6,0.5,0.5);

	this.instance_230 = new lib.CachedBmp_4239();
	this.instance_230.setTransform(1192.3,458.6,0.5,0.5);

	this.instance_231 = new lib.CachedBmp_4240();
	this.instance_231.setTransform(1183.15,458.6,0.5,0.5);

	this.instance_232 = new lib.CachedBmp_4241();
	this.instance_232.setTransform(1174.05,458.6,0.5,0.5);

	this.instance_233 = new lib.CachedBmp_4242();
	this.instance_233.setTransform(1164.9,458.6,0.5,0.5);

	this.instance_234 = new lib.CachedBmp_4243();
	this.instance_234.setTransform(1155.75,458.6,0.5,0.5);

	this.instance_235 = new lib.CachedBmp_4244();
	this.instance_235.setTransform(1146.65,458.6,0.5,0.5);

	this.instance_236 = new lib.CachedBmp_4245();
	this.instance_236.setTransform(1137.5,458.6,0.5,0.5);

	this.instance_237 = new lib.CachedBmp_4246();
	this.instance_237.setTransform(1126.3,458.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_206}]},4424).to({state:[{t:this.instance_207}]},1).to({state:[{t:this.instance_208}]},1).to({state:[{t:this.instance_209}]},1).to({state:[{t:this.instance_210}]},1).to({state:[{t:this.instance_211}]},1).to({state:[{t:this.instance_212}]},1).to({state:[{t:this.instance_213}]},1).to({state:[{t:this.instance_214}]},1).to({state:[{t:this.instance_215}]},1).to({state:[{t:this.instance_216}]},1).to({state:[{t:this.instance_217}]},1).to({state:[{t:this.instance_218}]},1).to({state:[{t:this.instance_219}]},1).to({state:[{t:this.instance_220}]},1).to({state:[{t:this.instance_221}]},1).to({state:[{t:this.instance_222}]},1).to({state:[{t:this.instance_223}]},1).to({state:[{t:this.instance_224}]},1).to({state:[{t:this.instance_225}]},1).to({state:[{t:this.instance_226}]},1).to({state:[{t:this.instance_227}]},1).to({state:[{t:this.instance_228}]},1).to({state:[{t:this.instance_229}]},1).to({state:[{t:this.instance_230}]},1).to({state:[{t:this.instance_231}]},1).to({state:[{t:this.instance_232}]},1).to({state:[{t:this.instance_233}]},1).to({state:[{t:this.instance_234}]},1).to({state:[{t:this.instance_235}]},1).to({state:[{t:this.instance_236}]},1).to({state:[{t:this.instance_237}]},1).to({state:[]},726).wait(97));

	// Line_Blue
	this.instance_238 = new lib.CachedBmp_4247();
	this.instance_238.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_239 = new lib.CachedBmp_4248();
	this.instance_239.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_240 = new lib.CachedBmp_4249();
	this.instance_240.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_241 = new lib.CachedBmp_4250();
	this.instance_241.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_242 = new lib.CachedBmp_4251();
	this.instance_242.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_243 = new lib.CachedBmp_4252();
	this.instance_243.setTransform(1361.15,426.5,0.5,0.5);

	this.instance_244 = new lib.CachedBmp_4253();
	this.instance_244.setTransform(1361.1,426.5,0.5,0.5);

	this.instance_245 = new lib.CachedBmp_4254();
	this.instance_245.setTransform(1361.1,426.5,0.5,0.5);

	this.instance_246 = new lib.CachedBmp_4255();
	this.instance_246.setTransform(1361.1,426.5,0.5,0.5);

	this.instance_247 = new lib.CachedBmp_4256();
	this.instance_247.setTransform(1361.1,426.5,0.5,0.5);

	this.instance_248 = new lib.CachedBmp_4257();
	this.instance_248.setTransform(1361.1,426.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_238}]},4414).to({state:[{t:this.instance_239}]},1).to({state:[{t:this.instance_240}]},1).to({state:[{t:this.instance_241}]},1).to({state:[{t:this.instance_242}]},1).to({state:[{t:this.instance_243}]},1).to({state:[{t:this.instance_244}]},1).to({state:[{t:this.instance_245}]},1).to({state:[{t:this.instance_246}]},1).to({state:[{t:this.instance_247}]},1).to({state:[{t:this.instance_248}]},1).to({state:[]},757).wait(97));

	// txt
	this.instance_249 = new lib.Symbol21("synched",0);
	this.instance_249.setTransform(455.6,549.5,1,1,0,0,0,119.9,56.9);
	this.instance_249.alpha = 0;
	this.instance_249._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_249).wait(4314).to({_off:false},0).to({y:559.5,alpha:1},10).wait(165).to({startPosition:0},0).to({y:549.5,alpha:0},10).to({_off:true},1).wait(778));

	// Speech_Bubble
	this.instance_250 = new lib.speechbubble2("synched",0);
	this.instance_250.setTransform(462.45,681.4,1.4925,1.4925,0,0,0,227.6,236);
	this.instance_250._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_250).wait(4299).to({_off:false},0).to({y:691.4},15).wait(175).to({startPosition:0},0).to({startPosition:0},10).to({_off:true},1).wait(778));

	// Logo_Icon
	this.instance_251 = new lib.logoicon2("synched",0);
	this.instance_251.setTransform(1261.3,879.4,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_251._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_251).wait(4239).to({_off:false},0).to({x:462.3,y:747.45},60,cjs.Ease.get(0.5)).to({_off:true},201).wait(778));

	// Text_Commissions
	this.instance_252 = new lib.textcommissions("synched",0);
	this.instance_252.setTransform(1430.8,316.4,0.9025,0.9025,0,0,0,40.6,94.7);
	this.instance_252.alpha = 0;
	this.instance_252._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_252).wait(4189).to({_off:false},0).to({alpha:1},10).to({_off:true},982).wait(97));

	// Text_Banks
	this.instance_253 = new lib.textbanks("synched",0);
	this.instance_253.setTransform(1579.5,323.35,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_253.alpha = 0;
	this.instance_253._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_253).wait(4162).to({_off:false},0).to({alpha:1},27).to({_off:true},992).wait(97));

	// Img_Banks
	this.instance_254 = new lib.banks("synched",0);
	this.instance_254.setTransform(1542.25,267.7,0.9025,0.9025,0,0,0,94.5,91.5);
	this.instance_254.alpha = 0;
	this.instance_254._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_254).wait(4157).to({_off:false},0).to({y:279.8,alpha:1},26).to({y:276.25},6).to({_off:true},992).wait(97));

	// Line_Pink
	this.instance_255 = new lib.CachedBmp_4258();
	this.instance_255.setTransform(1449.5,272.1,0.5,0.5);

	this.instance_256 = new lib.CachedBmp_4259();
	this.instance_256.setTransform(1443.8,272.1,0.5,0.5);

	this.instance_257 = new lib.CachedBmp_4260();
	this.instance_257.setTransform(1438.05,272.1,0.5,0.5);

	this.instance_258 = new lib.CachedBmp_4261();
	this.instance_258.setTransform(1432.35,272.1,0.5,0.5);

	this.instance_259 = new lib.CachedBmp_4262();
	this.instance_259.setTransform(1426.65,272.1,0.5,0.5);

	this.instance_260 = new lib.CachedBmp_4263();
	this.instance_260.setTransform(1420.95,272.1,0.5,0.5);

	this.instance_261 = new lib.CachedBmp_4264();
	this.instance_261.setTransform(1415.25,272.1,0.5,0.5);

	this.instance_262 = new lib.CachedBmp_4265();
	this.instance_262.setTransform(1409.5,272.1,0.5,0.5);

	this.instance_263 = new lib.CachedBmp_4266();
	this.instance_263.setTransform(1403.8,272.1,0.5,0.5);

	this.instance_264 = new lib.CachedBmp_4267();
	this.instance_264.setTransform(1398.1,272.1,0.5,0.5);

	this.instance_265 = new lib.CachedBmp_4268();
	this.instance_265.setTransform(1392.4,272.1,0.5,0.5);

	this.instance_266 = new lib.CachedBmp_4269();
	this.instance_266.setTransform(1386.65,272.1,0.5,0.5);

	this.instance_267 = new lib.CachedBmp_4270();
	this.instance_267.setTransform(1380.95,272.1,0.5,0.5);

	this.instance_268 = new lib.CachedBmp_4271();
	this.instance_268.setTransform(1371.5,272.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_255}]},4144).to({state:[{t:this.instance_256}]},1).to({state:[{t:this.instance_257}]},1).to({state:[{t:this.instance_258}]},1).to({state:[{t:this.instance_259}]},1).to({state:[{t:this.instance_260}]},1).to({state:[{t:this.instance_261}]},1).to({state:[{t:this.instance_262}]},1).to({state:[{t:this.instance_263}]},1).to({state:[{t:this.instance_264}]},1).to({state:[{t:this.instance_265}]},1).to({state:[{t:this.instance_266}]},1).to({state:[{t:this.instance_267}]},1).to({state:[{t:this.instance_268}]},1).to({state:[]},1024).wait(97));

	// Text_LP_s
	this.instance_269 = new lib.textlp("synched",0);
	this.instance_269.setTransform(1412.6,162.7,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_269.alpha = 0;
	this.instance_269._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_269).wait(4134).to({_off:false},0).to({alpha:1},10).to({_off:true},1037).wait(97));

	// Img_LP_s
	this.instance_270 = new lib.liquidityproviders("synched",0);
	this.instance_270.setTransform(1439.3,203.2,0.9025,0.9025,0,0,0,154.5,187.6);
	this.instance_270.alpha = 0;
	this.instance_270._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_270).wait(4129).to({_off:false},0).to({regY:187.4,y:211.15,alpha:1},10).to({regY:187.6,y:207.7},5).to({_off:true},1037).wait(97));

	// Line_Blue
	this.instance_271 = new lib.CachedBmp_4272();
	this.instance_271.setTransform(1377.05,313.7,0.5,0.5);

	this.instance_272 = new lib.CachedBmp_4273();
	this.instance_272.setTransform(1377.05,310.25,0.5,0.5);

	this.instance_273 = new lib.CachedBmp_4274();
	this.instance_273.setTransform(1377.05,306.85,0.5,0.5);

	this.instance_274 = new lib.CachedBmp_4275();
	this.instance_274.setTransform(1377.05,303.4,0.5,0.5);

	this.instance_275 = new lib.CachedBmp_4276();
	this.instance_275.setTransform(1377.05,299.95,0.5,0.5);

	this.instance_276 = new lib.CachedBmp_4277();
	this.instance_276.setTransform(1377.05,296.55,0.5,0.5);

	this.instance_277 = new lib.CachedBmp_4278();
	this.instance_277.setTransform(1377.05,293.1,0.5,0.5);

	this.instance_278 = new lib.CachedBmp_4279();
	this.instance_278.setTransform(1377.05,289.65,0.5,0.5);

	this.instance_279 = new lib.CachedBmp_4280();
	this.instance_279.setTransform(1377.05,286.2,0.5,0.5);

	this.instance_280 = new lib.CachedBmp_4281();
	this.instance_280.setTransform(1377.05,282.8,0.5,0.5);

	this.instance_281 = new lib.CachedBmp_4282();
	this.instance_281.setTransform(1377.05,279.35,0.5,0.5);

	this.instance_282 = new lib.CachedBmp_4283();
	this.instance_282.setTransform(1377,273.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_271}]},4119).to({state:[{t:this.instance_272}]},1).to({state:[{t:this.instance_273}]},1).to({state:[{t:this.instance_274}]},1).to({state:[{t:this.instance_275}]},1).to({state:[{t:this.instance_276}]},1).to({state:[{t:this.instance_277}]},1).to({state:[{t:this.instance_278}]},1).to({state:[{t:this.instance_279}]},1).to({state:[{t:this.instance_280}]},1).to({state:[{t:this.instance_281}]},1).to({state:[{t:this.instance_282}]},1).to({state:[]},1051).wait(97));

	// txt
	this.instance_283 = new lib.Symbol20("synched",0);
	this.instance_283.setTransform(1254.1,656.2,1,1,0,0,0,146.1,70.6);
	this.instance_283.alpha = 0;
	this.instance_283._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_283).wait(3989).to({_off:false},0).to({y:666.2,alpha:1},10).wait(230).to({startPosition:0},0).to({y:656.2,alpha:0},10).to({_off:true},1).wait(1038));

	// Speech_Bubble
	this.instance_284 = new lib.speechbubble2("synched",0);
	this.instance_284.setTransform(1259.9,812.95,1.7336,1.7336,0,0,0,227.6,236);
	this.instance_284._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_284).wait(3979).to({_off:false},0).to({y:822.95},10).wait(240).to({startPosition:0},0).to({y:812.95},10).to({_off:true},1).wait(1038));

	// Logo_Icon
	this.instance_285 = new lib.logoicon2("synched",0);
	this.instance_285.setTransform(520.15,510.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_285._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_285).wait(3941).to({_off:false},0).to({x:1261.3,y:879.4},38).to({_off:true},260).wait(1039));

	// txt
	this.instance_286 = new lib.Tween4("synched",0);
	this.instance_286.setTransform(518.2,283.1);
	this.instance_286.alpha = 0;
	this.instance_286._off = true;

	this.instance_287 = new lib.Tween5("synched",0);
	this.instance_287.setTransform(518.2,293.1);
	this.instance_287._off = true;

	this.instance_288 = new lib.Symbol17("synched",0);
	this.instance_288.setTransform(512.25,285.8,1,1,0,0,0,142.8,70.6);
	this.instance_288.alpha = 0;
	this.instance_288._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_286).wait(3589).to({_off:false},0).to({_off:true,y:293.1,alpha:1},11).wait(100).to({_off:false,y:283.1,alpha:0},10).to({_off:true},1).wait(1567));
	this.timeline.addTween(cjs.Tween.get(this.instance_287).wait(3589).to({_off:false},11).wait(100).to({startPosition:0},0).to({_off:true,y:283.1,alpha:0},10).wait(1568));
	this.timeline.addTween(cjs.Tween.get(this.instance_288).wait(3725).to({_off:false},0).to({y:295.8,alpha:1},10).wait(180).to({startPosition:0},0).to({y:285.8,alpha:0},10).to({_off:true},1).wait(1352));

	// Layer_10
	this.instance_289 = new lib.thumbsup("synched",0);
	this.instance_289.setTransform(617.35,337.35,1,1,-8.7478,0,0,0.1,139.6);
	this.instance_289.alpha = 0;
	this.instance_289._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_289).wait(3600).to({_off:false},0).to({regX:0,regY:139.5,rotation:0,x:617.25,y:337.3,alpha:1},10).wait(90).to({startPosition:0},0).to({regX:0.1,regY:139.6,rotation:-8.7478,x:617.35,y:337.35,alpha:0},10).wait(1568));

	// Speech_Bubble
	this.instance_290 = new lib.speechbubble2("synched",0);
	this.instance_290.setTransform(518.75,443.65,1.7336,1.7336,0,0,0,227.6,236);
	this.instance_290._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_290).wait(3579).to({_off:false},0).to({y:453.65},10).wait(326).to({startPosition:0},0).to({y:443.65},10).to({_off:true},1).wait(1352));

	// Logo_Icon
	this.instance_291 = new lib.logoicon2("synched",0);
	this.instance_291.setTransform(520.15,510.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_291._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_291).wait(3540).to({_off:false},0).wait(400).to({startPosition:0},0).to({_off:true},1).wait(1337));

	// txt
	this.instance_292 = new lib.Symbol16("synched",0);
	this.instance_292.setTransform(512.2,284.1,1,1,0,0,0,174.2,56.9);
	this.instance_292.alpha = 0;
	this.instance_292._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_292).wait(3354).to({_off:false},0).to({y:294.1,alpha:1},10).wait(165).to({startPosition:0},0).to({y:284.1,alpha:0},10).to({_off:true},1).wait(1738));

	// Speech_Bubble
	this.instance_293 = new lib.speechbubble2("synched",0);
	this.instance_293.setTransform(518.75,443.65,1.7336,1.7336,0,0,0,227.6,236);
	this.instance_293._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_293).wait(3344).to({_off:false},0).to({y:453.65},10).wait(175).to({startPosition:0},0).to({y:443.65},10).to({_off:true},1).wait(1738));

	// Logo_Icon
	this.instance_294 = new lib.logoicon2("synched",0);
	this.instance_294.setTransform(520.15,850.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_294._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_294).wait(3290).to({_off:false},0).to({y:510.1},54,cjs.Ease.get(0.5)).to({_off:true},196).wait(1738));

	// txt
	this.instance_295 = new lib.Symbol15("synched",0);
	this.instance_295.setTransform(512.2,606.8,1,1,0,0,0,188,70.6);
	this.instance_295.alpha = 0;
	this.instance_295._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_295).wait(3025).to({_off:false},0).to({y:616.8,alpha:1},10).wait(244).to({startPosition:0},0).to({y:606.8,alpha:0},10).to({_off:true},1).wait(1988));

	// Speech_Bubble
	this.instance_296 = new lib.speechbubble2("synched",0);
	this.instance_296.setTransform(518.75,783.7,1.97,1.97,0,0,0,227.6,236);
	this.instance_296._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_296).wait(3015).to({_off:false},0).to({y:793.7},10).wait(254).to({startPosition:0},0).to({y:783.7},10).to({_off:true},1).wait(1988));

	// Logo_Icon
	this.instance_297 = new lib.logoicon2("synched",0);
	this.instance_297.setTransform(1310.15,850.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_297._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_297).wait(2970).to({_off:false},0).to({x:520.15},45,cjs.Ease.get(0.5)).to({_off:true},275).wait(1988));

	// tooltip
	this.instance_298 = new lib.CachedBmp_4285();
	this.instance_298.setTransform(498.7,979.8,0.5,0.5);

	this.instance_299 = new lib.CachedBmp_4284();
	this.instance_299.setTransform(466.8,969,0.5,0.5);

	this.instance_300 = new lib.CachedBmp_4287();
	this.instance_300.setTransform(499.7,943.8,0.5,0.5);

	this.instance_301 = new lib.CachedBmp_4286();
	this.instance_301.setTransform(467.25,927.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_299},{t:this.instance_298}]},2504).to({state:[]},205).to({state:[{t:this.instance_301},{t:this.instance_300}]},44).to({state:[]},206).to({state:[]},2222).wait(97));

	// txt
	this.instance_302 = new lib.Symbol13("synched",0);
	this.instance_302.setTransform(1309.2,648.1,1,1,0,0,0,119.4,56.9);
	this.instance_302.alpha = 0;
	this.instance_302._off = true;

	this.instance_303 = new lib.Symbol14("synched",0);
	this.instance_303.setTransform(1310.2,649.1,1,1,0,0,0,142.1,56.9);
	this.instance_303.alpha = 0;
	this.instance_303._off = true;

	this.instance_304 = new lib.Tween2("synched",0);
	this.instance_304.setTransform(1310.2,636.8);
	this.instance_304.alpha = 0;
	this.instance_304._off = true;

	this.instance_305 = new lib.Tween3("synched",0);
	this.instance_305.setTransform(1310.2,646.8);
	this.instance_305._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_302).wait(2289).to({_off:false},0).to({y:658.1,alpha:1},10).wait(170).to({startPosition:0},0).to({y:648.1,alpha:0},10).to({_off:true},1).wait(2798));
	this.timeline.addTween(cjs.Tween.get(this.instance_303).wait(2494).to({_off:false},0).to({y:659.1,alpha:1},10).wait(205).to({startPosition:0},0).to({y:649.1,alpha:0},10).to({_off:true},1).wait(2558));
	this.timeline.addTween(cjs.Tween.get(this.instance_304).wait(2743).to({_off:false},0).to({_off:true,y:646.8,alpha:1},10).wait(2525));
	this.timeline.addTween(cjs.Tween.get(this.instance_305).wait(2743).to({_off:false},10).wait(206).to({startPosition:0},0).to({y:636.8,alpha:0},10).to({_off:true},1).wait(2308));

	// Speech_Bubble
	this.instance_306 = new lib.speechbubble2("synched",0);
	this.instance_306.setTransform(1309.75,783.6,1.4925,1.4925,0,0,0,227.6,236);
	this.instance_306._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_306).wait(2279).to({_off:false},0).to({y:793.6},10).wait(444).to({startPosition:0},0).to({scaleX:1.6417,scaleY:1.6417,y:793.65},10).wait(216).to({startPosition:0},0).to({y:783.65},10).to({_off:true},1).wait(2308));

	// Logo_Icon
	this.instance_307 = new lib.logoicon2("synched",0);
	this.instance_307.setTransform(1310.15,850.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_307._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_307).wait(2279).to({_off:false},0).to({_off:true},691).wait(2308));

	// Text_Managed_Fund
	this.instance_308 = new lib.managedfund("synched",0);
	this.instance_308.setTransform(1164.05,228.5,0.9025,0.9025,0,0,0,62.6,36.1);
	this.instance_308.alpha = 0;
	this.instance_308._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_308).wait(2027).to({_off:false},0).to({x:1159.5,y:233.05,alpha:1},11).to({_off:true},3143).wait(97));

	// Line_Orange
	this.instance_309 = new lib.CachedBmp_4288();
	this.instance_309.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_310 = new lib.CachedBmp_4289();
	this.instance_310.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_311 = new lib.CachedBmp_4290();
	this.instance_311.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_312 = new lib.CachedBmp_4291();
	this.instance_312.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_313 = new lib.CachedBmp_4292();
	this.instance_313.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_314 = new lib.CachedBmp_4293();
	this.instance_314.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_315 = new lib.CachedBmp_4294();
	this.instance_315.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_316 = new lib.CachedBmp_4295();
	this.instance_316.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_317 = new lib.CachedBmp_4296();
	this.instance_317.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_318 = new lib.CachedBmp_4297();
	this.instance_318.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_319 = new lib.CachedBmp_4298();
	this.instance_319.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_320 = new lib.CachedBmp_4299();
	this.instance_320.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_321 = new lib.CachedBmp_4300();
	this.instance_321.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_322 = new lib.CachedBmp_4301();
	this.instance_322.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_323 = new lib.CachedBmp_4302();
	this.instance_323.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_324 = new lib.CachedBmp_4303();
	this.instance_324.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_325 = new lib.CachedBmp_4304();
	this.instance_325.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_326 = new lib.CachedBmp_4305();
	this.instance_326.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_327 = new lib.CachedBmp_4306();
	this.instance_327.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_328 = new lib.CachedBmp_4307();
	this.instance_328.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_329 = new lib.CachedBmp_4308();
	this.instance_329.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_330 = new lib.CachedBmp_4309();
	this.instance_330.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_331 = new lib.CachedBmp_4310();
	this.instance_331.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_332 = new lib.CachedBmp_4311();
	this.instance_332.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_333 = new lib.CachedBmp_4312();
	this.instance_333.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_334 = new lib.CachedBmp_4313();
	this.instance_334.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_335 = new lib.CachedBmp_4314();
	this.instance_335.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_336 = new lib.CachedBmp_4315();
	this.instance_336.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_337 = new lib.CachedBmp_4316();
	this.instance_337.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_338 = new lib.CachedBmp_4317();
	this.instance_338.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_339 = new lib.CachedBmp_4318();
	this.instance_339.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_340 = new lib.CachedBmp_4319();
	this.instance_340.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_341 = new lib.CachedBmp_4320();
	this.instance_341.setTransform(1082.7,199.15,0.5,0.5);

	this.instance_342 = new lib.CachedBmp_4321();
	this.instance_342.setTransform(1082.65,199.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_309}]},1994).to({state:[{t:this.instance_310}]},1).to({state:[{t:this.instance_311}]},1).to({state:[{t:this.instance_312}]},1).to({state:[{t:this.instance_313}]},1).to({state:[{t:this.instance_314}]},1).to({state:[{t:this.instance_315}]},1).to({state:[{t:this.instance_316}]},1).to({state:[{t:this.instance_317}]},1).to({state:[{t:this.instance_318}]},1).to({state:[{t:this.instance_319}]},1).to({state:[{t:this.instance_320}]},1).to({state:[{t:this.instance_321}]},1).to({state:[{t:this.instance_322}]},1).to({state:[{t:this.instance_323}]},1).to({state:[{t:this.instance_324}]},1).to({state:[{t:this.instance_325}]},1).to({state:[{t:this.instance_326}]},1).to({state:[{t:this.instance_327}]},1).to({state:[{t:this.instance_328}]},1).to({state:[{t:this.instance_329}]},1).to({state:[{t:this.instance_330}]},1).to({state:[{t:this.instance_331}]},1).to({state:[{t:this.instance_332}]},1).to({state:[{t:this.instance_333}]},1).to({state:[{t:this.instance_334}]},1).to({state:[{t:this.instance_335}]},1).to({state:[{t:this.instance_336}]},1).to({state:[{t:this.instance_337}]},1).to({state:[{t:this.instance_338}]},1).to({state:[{t:this.instance_339}]},1).to({state:[{t:this.instance_340}]},1).to({state:[{t:this.instance_341}]},1).to({state:[{t:this.instance_342}]},1).to({state:[]},3154).wait(97));

	// Dot_Orange
	this.instance_343 = new lib.dotorange("synched",0);
	this.instance_343.setTransform(1083.55,199.9,0.2707,0.2707,0,0,0,7.8,4.3);
	this.instance_343._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_343).wait(1984).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:1083.6,y:199.95},5).to({regY:4.5,scaleX:0.6552,scaleY:0.6552,y:199.9},5).to({_off:true},3187).wait(97));

	// Text_Broker
	this.instance_344 = new lib.textbroker("synched",0);
	this.instance_344.setTransform(1245.35,471.4,0.9025,0.9025,0,0,0,40.7,94.7);
	this.instance_344.alpha = 0;
	this.instance_344._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_344).wait(1969).to({_off:false},0).to({y:451.55,alpha:1},10).to({_off:true},3202).wait(97));

	// Img_Broker
	this.instance_345 = new lib.broker("synched",0);
	this.instance_345.setTransform(1323.9,347.55,0.9025,0.9025,0,0,0,61.9,82.8);
	this.instance_345.alpha = 0;
	this.instance_345._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_345).wait(1969).to({_off:false},0).to({y:356.7,alpha:1},10).to({y:352.05},5).to({_off:true},3197).wait(97));

	// tooltip
	this.instance_346 = new lib.CachedBmp_4323();
	this.instance_346.setTransform(555.95,979.8,0.5,0.5);

	this.instance_347 = new lib.CachedBmp_4322();
	this.instance_347.setTransform(524.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_347},{t:this.instance_346}]},1859).to({state:[]},239).to({state:[]},3083).wait(97));

	// txt
	this.instance_348 = new lib.Symbol11("synched",0);
	this.instance_348.setTransform(1310.2,648.3,1,1,0,0,0,108.3,43.1);
	this.instance_348.alpha = 0;
	this.instance_348._off = true;

	this.instance_349 = new lib.Symbol12("synched",0);
	this.instance_349.setTransform(1310.25,649.6,1,1,0,0,0,130.1,29.4);
	this.instance_349.alpha = 0;
	this.instance_349._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_348).wait(1849).to({_off:false},0).to({y:658.3,alpha:1},10).wait(239).to({startPosition:0},0).to({y:648.3,alpha:0},10).to({_off:true},1).wait(3169));
	this.timeline.addTween(cjs.Tween.get(this.instance_349).wait(2124).to({_off:false},0).to({y:659.6,alpha:1},10).wait(105).to({startPosition:0},0).to({y:649.6,alpha:0},10).to({_off:true},1).wait(3028));

	// Speech_Bubble_6
	this.instance_350 = new lib.speechbubble2("synched",0);
	this.instance_350.setTransform(1309.75,783.6,1.4925,1.4925,0,0,0,227.6,236);
	this.instance_350._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_350).wait(1834).to({_off:false},0).to({y:793.6},15).to({_off:true},430).wait(2999));

	// Logo_Icon
	this.instance_351 = new lib.logoicon2("synched",0);
	this.instance_351.setTransform(1310.15,587.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_351._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_351).wait(1804).to({_off:false},0).to({y:850.1},30,cjs.Ease.get(0.5)).to({_off:true},445).wait(2999));

	// Img_Funds
	this.instance_352 = new lib.funds("synched",0);
	this.instance_352.setTransform(1003.6,155.75,1.083,1.083,0,0,0,60,52.2);
	this.instance_352.alpha = 0;
	this.instance_352._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_352).wait(1699).to({_off:false},0).to({regY:52.3,y:170.85,alpha:1},10).to({regY:52.2,y:166.15},5).to({_off:true},3467).wait(97));

	// Line_Pink
	this.instance_353 = new lib.CachedBmp_4324();
	this.instance_353.setTransform(1074.8,260.3,0.5,0.5);

	this.instance_354 = new lib.CachedBmp_4325();
	this.instance_354.setTransform(1064.6,254.65,0.5,0.5);

	this.instance_355 = new lib.CachedBmp_4326();
	this.instance_355.setTransform(1054.45,249,0.5,0.5);

	this.instance_356 = new lib.CachedBmp_4327();
	this.instance_356.setTransform(1044.25,243.35,0.5,0.5);

	this.instance_357 = new lib.CachedBmp_4328();
	this.instance_357.setTransform(1034.1,237.7,0.5,0.5);

	this.instance_358 = new lib.CachedBmp_4329();
	this.instance_358.setTransform(1023.9,232.05,0.5,0.5);

	this.instance_359 = new lib.CachedBmp_4330();
	this.instance_359.setTransform(1025.75,232.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_353}]},1694).to({state:[{t:this.instance_354}]},1).to({state:[{t:this.instance_355}]},1).to({state:[{t:this.instance_356}]},1).to({state:[{t:this.instance_357}]},1).to({state:[{t:this.instance_358}]},1).to({state:[{t:this.instance_359}]},1).to({state:[]},3481).wait(97));

	// Line_Pink
	this.instance_360 = new lib.CachedBmp_4331();
	this.instance_360.setTransform(904.25,361.7,0.5,0.5);

	this.instance_361 = new lib.CachedBmp_4332();
	this.instance_361.setTransform(904.25,355.15,0.5,0.5);

	this.instance_362 = new lib.CachedBmp_4333();
	this.instance_362.setTransform(904.25,348.6,0.5,0.5);

	this.instance_363 = new lib.CachedBmp_4334();
	this.instance_363.setTransform(904.25,342,0.5,0.5);

	this.instance_364 = new lib.CachedBmp_4335();
	this.instance_364.setTransform(904.25,335.45,0.5,0.5);

	this.instance_365 = new lib.CachedBmp_4336();
	this.instance_365.setTransform(904.25,328.9,0.5,0.5);

	this.instance_366 = new lib.CachedBmp_4337();
	this.instance_366.setTransform(904.25,322.35,0.5,0.5);

	this.instance_367 = new lib.CachedBmp_4338();
	this.instance_367.setTransform(904.25,315.8,0.5,0.5);

	this.instance_368 = new lib.CachedBmp_4339();
	this.instance_368.setTransform(904.25,309.2,0.5,0.5);

	this.instance_369 = new lib.CachedBmp_4340();
	this.instance_369.setTransform(904.25,302.65,0.5,0.5);

	this.instance_370 = new lib.CachedBmp_4341();
	this.instance_370.setTransform(904.25,296.1,0.5,0.5);

	this.instance_371 = new lib.CachedBmp_4342();
	this.instance_371.setTransform(904.25,289.55,0.5,0.5);

	this.instance_372 = new lib.CachedBmp_4343();
	this.instance_372.setTransform(904.25,283,0.5,0.5);

	this.instance_373 = new lib.CachedBmp_4344();
	this.instance_373.setTransform(904.25,276.4,0.5,0.5);

	this.instance_374 = new lib.CachedBmp_4345();
	this.instance_374.setTransform(904.25,269.85,0.5,0.5);

	this.instance_375 = new lib.CachedBmp_4346();
	this.instance_375.setTransform(904.25,263.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_360}]},1679).to({state:[{t:this.instance_361}]},1).to({state:[{t:this.instance_362}]},1).to({state:[{t:this.instance_363}]},1).to({state:[{t:this.instance_364}]},1).to({state:[{t:this.instance_365}]},1).to({state:[{t:this.instance_366}]},1).to({state:[{t:this.instance_367}]},1).to({state:[{t:this.instance_368}]},1).to({state:[{t:this.instance_369}]},1).to({state:[{t:this.instance_370}]},1).to({state:[{t:this.instance_371}]},1).to({state:[{t:this.instance_372}]},1).to({state:[{t:this.instance_373}]},1).to({state:[{t:this.instance_374}]},1).to({state:[{t:this.instance_375}]},1).to({state:[]},3487).wait(97));

	// Line_Pink
	this.instance_376 = new lib.CachedBmp_4347();
	this.instance_376.setTransform(904.2,392.1,0.5,0.5);

	this.instance_377 = new lib.CachedBmp_4348();
	this.instance_377.setTransform(904.2,386.45,0.5,0.5);

	this.instance_378 = new lib.CachedBmp_4349();
	this.instance_378.setTransform(904.2,380.75,0.5,0.5);

	this.instance_379 = new lib.CachedBmp_4350();
	this.instance_379.setTransform(904.2,375.1,0.5,0.5);

	this.instance_380 = new lib.CachedBmp_4351();
	this.instance_380.setTransform(904.2,369.4,0.5,0.5);

	this.instance_381 = new lib.CachedBmp_4352();
	this.instance_381.setTransform(904.2,363.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_376}]},1674).to({state:[{t:this.instance_377}]},1).to({state:[{t:this.instance_378}]},1).to({state:[{t:this.instance_379}]},1).to({state:[{t:this.instance_380}]},1).to({state:[{t:this.instance_381}]},1).to({state:[]},3502).wait(97));

	// Dots_Pink
	this.instance_382 = new lib.dotpink("synched",0);
	this.instance_382.setTransform(905.3,397.25,0.1733,0.1733,0,0,0,7.5,4.4);
	this.instance_382._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_382).wait(1659).to({_off:false},0).to({regX:7.6,scaleX:0.5856,scaleY:0.5856,y:397.3},10).to({regX:7.4,scaleX:0.4193,scaleY:0.4193,y:397.25},5).to({_off:true},3507).wait(97));

	// tooltip
	this.instance_383 = new lib.CachedBmp_4354();
	this.instance_383.setTransform(498.9,979.8,0.5,0.5);

	this.instance_384 = new lib.CachedBmp_4353();
	this.instance_384.setTransform(464.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_384},{t:this.instance_383}]},1554).to({state:[]},205).to({state:[]},3422).wait(97));

	// txt
	this.instance_385 = new lib.Symbol10("synched",0);
	this.instance_385.setTransform(1297.45,386.15,1,1,0,0,0,134.8,43.1);
	this.instance_385.alpha = 0;
	this.instance_385._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_385).wait(1544).to({_off:false},0).to({y:396.15,alpha:1},10).wait(205).to({startPosition:0},0).to({y:386.15,alpha:0},15).to({_off:true},1).wait(3503));

	// Speech_Bubble5
	this.instance_386 = new lib.speechbubble2("synched",0);
	this.instance_386.setTransform(1310.4,388.35,1.4925,1.4925,0,0,0,233.4,146.7);
	this.instance_386._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_386).wait(1530).to({_off:false},0).to({y:398.35},14).wait(215).to({startPosition:0},0).to({y:388.35},15).to({_off:true},1).wait(3503));

	// Logo_Icon
	this.instance_387 = new lib.logoicon2("synched",0);
	this.instance_387.setTransform(410.15,587.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_387._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_387).wait(1469).to({_off:false},0).to({x:1310.15},61,cjs.Ease.get(0.5)).to({_off:true},274).wait(3474));

	// Img_Trading_Account
	this.instance_388 = new lib.tradingaccount("synched",0);
	this.instance_388.setTransform(986.45,377.4,0.9025,0.9025,0,0,0,145.7,119.7);
	this.instance_388.alpha = 0;
	this.instance_388._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_388).wait(1395).to({_off:false},0).to({x:976.55,y:367.5,alpha:1},14).to({_off:true},3772).wait(97));

	// Line_Blue
	this.instance_389 = new lib.CachedBmp_4355();
	this.instance_389.setTransform(786.6,494,0.5,0.5);

	this.instance_390 = new lib.CachedBmp_4356();
	this.instance_390.setTransform(786.6,489.8,0.5,0.5);

	this.instance_391 = new lib.CachedBmp_4357();
	this.instance_391.setTransform(786.6,485.65,0.5,0.5);

	this.instance_392 = new lib.CachedBmp_4358();
	this.instance_392.setTransform(786.6,481.45,0.5,0.5);

	this.instance_393 = new lib.CachedBmp_4359();
	this.instance_393.setTransform(786.6,477.25,0.5,0.5);

	this.instance_394 = new lib.CachedBmp_4360();
	this.instance_394.setTransform(786.6,473.05,0.5,0.5);

	this.instance_395 = new lib.CachedBmp_4361();
	this.instance_395.setTransform(786.6,468.9,0.5,0.5);

	this.instance_396 = new lib.CachedBmp_4362();
	this.instance_396.setTransform(786.6,464.7,0.5,0.5);

	this.instance_397 = new lib.CachedBmp_4363();
	this.instance_397.setTransform(786.6,460.5,0.5,0.5);

	this.instance_398 = new lib.CachedBmp_4364();
	this.instance_398.setTransform(786.6,456.3,0.5,0.5);

	this.instance_399 = new lib.CachedBmp_4365();
	this.instance_399.setTransform(786.6,452.15,0.5,0.5);

	this.instance_400 = new lib.CachedBmp_4366();
	this.instance_400.setTransform(786.6,447.95,0.5,0.5);

	this.instance_401 = new lib.CachedBmp_4367();
	this.instance_401.setTransform(786.6,443.75,0.5,0.5);

	this.instance_402 = new lib.CachedBmp_4368();
	this.instance_402.setTransform(786.6,439.55,0.5,0.5);

	this.instance_403 = new lib.CachedBmp_4369();
	this.instance_403.setTransform(786.6,435.4,0.5,0.5);

	this.instance_404 = new lib.CachedBmp_4370();
	this.instance_404.setTransform(786.6,431.2,0.5,0.5);

	this.instance_405 = new lib.CachedBmp_4371();
	this.instance_405.setTransform(786.6,428.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_389}]},1379).to({state:[{t:this.instance_390}]},1).to({state:[{t:this.instance_391}]},1).to({state:[{t:this.instance_392}]},1).to({state:[{t:this.instance_393}]},1).to({state:[{t:this.instance_394}]},1).to({state:[{t:this.instance_395}]},1).to({state:[{t:this.instance_396}]},1).to({state:[{t:this.instance_397}]},1).to({state:[{t:this.instance_398}]},1).to({state:[{t:this.instance_399}]},1).to({state:[{t:this.instance_400}]},1).to({state:[{t:this.instance_401}]},1).to({state:[{t:this.instance_402}]},1).to({state:[{t:this.instance_403}]},1).to({state:[{t:this.instance_404}]},1).to({state:[{t:this.instance_405}]},1).to({state:[]},3786).wait(97));

	// Dot_Blue
	this.instance_406 = new lib.dotblue("synched",0);
	this.instance_406.setTransform(786.2,498.65,0.2707,0.2707,0,0,0,7.5,4.5);
	this.instance_406._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_406).wait(1364).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:786.25,y:498.7},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:786.15,y:498.65},5).to({_off:true},3802).wait(97));

	// tooltip
	this.instance_407 = new lib.CachedBmp_4373();
	this.instance_407.setTransform(575.1,979.8,0.5,0.5);

	this.instance_408 = new lib.CachedBmp_4372();
	this.instance_408.setTransform(544.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_408},{t:this.instance_407}]},1213).to({state:[]},241).to({state:[]},3727).wait(97));

	// txt
	this.instance_409 = new lib.Symbol9("synched",0);
	this.instance_409.setTransform(398.65,386.85,1,1,0,0,0,119.9,56.9);
	this.instance_409.alpha = 0;
	this.instance_409._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_409).wait(1203).to({_off:false},0).to({y:396.85,alpha:1},10).wait(241).to({startPosition:0},0).to({y:386.85,alpha:0},14).to({_off:true},1).wait(3809));

	// Speech_Bubble4
	this.instance_410 = new lib.speechbubble2("synched",0);
	this.instance_410.setTransform(413.6,388.15,1.4925,1.4925,0,0,0,233.4,146.7);
	this.instance_410._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_410).wait(1188).to({_off:false},0).to({y:398.15},15).wait(251).to({startPosition:0},0).to({y:388.15},14).to({_off:true},1).wait(3809));

	// Logo_Icon
	this.instance_411 = new lib.logoicon2("synched",0);
	this.instance_411.setTransform(1188.95,846.1,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_411._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_411).wait(1128).to({_off:false},0).to({x:410.15,y:587.1},60).to({_off:true},281).wait(3809));

	// Text_Buy_Cashback
	this.instance_412 = new lib.buycashbacklicenses("synched",0);
	this.instance_412.setTransform(652.65,701.05,0.9025,0.9025,0,0,0,62.5,36.1);
	this.instance_412.alpha = 0;
	this.instance_412._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_412).wait(885).to({_off:false},0).to({regX:62.6,x:655.45,y:698.35,alpha:1},15).to({_off:true},4281).wait(97));

	// Img_Licence_Pack
	this.instance_413 = new lib.licencsespack("synched",0);
	this.instance_413.setTransform(777,728.3,0.9025,0.9025,0,0,0,98.3,81.5);
	this.instance_413.alpha = 0;
	this.instance_413._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_413).wait(885).to({_off:false},0).to({y:717.6,alpha:1},15).to({y:722.9},6).to({_off:true},4275).wait(97));

	// Line_Pink_Dotted
	this.instance_414 = new lib.CachedBmp_4374();
	this.instance_414.setTransform(911.95,619.15,0.5,0.5);

	this.instance_415 = new lib.CachedBmp_4375();
	this.instance_415.setTransform(906.4,619.35,0.5,0.5);

	this.instance_416 = new lib.CachedBmp_4376();
	this.instance_416.setTransform(900.85,619.35,0.5,0.5);

	this.instance_417 = new lib.CachedBmp_4377();
	this.instance_417.setTransform(895.3,619.35,0.5,0.5);

	this.instance_418 = new lib.CachedBmp_4378();
	this.instance_418.setTransform(889.75,619.35,0.5,0.5);

	this.instance_419 = new lib.CachedBmp_4379();
	this.instance_419.setTransform(884.2,619.35,0.5,0.5);

	this.instance_420 = new lib.CachedBmp_4380();
	this.instance_420.setTransform(878.65,619.35,0.5,0.5);

	this.instance_421 = new lib.CachedBmp_4381();
	this.instance_421.setTransform(873.1,619.35,0.5,0.5);

	this.instance_422 = new lib.CachedBmp_4382();
	this.instance_422.setTransform(867.6,619.35,0.5,0.5);

	this.instance_423 = new lib.CachedBmp_4383();
	this.instance_423.setTransform(862.05,619.35,0.5,0.5);

	this.instance_424 = new lib.CachedBmp_4384();
	this.instance_424.setTransform(856.5,619.35,0.5,0.5);

	this.instance_425 = new lib.CachedBmp_4385();
	this.instance_425.setTransform(850.95,619.35,0.5,0.5);

	this.instance_426 = new lib.CachedBmp_4386();
	this.instance_426.setTransform(845.4,619.35,0.5,0.5);

	this.instance_427 = new lib.CachedBmp_4387();
	this.instance_427.setTransform(839.85,619.35,0.5,0.5);

	this.instance_428 = new lib.CachedBmp_4388();
	this.instance_428.setTransform(834.3,619.35,0.5,0.5);

	this.instance_429 = new lib.CachedBmp_4389();
	this.instance_429.setTransform(828.75,619.15,0.5,0.5);

	this.instance_430 = new lib.CachedBmp_4390();
	this.instance_430.setTransform(812.65,619.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_414}]},890).to({state:[{t:this.instance_415}]},1).to({state:[{t:this.instance_416}]},1).to({state:[{t:this.instance_417}]},1).to({state:[{t:this.instance_418}]},1).to({state:[{t:this.instance_419}]},1).to({state:[{t:this.instance_420}]},1).to({state:[{t:this.instance_421}]},1).to({state:[{t:this.instance_422}]},1).to({state:[{t:this.instance_423}]},1).to({state:[{t:this.instance_424}]},1).to({state:[{t:this.instance_425}]},1).to({state:[{t:this.instance_426}]},1).to({state:[{t:this.instance_427}]},1).to({state:[{t:this.instance_428}]},1).to({state:[{t:this.instance_429}]},1).to({state:[{t:this.instance_430}]},1).to({state:[]},4275).wait(97));

	// Dot_Pink
	this.instance_431 = new lib.dotpink("synched",0);
	this.instance_431.setTransform(913.95,621.1,0.2707,0.2707,0,0,0,7.5,4.5);
	this.instance_431._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_431).wait(875).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:914,y:621.15},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552,x:913.9,y:621.1},5).to({_off:true},4291).wait(97));

	// Line_Pink
	this.instance_432 = new lib.CachedBmp_4391();
	this.instance_432.setTransform(630.35,651.1,0.5,0.5);

	this.instance_433 = new lib.CachedBmp_4392();
	this.instance_433.setTransform(630.35,651.1,0.5,0.5);

	this.instance_434 = new lib.CachedBmp_4393();
	this.instance_434.setTransform(630.35,651.1,0.5,0.5);

	this.instance_435 = new lib.CachedBmp_4394();
	this.instance_435.setTransform(630.35,651.1,0.5,0.5);

	this.instance_436 = new lib.CachedBmp_4395();
	this.instance_436.setTransform(630.35,651.1,0.5,0.5);

	this.instance_437 = new lib.CachedBmp_4396();
	this.instance_437.setTransform(630.35,651.1,0.5,0.5);

	this.instance_438 = new lib.CachedBmp_4397();
	this.instance_438.setTransform(630.35,651.1,0.5,0.5);

	this.instance_439 = new lib.CachedBmp_4398();
	this.instance_439.setTransform(630.35,651.1,0.5,0.5);

	this.instance_440 = new lib.CachedBmp_4399();
	this.instance_440.setTransform(630.35,651.1,0.5,0.5);

	this.instance_441 = new lib.CachedBmp_4400();
	this.instance_441.setTransform(630.35,651.1,0.5,0.5);

	this.instance_442 = new lib.CachedBmp_4401();
	this.instance_442.setTransform(630.35,651.1,0.5,0.5);

	this.instance_443 = new lib.CachedBmp_4402();
	this.instance_443.setTransform(630.35,651.1,0.5,0.5);

	this.instance_444 = new lib.CachedBmp_4403();
	this.instance_444.setTransform(630.35,651.1,0.5,0.5);

	this.instance_445 = new lib.CachedBmp_4404();
	this.instance_445.setTransform(630.35,651.1,0.5,0.5);

	this.instance_446 = new lib.CachedBmp_4405();
	this.instance_446.setTransform(630.35,651.1,0.5,0.5);

	this.instance_447 = new lib.CachedBmp_4406();
	this.instance_447.setTransform(630.35,651.1,0.5,0.5);

	this.instance_448 = new lib.CachedBmp_4407();
	this.instance_448.setTransform(630.3,651.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_432}]},900).to({state:[{t:this.instance_433}]},1).to({state:[{t:this.instance_434}]},1).to({state:[{t:this.instance_435}]},1).to({state:[{t:this.instance_436}]},1).to({state:[{t:this.instance_437}]},1).to({state:[{t:this.instance_438}]},1).to({state:[{t:this.instance_439}]},1).to({state:[{t:this.instance_440}]},1).to({state:[{t:this.instance_441}]},1).to({state:[{t:this.instance_442}]},1).to({state:[{t:this.instance_443}]},1).to({state:[{t:this.instance_444}]},1).to({state:[{t:this.instance_445}]},1).to({state:[{t:this.instance_446}]},1).to({state:[{t:this.instance_447}]},1).to({state:[{t:this.instance_448}]},1).to({state:[]},4265).wait(97));

	// Line_Pink
	this.instance_449 = new lib.CachedBmp_4408();
	this.instance_449.setTransform(683.65,619.15,0.5,0.5);

	this.instance_450 = new lib.CachedBmp_4409();
	this.instance_450.setTransform(678.3,619.15,0.5,0.5);

	this.instance_451 = new lib.CachedBmp_4410();
	this.instance_451.setTransform(673,619.15,0.5,0.5);

	this.instance_452 = new lib.CachedBmp_4411();
	this.instance_452.setTransform(667.65,619.15,0.5,0.5);

	this.instance_453 = new lib.CachedBmp_4412();
	this.instance_453.setTransform(662.3,619.15,0.5,0.5);

	this.instance_454 = new lib.CachedBmp_4413();
	this.instance_454.setTransform(657,619.15,0.5,0.5);

	this.instance_455 = new lib.CachedBmp_4414();
	this.instance_455.setTransform(651.65,619.15,0.5,0.5);

	this.instance_456 = new lib.CachedBmp_4415();
	this.instance_456.setTransform(646.3,619.15,0.5,0.5);

	this.instance_457 = new lib.CachedBmp_4416();
	this.instance_457.setTransform(640.95,619.15,0.5,0.5);

	this.instance_458 = new lib.CachedBmp_4417();
	this.instance_458.setTransform(635.65,619.15,0.5,0.5);

	this.instance_459 = new lib.CachedBmp_4418();
	this.instance_459.setTransform(630.3,619.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_449}]},890).to({state:[{t:this.instance_450}]},1).to({state:[{t:this.instance_451}]},1).to({state:[{t:this.instance_452}]},1).to({state:[{t:this.instance_453}]},1).to({state:[{t:this.instance_454}]},1).to({state:[{t:this.instance_455}]},1).to({state:[{t:this.instance_456}]},1).to({state:[{t:this.instance_457}]},1).to({state:[{t:this.instance_458}]},1).to({state:[{t:this.instance_459}]},1).to({state:[]},4281).wait(97));

	// Dot_Pink
	this.instance_460 = new lib.dotpink("synched",0);
	this.instance_460.setTransform(687.8,620.6,0.2707,0.2707,0,0,0,7.4,4);
	this.instance_460._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_460).wait(875).to({_off:false},0).to({regX:7.6,regY:4.3,scaleX:0.9151,scaleY:0.9151,y:620.65},10).to({regX:7.5,regY:4.5,scaleX:0.6552,scaleY:0.6552},5).to({_off:true},4291).wait(97));

	// txt
	this.instance_461 = new lib.Symbol8("synched",0);
	this.instance_461.setTransform(1178.95,668.05,1,1,0,0,0,90.3,29.4);
	this.instance_461.alpha = 0;
	this.instance_461._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_461).wait(984).to({_off:false},0).to({y:678.05,alpha:1},10).wait(95).to({startPosition:0},0).to({y:668.05,alpha:0},10).to({_off:true},1).wait(4178));

	// tootip
	this.instance_462 = new lib.CachedBmp_4420();
	this.instance_462.setTransform(483.8,979.8,0.5,0.5);

	this.instance_463 = new lib.CachedBmp_4419();
	this.instance_463.setTransform(449.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_463},{t:this.instance_462}]},757).to({state:[]},203).to({state:[]},4221).wait(97));

	// txt
	this.instance_464 = new lib.Symbol7("synched",0);
	this.instance_464.setTransform(1178.95,667.75,1,1,0,0,0,111.2,43.1);
	this.instance_464.alpha = 0;
	this.instance_464._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_464).wait(747).to({_off:false},0).to({y:677.75,alpha:1},10).wait(203).to({startPosition:0},0).to({y:667.75,alpha:0},10).to({_off:true},1).wait(4307));

	// Speech_Bubble3
	this.instance_465 = new lib.speechbubble2("synched",0);
	this.instance_465.setTransform(1191.2,668.85,1.3537,1.3537,0,0,0,233.4,146.7);
	this.instance_465._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_465).wait(732).to({_off:false},0).to({y:678.85},15).wait(342).to({startPosition:0},0).to({y:668.85},10).to({_off:true},1).wait(4178));

	// Logo_Icon
	this.instance_466 = new lib.logoicon2("synched",0);
	this.instance_466.setTransform(1188.95,524.45,0.9025,0.9025,0,0,0,50.1,50.1);
	this.instance_466._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_466).wait(704).to({_off:false},0).to({regY:50,y:846.1},28,cjs.Ease.get(0.5)).to({_off:true},396).wait(4150));

	// Text_CBM_Registration
	this.instance_467 = new lib.cbmgeneration("synched",0);
	this.instance_467.setTransform(883.95,543.5,0.9025,0.9025,0,0,0,49.6,100);
	this.instance_467.alpha = 0;
	this.instance_467._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_467).wait(590).to({_off:false},0).to({x:880.75,y:540.3,alpha:1},9).to({_off:true},4582).wait(97));

	// Logo_CBM
	this.instance_468 = new lib.logoicon("synched",0);
	this.instance_468.setTransform(1033.5,629.25,0.4501,0.45,0,0,0,190.2,182.5);
	this.instance_468.alpha = 0;
	this.instance_468._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_468).wait(580).to({_off:false},0).to({regX:190.3,regY:182.4,scaleX:0.9406,scaleY:0.9404,x:1033.55,alpha:1},10).to({scaleX:0.9001,scaleY:0.8999},9).to({_off:true},4582).wait(97));

	// Pink_Line
	this.instance_469 = new lib.CachedBmp_4421();
	this.instance_469.setTransform(911.5,490.5,0.5,0.5);

	this.instance_470 = new lib.CachedBmp_4422();
	this.instance_470.setTransform(911.5,490.5,0.5,0.5);

	this.instance_471 = new lib.CachedBmp_4423();
	this.instance_471.setTransform(911.5,490.5,0.5,0.5);

	this.instance_472 = new lib.CachedBmp_4424();
	this.instance_472.setTransform(911.5,490.5,0.5,0.5);

	this.instance_473 = new lib.CachedBmp_4425();
	this.instance_473.setTransform(911.5,490.5,0.5,0.5);

	this.instance_474 = new lib.CachedBmp_4426();
	this.instance_474.setTransform(911.5,490.5,0.5,0.5);

	this.instance_475 = new lib.CachedBmp_4427();
	this.instance_475.setTransform(911.5,490.5,0.5,0.5);

	this.instance_476 = new lib.CachedBmp_4428();
	this.instance_476.setTransform(911.5,490.5,0.5,0.5);

	this.instance_477 = new lib.CachedBmp_4429();
	this.instance_477.setTransform(911.5,490.5,0.5,0.5);

	this.instance_478 = new lib.CachedBmp_4430();
	this.instance_478.setTransform(911.5,490.5,0.5,0.5);

	this.instance_479 = new lib.CachedBmp_4431();
	this.instance_479.setTransform(911.5,490.5,0.5,0.5);

	this.instance_480 = new lib.CachedBmp_4432();
	this.instance_480.setTransform(911.5,490.5,0.5,0.5);

	this.instance_481 = new lib.CachedBmp_4433();
	this.instance_481.setTransform(911.5,490.5,0.5,0.5);

	this.instance_482 = new lib.CachedBmp_4434();
	this.instance_482.setTransform(911.5,490.5,0.5,0.5);

	this.instance_483 = new lib.CachedBmp_4435();
	this.instance_483.setTransform(911.5,490.5,0.5,0.5);

	this.instance_484 = new lib.CachedBmp_4436();
	this.instance_484.setTransform(911.5,490.5,0.5,0.5);

	this.instance_485 = new lib.CachedBmp_4437();
	this.instance_485.setTransform(911.5,490.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_469}]},565).to({state:[{t:this.instance_470}]},1).to({state:[{t:this.instance_471}]},1).to({state:[{t:this.instance_472}]},1).to({state:[{t:this.instance_473}]},1).to({state:[{t:this.instance_474}]},1).to({state:[{t:this.instance_475}]},1).to({state:[{t:this.instance_476}]},1).to({state:[{t:this.instance_477}]},1).to({state:[{t:this.instance_478}]},1).to({state:[{t:this.instance_479}]},1).to({state:[{t:this.instance_480}]},1).to({state:[{t:this.instance_481}]},1).to({state:[{t:this.instance_482}]},1).to({state:[{t:this.instance_483}]},1).to({state:[{t:this.instance_484}]},1).to({state:[{t:this.instance_485}]},1).to({state:[]},4600).wait(97));

	// Pink_Line
	this.instance_486 = new lib.CachedBmp_4438();
	this.instance_486.setTransform(782.45,559.9,0.5,0.5);

	this.instance_487 = new lib.CachedBmp_4439();
	this.instance_487.setTransform(782.45,555.25,0.5,0.5);

	this.instance_488 = new lib.CachedBmp_4440();
	this.instance_488.setTransform(782.45,550.65,0.5,0.5);

	this.instance_489 = new lib.CachedBmp_4441();
	this.instance_489.setTransform(782.45,546,0.5,0.5);

	this.instance_490 = new lib.CachedBmp_4442();
	this.instance_490.setTransform(782.45,541.4,0.5,0.5);

	this.instance_491 = new lib.CachedBmp_4443();
	this.instance_491.setTransform(782.45,536.75,0.5,0.5);

	this.instance_492 = new lib.CachedBmp_4444();
	this.instance_492.setTransform(782.45,532.1,0.5,0.5);

	this.instance_493 = new lib.CachedBmp_4445();
	this.instance_493.setTransform(782.45,527.5,0.5,0.5);

	this.instance_494 = new lib.CachedBmp_4446();
	this.instance_494.setTransform(782.45,522.85,0.5,0.5);

	this.instance_495 = new lib.CachedBmp_4447();
	this.instance_495.setTransform(782.45,518.25,0.5,0.5);

	this.instance_496 = new lib.CachedBmp_4448();
	this.instance_496.setTransform(782.45,513.6,0.5,0.5);

	this.instance_497 = new lib.CachedBmp_4449();
	this.instance_497.setTransform(782.45,508.95,0.5,0.5);

	this.instance_498 = new lib.CachedBmp_4450();
	this.instance_498.setTransform(782.45,504.35,0.5,0.5);

	this.instance_499 = new lib.CachedBmp_4451();
	this.instance_499.setTransform(782.45,499.7,0.5,0.5);

	this.instance_500 = new lib.CachedBmp_4452();
	this.instance_500.setTransform(782.45,495.1,0.5,0.5);

	this.instance_501 = new lib.CachedBmp_4453();
	this.instance_501.setTransform(782.45,490.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_486}]},550).to({state:[{t:this.instance_487}]},1).to({state:[{t:this.instance_488}]},1).to({state:[{t:this.instance_489}]},1).to({state:[{t:this.instance_490}]},1).to({state:[{t:this.instance_491}]},1).to({state:[{t:this.instance_492}]},1).to({state:[{t:this.instance_493}]},1).to({state:[{t:this.instance_494}]},1).to({state:[{t:this.instance_495}]},1).to({state:[{t:this.instance_496}]},1).to({state:[{t:this.instance_497}]},1).to({state:[{t:this.instance_498}]},1).to({state:[{t:this.instance_499}]},1).to({state:[{t:this.instance_500}]},1).to({state:[{t:this.instance_501}]},1).to({state:[]},4616).wait(97));

	// Dot_Pink
	this.instance_502 = new lib.dotpink("synched",0);
	this.instance_502.setTransform(783.95,565.4,0.2707,0.2707,0,0,0,7.8,4.5);
	this.instance_502._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_502).wait(535).to({_off:false},0).to({regX:7.7,regY:4.4,scaleX:0.9151,scaleY:0.9151,x:784,y:565.45},10).to({regY:4.5,scaleX:0.6552,scaleY:0.6552,y:565.4},5).to({_off:true},4631).wait(97));

	// tootip
	this.instance_503 = new lib.CachedBmp_4455();
	this.instance_503.setTransform(616.05,979.8,0.5,0.5);

	this.instance_504 = new lib.CachedBmp_4454();
	this.instance_504.setTransform(589.8,969,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_504},{t:this.instance_503}]},439).to({state:[]},220).to({state:[]},4522).wait(97));

	// txt
	this.instance_505 = new lib.Symbol4("synched",0);
	this.instance_505.setTransform(1159.45,340.25,1,1,0,0,0,124.3,45.6);
	this.instance_505.alpha = 0;
	this.instance_505._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_505).wait(429).to({_off:false},0).to({y:350.25,alpha:1},10).wait(220).to({startPosition:0},0).to({y:340.25,alpha:0},14).to({_off:true},1).wait(4604));

	// Speech_Bubble3
	this.instance_506 = new lib.speechbubble2("synched",0);
	this.instance_506.setTransform(1171.2,336.85,1.3537,1.3537,0,0,0,233.4,146.7);
	this.instance_506._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_506).wait(414).to({_off:false},0).to({y:346.85},15).wait(230).to({startPosition:0},0).to({y:336.85},14).to({_off:true},1).wait(4604));

	// txt
	this.instance_507 = new lib.txtmeetjames("synched",0);
	this.instance_507.setTransform(547.25,318.9,1,1,0,0,0,64,15.7);
	this.instance_507.alpha = 0;
	this.instance_507._off = true;

	this.instance_508 = new lib.Symbol3("synched",0);
	this.instance_508.setTransform(547.3,270.85,1,1,0,0,0,124.3,45.6);
	this.instance_508.alpha = 0;
	this.instance_508._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_507).wait(104).to({_off:false},0).to({y:328.9,alpha:1},10).wait(75).to({startPosition:0},0).to({y:318.9,alpha:0},10).to({_off:true},1).wait(5078));
	this.timeline.addTween(cjs.Tween.get(this.instance_508).wait(209).to({_off:false},0).to({y:280.85,alpha:1},10).wait(160).to({startPosition:0},0).to({y:270.85,alpha:0},10).to({_off:true},1).wait(4888));

	// Speech_Bubble
	this.instance_509 = new lib.speechbubble2("synched",0);
	this.instance_509.setTransform(553.2,316,0.9025,0.9025,0,0,0,233.4,146.7);
	this.instance_509._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_509).wait(94).to({_off:false},0).to({y:326},10).wait(85).to({startPosition:0},0).to({scaleX:1.3537,scaleY:1.3537,x:555.2,y:285.85},15).wait(175).to({startPosition:0},0).to({y:275.85},10).to({_off:true},1).wait(4888));

	// Logo_Icon_
	this.instance_510 = new lib.logoicon2("synched",0);
	this.instance_510.setTransform(548.15,463.9,0.4512,0.4512,0,0,0,50.1,50);
	this.instance_510.alpha = 0;
	this.instance_510._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_510).wait(76).to({_off:false},0).to({regX:50,scaleX:0.9927,scaleY:0.9927,y:463.95,alpha:1},13).to({regX:50.1,scaleX:0.9025,scaleY:0.9025,x:548.2,y:463.9},5).wait(285).to({startPosition:0},0).to({regY:50.1,x:1188.95,y:524.45},30,cjs.Ease.get(0.5)).to({_off:true},295).wait(4574));

	// txt_james
	this.instance_511 = new lib.textjames("synched",0);
	this.instance_511.setTransform(664.6,450.35,0.9025,0.9025,0,0,0,9.4,13.8);
	this.instance_511.alpha = 0;
	this.instance_511._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_511).wait(114).to({_off:false},0).to({x:674.6,alpha:1},15).to({_off:true},5052).wait(97));

	// james
	this.instance_512 = new lib.james();
	this.instance_512.setTransform(738.4,462,0.9025,0.9025,0,0,0,44,125);
	this.instance_512.alpha = 0;
	this.instance_512._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_512).wait(114).to({_off:false},0).to({y:517.15,alpha:1},9).to({y:510.75},6).to({_off:true},5052).wait(97));

	// Bg Grid
	this.instance_513 = new lib.grid("synched",0);
	this.instance_513.setTransform(865.05,575.9,0.9927,0.9927,0,0,0,960.1,510.7);
	this.instance_513.alpha = 0;
	this.instance_513._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_513).wait(59).to({_off:false},0).to({alpha:1},10).wait(5209));

	// txt-title
	this.instance_514 = new lib.texttitle("synched",0);
	this.instance_514.setTransform(352.2,112.3,0.9025,0.9025,0,0,0,344.8,69.5);
	this.instance_514.alpha = 0;
	this.instance_514._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_514).wait(39).to({_off:false},0).to({x:362.2,alpha:1},10).wait(5229));

	// Infographic
	this.instance_515 = new lib.infographic();
	this.instance_515.setTransform(864.95,575.8,1.5,1.5,0,0,0,953,506.9);
	this.instance_515._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_515).wait(4).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:0.0703},30).wait(5147).to({alpha:1},0).to({alpha:0.1016},10).wait(87));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,2294.5,1336.3);
// library properties:
lib.properties = {
	id: 'EA5571A2295DF7458D9934B992E3E739',
	width: 1920,
	height: 1080,
	fps: 90,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"step1-registration/images/CachedBmp_4476.png", id:"CachedBmp_4476"},
		{src:"step1-registration/images/imgbggrid.png", id:"imgbggrid"},
		{src:"step1-registration/images/step1_registration_atlas_.png", id:"step1_registration_atlas_"},
		{src:"step1-registration/images/step1_registration_atlas_2.png", id:"step1_registration_atlas_2"},
		{src:"step1-registration/images/step1_registration_atlas_3.png", id:"step1_registration_atlas_3"},
		{src:"step1-registration/images/step1_registration_atlas_4.png", id:"step1_registration_atlas_4"},
		{src:"step1-registration/images/step1_registration_atlas_5.png", id:"step1_registration_atlas_5"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EA5571A2295DF7458D9934B992E3E739'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;