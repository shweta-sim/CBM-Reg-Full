(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"step2_buycashbacklicenses_atlas_", frames: [[0,1175,729,232],[0,1409,668,228],[477,1780,674,173],[1004,0,1005,1012],[670,1491,491,287],[0,1639,475,278],[1584,1014,459,269],[1153,1780,443,259],[1584,1285,427,250],[1163,1491,411,241],[1576,1537,395,231],[1598,1770,379,222],[0,0,1002,1173],[1004,1014,578,475]]},
		{name:"step2_buycashbacklicenses_atlas_2", frames: [[616,808,668,49],[977,202,77,65],[1121,2010,109,38],[928,1375,358,65],[1794,1620,131,76],[1725,1393,167,65],[1658,1703,158,65],[798,1956,235,54],[1343,1925,110,64],[1495,1537,162,97],[427,1997,88,51],[300,1388,219,219],[1741,1320,175,71],[1877,1985,97,47],[229,1997,97,47],[328,1997,97,47],[0,215,358,207],[712,0,346,200],[0,628,334,194],[1392,0,322,187],[0,1206,310,180],[0,1565,298,173],[364,205,287,166],[297,1835,275,160],[712,202,263,153],[723,512,251,146],[1481,493,239,139],[0,1915,227,133],[976,658,215,126],[723,1375,203,119],[1289,1010,192,112],[1395,1124,180,105],[1325,1539,168,98],[1567,1327,156,92],[1097,1656,144,85],[1796,1460,132,78],[1367,1714,120,71],[1455,1943,108,65],[1700,1836,97,58],[1123,1912,85,51],[1226,1873,115,68],[1239,1803,119,68],[1582,1902,108,63],[1799,1837,98,57],[1958,511,88,51],[0,0,362,213],[364,0,346,203],[1060,0,330,194],[0,1019,314,185],[0,1388,298,175],[346,542,282,166],[1060,196,266,157],[982,508,250,148],[1722,486,234,138],[848,995,218,129],[976,1253,202,120],[1615,892,186,110],[1392,1335,170,101],[771,1496,154,92],[949,1824,138,82],[1367,1639,121,73],[616,710,105,64],[1899,1817,89,54],[1489,1734,119,70],[1610,1770,108,64],[1777,1967,98,58],[1958,457,87,52],[0,424,344,202],[0,824,328,193],[1716,0,311,183],[0,1740,295,173],[336,710,278,164],[316,1205,261,154],[1234,514,245,145],[1080,859,228,135],[757,1126,212,125],[1419,773,195,116],[579,1253,179,106],[1577,1228,162,97],[798,1867,146,87],[1818,1698,129,77],[1932,1113,113,68],[1616,773,96,58],[977,269,80,49],[1659,1542,133,79],[1243,1731,118,70],[1591,1836,107,64],[1799,1777,97,58],[1958,564,86,52],[1922,1298,126,74],[1930,1449,118,71],[1478,1806,111,67],[1565,1967,104,63],[1949,1756,97,59],[1899,1873,89,54],[1210,1943,82,50],[1671,1967,104,63],[1616,833,92,56],[1035,1966,84,51],[1755,1220,165,98],[927,1561,146,86],[1660,1460,134,80],[1918,1374,123,73],[1937,760,111,67],[1288,1374,100,60],[1895,1929,89,54],[1720,1770,77,47],[848,859,230,134],[1068,996,219,128],[1185,1126,208,122],[1126,1442,197,116],[1672,1004,186,109],[1755,1115,175,103],[1494,1438,164,97],[771,1590,153,91],[952,1737,143,85],[1659,1623,132,78],[1927,1620,121,72],[1360,1857,110,66],[1949,1694,99,60],[593,1198,88,53],[1316,1991,77,47],[574,1711,110,331],[686,1711,110,326],[360,373,284,167],[316,1041,275,162],[1716,185,266,156],[982,355,257,151],[723,660,248,146],[1713,343,239,141],[616,859,230,136],[1714,760,221,130],[971,1126,212,125],[771,1253,203,120],[1419,891,194,115],[1803,892,185,110],[1577,1122,176,104],[1325,1438,167,99],[1126,1560,158,94],[798,1776,149,89],[1097,1743,140,84],[1796,1540,131,78],[1243,1656,122,73],[1363,1787,113,68],[1692,1902,104,63],[1798,1896,95,58],[1035,1912,86,52],[330,876,275,163],[1392,189,266,158],[723,357,257,153],[521,1561,248,148],[1471,349,240,142],[1481,634,231,137],[1722,626,222,132],[1193,661,213,127],[1185,1250,205,122],[928,1442,196,117],[1483,1008,187,112],[1860,1004,178,107],[1395,1231,170,102],[1495,1636,161,96],[798,1683,152,91],[952,1649,143,86],[1089,1829,135,81],[1922,1220,126,76],[1929,1540,117,71],[1472,1875,108,66],[1937,829,100,61],[630,640,91,56],[1232,1995,82,50],[630,542,91,96],[1946,626,102,110],[607,997,148,199],[1954,343,92,112],[521,1361,200,198],[757,997,84,83],[1241,355,228,157],[1310,790,107,218],[300,1609,214,224]]},
		{name:"step2_buycashbacklicenses_atlas_3", frames: [[0,173,33,19],[862,63,49,49],[414,126,25,31],[715,156,25,31],[537,162,6,69],[269,171,6,58],[775,176,6,47],[439,178,6,35],[361,95,6,24],[369,95,6,13],[620,0,73,44],[379,87,61,37],[975,63,49,31],[278,165,37,24],[996,170,25,17],[990,34,13,10],[79,0,78,46],[457,63,68,40],[244,95,57,35],[911,140,47,29],[461,170,37,23],[381,178,27,18],[700,189,17,12],[470,0,73,45],[185,95,57,36],[746,148,41,26],[823,178,25,17],[960,140,9,8],[159,0,76,46],[527,63,66,40],[797,104,55,34],[48,142,45,28],[960,170,34,22],[545,184,24,16],[1005,50,13,10],[797,63,63,39],[971,138,47,30],[317,178,30,20],[442,87,13,10],[237,0,76,46],[663,63,65,40],[854,114,55,34],[142,142,44,28],[233,171,34,22],[772,113,23,16],[719,189,13,10],[393,0,75,46],[695,0,68,42],[913,63,60,38],[971,103,53,33],[0,142,46,29],[634,156,39,25],[166,172,32,21],[127,180,24,17],[278,142,17,13],[877,178,10,8],[0,95,60,37],[498,129,50,31],[847,150,41,26],[742,176,31,20],[35,188,21,15],[1010,189,12,9],[315,0,76,46],[765,0,68,42],[62,95,60,37],[361,126,51,32],[188,142,43,28],[500,170,35,23],[410,178,27,18],[1005,34,19,14],[348,132,11,9],[595,63,66,40],[442,121,54,34],[233,142,43,27],[200,172,31,21],[431,71,20,14],[960,150,9,8],[300,132,46,31],[593,156,39,26],[926,171,32,22],[850,178,25,17],[890,150,17,13],[348,143,10,9],[905,0,67,41],[303,95,56,35],[95,142,45,28],[890,171,34,22],[571,184,23,16],[447,178,12,10],[0,0,77,47],[835,0,68,42],[124,95,59,37],[974,0,50,32],[550,156,41,26],[789,172,32,21],[596,184,23,16],[974,34,14,11],[545,0,73,45],[730,63,65,40],[913,103,56,35],[798,140,47,30],[675,156,38,25],[349,178,30,20],[58,188,21,15],[996,189,12,10],[470,47,533,6],[0,55,507,6],[509,55,481,6],[0,63,455,6],[0,71,429,6],[0,79,403,6],[0,87,377,6],[442,105,351,6],[442,113,325,6],[0,134,298,6],[498,121,272,6],[550,140,246,6],[550,129,220,6],[550,148,194,6],[348,162,168,6],[317,170,142,6],[48,172,116,6],[35,180,90,6],[634,183,64,6],[81,188,38,6],[405,79,12,6]]}
];


// symbols:



(lib.CachedBmp_4818 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4817 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4816 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4815 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4814 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4813 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4812 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4811 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4810 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4809 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4808 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4807 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4806 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4805 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4804 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4803 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4802 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4801 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4800 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4798 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4799 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4796 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4795 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4794 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4793 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4792 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4791 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4790 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4789 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4788 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4787 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4786 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4785 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4784 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4783 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4782 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4781 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4780 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4779 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4778 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4777 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4776 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4775 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4774 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4773 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4772 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4771 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4770 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4769 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4768 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4767 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4766 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4765 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4764 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4763 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4762 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4761 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4760 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4759 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4758 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4757 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4756 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4755 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4754 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4753 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4752 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4751 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4750 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4749 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4748 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4747 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4746 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4745 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4744 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4743 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4742 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4741 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4740 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4739 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4738 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4737 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4736 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4735 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4734 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4733 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4732 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4731 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4730 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4729 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4728 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4727 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4726 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4725 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4724 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4723 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4722 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4721 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4720 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4719 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4718 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4717 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4716 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4715 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4714 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4713 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4712 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4711 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4710 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4709 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4708 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4707 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4706 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4705 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4704 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4703 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4702 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4701 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4700 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4699 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4698 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4697 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4696 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4695 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4694 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4693 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4692 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4691 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4690 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4689 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4688 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4687 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4686 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4685 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4684 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4683 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4682 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4681 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4680 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4679 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4678 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4677 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4676 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4675 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4674 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4673 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4672 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4671 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4670 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4669 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4668 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4667 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4666 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4665 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4664 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4663 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4662 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4661 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4660 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4659 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4658 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4657 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4656 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4655 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4654 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4653 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4652 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4651 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4650 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4649 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4648 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4647 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4646 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4645 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4644 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4643 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4642 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4641 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4640 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4639 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4638 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4637 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4636 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4635 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4634 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4633 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4632 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4631 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4630 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4629 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4628 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4627 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4626 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4625 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4624 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4623 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4622 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4621 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4620 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4619 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4618 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4617 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4616 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4615 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4614 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4613 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4612 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4611 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4610 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4609 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4608 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4607 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4606 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4605 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4604 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4603 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4602 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4601 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4600 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4599 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4598 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4597 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4596 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4595 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4594 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4593 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4592 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4591 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4590 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4589 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4588 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4587 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4586 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4585 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4584 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4583 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4582 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4581 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4580 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4579 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4578 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4577 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4576 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4575 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4574 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4573 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4572 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4571 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4570 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4569 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4568 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4567 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4566 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4565 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4564 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4563 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4562 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4561 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4560 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4559 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4558 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4557 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4556 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4555 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4554 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4553 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4552 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4551 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4550 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4549 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4548 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4547 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4546 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4545 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4544 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4543 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4542 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4541 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4540 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4539 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4538 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4537 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4536 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4535 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4534 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4533 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4532 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4531 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4530 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4529 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4528 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4527 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4526 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4525 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4524 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4523 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4522 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4521 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4520 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4519 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4518 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4517 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4516 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4515 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4514 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4513 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4512 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4511 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4510 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_3"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap28 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap29 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.imgbggrid = function() {
	this.initialize(img.imgbggrid);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4132,2198);


(lib.imgcashback = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_2"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.imgtradingaccount = function() {
	this.initialize(ss["step2_buycashbacklicenses_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.text3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4818();
	this.instance.setTransform(-106.2,13.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.2,13.5,364.5,116);


(lib.text2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4817();
	this.instance.setTransform(-98.6,109.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_4816();
	this.instance_1.setTransform(-98.6,-0.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98.6,-0.3,334,134.70000000000002);


(lib.text1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4815();
	this.instance.setTransform(-106.4,11.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.4,11.9,337,86.5);


(lib.textnodesno = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4814();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38.5,32.5);


(lib.textnode = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4813();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54.5,19);


(lib.textcbnodes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4812();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,179,32.5);


(lib.textcashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_4811();
	this.instance.setTransform(67.35,20.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(67.4,20.4,65.5,38);


(lib.textcapital = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4810();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,83.5,32.5);


(lib.textamount1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4809();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,79,32.5);


(lib.textafullmatrix = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4808();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,117.5,27);


(lib.imgpig = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap12();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,91,96);


(lib.imgcouple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,107,218);


(lib.grid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgbggrid();
	this.instance.setTransform(0,0,0.4647,0.4646);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,1021.3);


(lib.tradingaccount = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgtradingaccount();
	this.instance.setTransform(0,0,0.504,0.504);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,291.3,239.4);


(lib.textrebates = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_4807();
	this.instance.setTransform(70.75,24.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(70.8,24.3,55,31.999999999999996);


(lib.textlp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_4806();
	this.instance.setTransform(55.85,5.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(55.9,5.7,81,48.5);


(lib.textbanks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_4805();
	this.instance.setTransform(76.25,27.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(76.3,27.5,44,25.5);


(lib.speechbubble2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap29();
	this.instance.setTransform(114,79);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(114,79,228,157);


(lib.mccashback = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.imgcashback();
	this.instance.setTransform(0,0,0.6694,0.6696);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143.3,150);


(lib.logoicon2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap28();
	this.instance.setTransform(7.95,7.95);

	this.instance_1 = new lib.CachedBmp_4804();
	this.instance_1.setTransform(-0.5,-0.5,0.4617,0.4617);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,101.1,101.1);


(lib.logoicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(89,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89,88,200,198);


(lib.liquidityproviders = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(109,131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109,131,92,112);


(lib.fibo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4803();
	this.instance.setTransform(-1,-5.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-5,502.5,506);


(lib.dotpink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4802();
	this.instance.setTransform(0,0,0.4647,0.4647);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.4,8.9);


(lib.broker = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-12,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-17,148,199);


(lib.banks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(38,37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(38,37,102,110);


(lib.circlepink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_4801();
	this.instance.setTransform(-0.65,-0.85,0.1481,0.1481);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.8,7.199999999999999,7.2);


(lib.cashbackmatrix = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.setTransform(298.65,471.4,0.2424,0.2424);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(298.7,471.4,242.8,284.30000000000007);


(lib.btnreplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay.svg
	this.instance = new lib.CachedBmp_4795();
	this.instance.setTransform(132.55,72,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_4794();
	this.instance_1.setTransform(81.1,68.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_4799();
	this.instance_2.setTransform(132.55,72,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4796();
	this.instance_3.setTransform(81.1,68.05,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_4798();
	this.instance_4.setTransform(81.1,68.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_4800();
	this.instance_5.setTransform(68.5,62.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4},{t:this.instance_2}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.5,62.7,87.5,35.5);


// stage content:
(lib.step2buycashbacklicenses = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1417 = function() {
		this.stop();
		
		this.replayBtn.addEventListener("click", fl_ClickToGoToAndPlayAtFrame1.bind(this));
		function fl_ClickToGoToAndPlayAtFrame1()
		{
			this.gotoAndPlay(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1417).call(this.frame_1417).wait(1));

	// Btn_Replay
	this.replayBtn = new lib.btnreplay();
	this.replayBtn.name = "replayBtn";
	this.replayBtn.setTransform(1817,72.75,1,1,0,0,0,112,80.3);
	this.replayBtn.alpha = 0;
	this.replayBtn._off = true;
	new cjs.ButtonHelper(this.replayBtn, 0, 1, 2, false, new lib.btnreplay(), 3);

	this.timeline.addTween(cjs.Tween.get(this.replayBtn).wait(1402).to({_off:false},0).to({x:1827,alpha:1},15).wait(1));

	// Layer_272
	this.instance = new lib.textnodesno("synched",0);
	this.instance.setTransform(487.3,984.75,1,1,0,0,0,19.4,16.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1389).to({_off:false},0).to({x:497.3,alpha:1},10).wait(19));

	// Layer_273
	this.instance_1 = new lib.textcbnodes("synched",0);
	this.instance_1.setTransform(328.5,984.75,1,1,0,0,0,89.5,16.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1389).to({_off:false},0).to({x:338.5,alpha:1},10).wait(19));

	// Layer_274
	this.instance_2 = new lib.textnode("synched",0);
	this.instance_2.setTransform(479.5,956,1,1,0,0,0,27.2,9.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1369).to({_off:false},0).to({x:489.5,alpha:1},10).wait(39));

	// Layer_275
	this.instance_3 = new lib.textamount1("synched",0);
	this.instance_3.setTransform(467.15,936.85,1,1,0,0,0,39.5,16.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1359).to({_off:false},0).to({x:477.15,alpha:1},10).wait(49));

	// Layer_276
	this.instance_4 = new lib.textcapital("synched",0);
	this.instance_4.setTransform(280.6,936.85,1,1,0,0,0,41.6,16.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1359).to({_off:false},0).to({x:290.6,alpha:1},10).wait(49));

	// Layer_277
	this.instance_5 = new lib.CachedBmp_4510();
	this.instance_5.setTransform(249.65,914.75,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_4511();
	this.instance_6.setTransform(249.65,914.75,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_4512();
	this.instance_7.setTransform(249.65,914.75,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_4513();
	this.instance_8.setTransform(249.65,914.75,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_4514();
	this.instance_9.setTransform(249.65,914.75,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_4515();
	this.instance_10.setTransform(249.65,914.75,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_4516();
	this.instance_11.setTransform(249.65,914.75,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_4517();
	this.instance_12.setTransform(249.65,914.75,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_4518();
	this.instance_13.setTransform(249.65,914.75,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_4519();
	this.instance_14.setTransform(249.65,914.75,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_4520();
	this.instance_15.setTransform(249.65,914.75,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_4521();
	this.instance_16.setTransform(249.65,914.75,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_4522();
	this.instance_17.setTransform(249.65,914.75,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_4523();
	this.instance_18.setTransform(249.65,914.75,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_4524();
	this.instance_19.setTransform(249.65,914.75,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_4525();
	this.instance_20.setTransform(249.65,914.75,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_4526();
	this.instance_21.setTransform(249.65,914.75,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_4527();
	this.instance_22.setTransform(249.65,914.75,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_4528();
	this.instance_23.setTransform(249.65,914.75,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_4529();
	this.instance_24.setTransform(249.65,914.75,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_4530();
	this.instance_25.setTransform(249.65,914.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},1329).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).wait(69));

	// Layer_278
	this.instance_26 = new lib.textafullmatrix("synched",0);
	this.instance_26.setTransform(297.6,896.4,1,1,0,0,0,58.6,13.5);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(1329).to({_off:false},0).to({x:307.6,alpha:1},10).wait(79));

	// txt
	this.instance_27 = new lib.text3("synched",0);
	this.instance_27.setTransform(1592.85,864,1,1,0,0,0,174.2,56.9);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(1080).to({_off:false},0).to({x:1582.85,alpha:1},10).wait(328));

	// Logo_Icon
	this.instance_28 = new lib.logoicon2("synched",0);
	this.instance_28.setTransform(1246.4,871.45,0.1805,0.1805,0,0,0,50.1,49.9);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(1055).to({_off:false},0).to({regY:50,scaleX:1.083,scaleY:1.083,x:1246.45,y:871.5},15).to({scaleX:0.9025,scaleY:0.9025,y:871.45},10).wait(338));

	// Line_Orange
	this.instance_29 = new lib.CachedBmp_4531();
	this.instance_29.setTransform(1067.5,775,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_4532();
	this.instance_30.setTransform(1067.5,775,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_4533();
	this.instance_31.setTransform(1067.5,775,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_4534();
	this.instance_32.setTransform(1067.5,775,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_4535();
	this.instance_33.setTransform(1067.5,775,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_4536();
	this.instance_34.setTransform(1067.5,775,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_4537();
	this.instance_35.setTransform(1067.5,775,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_4538();
	this.instance_36.setTransform(1067.5,775,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_4539();
	this.instance_37.setTransform(1067.5,775,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_4540();
	this.instance_38.setTransform(1067.5,775,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_4541();
	this.instance_39.setTransform(1067.5,775,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_4542();
	this.instance_40.setTransform(1067.5,775,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_4543();
	this.instance_41.setTransform(1067.5,775,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_4544();
	this.instance_42.setTransform(1067.5,775,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_4545();
	this.instance_43.setTransform(1067.5,775,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_4546();
	this.instance_44.setTransform(1067.5,775,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_4547();
	this.instance_45.setTransform(1067.5,775,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_4548();
	this.instance_46.setTransform(1067.5,775,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_4549();
	this.instance_47.setTransform(1067.5,775,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_4550();
	this.instance_48.setTransform(1067.5,775,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_4551();
	this.instance_49.setTransform(1067.5,775,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_4552();
	this.instance_50.setTransform(1067.5,775,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_4553();
	this.instance_51.setTransform(1067.5,775,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_4554();
	this.instance_52.setTransform(1067.5,775,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_4555();
	this.instance_53.setTransform(1067.5,775,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_4556();
	this.instance_54.setTransform(1067.5,775,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_4557();
	this.instance_55.setTransform(1067.5,775,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_4558();
	this.instance_56.setTransform(1067.5,775,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_4559();
	this.instance_57.setTransform(1067.5,775,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_4560();
	this.instance_58.setTransform(1067.5,775,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_4561();
	this.instance_59.setTransform(1067.5,775,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_29}]},1025).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).wait(363));

	// txt
	this.instance_60 = new lib.text2("synched",0);
	this.instance_60.setTransform(386.45,199,1,1,0,0,0,68.3,68.5);
	this.instance_60.alpha = 0;
	this.instance_60._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_60).wait(819).to({_off:false},0).to({y:219,alpha:1},10).wait(589));

	// Speech_Bubble
	this.instance_61 = new lib.speechbubble2("synched",0);
	this.instance_61.setTransform(381.25,360.9,1.5602,1.5602,0,0,180,227.6,236);
	this.instance_61._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(809).to({_off:false},0).to({startPosition:0},10).wait(599));

	// Logo_Icon
	this.instance_62 = new lib.logoicon2("synched",0);
	this.instance_62.setTransform(1030.2,753.5,0.9025,0.9025,0,0,0,50.1,50);
	this.instance_62._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_62).wait(744).to({_off:false},0).to({x:368.3,y:416.4},65,cjs.Ease.get(0.5)).wait(609));

	// txt
	this.instance_63 = new lib.text1("synched",0);
	this.instance_63.setTransform(1376.6,754.45,1,1,0,0,0,174.2,56.9);
	this.instance_63.alpha = 0;
	this.instance_63._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_63).wait(594).to({_off:false},0).to({x:1366.6,alpha:1},10).wait(814));

	// Logo_Icon
	this.instance_64 = new lib.logoicon2("synched",0);
	this.instance_64.setTransform(1030.15,753.5,0.1805,0.1805,0,0,0,50.1,49.9);
	this.instance_64._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_64).wait(569).to({_off:false},0).to({regY:50,scaleX:1.083,scaleY:1.083,x:1030.2,y:753.55},15).to({scaleX:0.9025,scaleY:0.9025,y:753.5},10).wait(824));

	// Line_Orange
	this.instance_65 = new lib.CachedBmp_4562();
	this.instance_65.setTransform(850.05,648.9,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_4563();
	this.instance_66.setTransform(850.05,648.9,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_4564();
	this.instance_67.setTransform(850.05,648.9,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_4565();
	this.instance_68.setTransform(850.05,648.9,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_4566();
	this.instance_69.setTransform(850.05,648.9,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_4567();
	this.instance_70.setTransform(850.05,648.9,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_4568();
	this.instance_71.setTransform(850.05,648.9,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_4569();
	this.instance_72.setTransform(850.05,648.9,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_4570();
	this.instance_73.setTransform(850.05,648.9,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_4571();
	this.instance_74.setTransform(850.05,648.9,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_4572();
	this.instance_75.setTransform(850.05,648.9,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_4573();
	this.instance_76.setTransform(850.05,648.9,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_4574();
	this.instance_77.setTransform(850.05,648.9,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_4575();
	this.instance_78.setTransform(850.05,648.9,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_4576();
	this.instance_79.setTransform(850.05,648.9,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_4577();
	this.instance_80.setTransform(850.05,648.9,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_4578();
	this.instance_81.setTransform(850.05,648.9,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_4579();
	this.instance_82.setTransform(850.05,648.9,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_4580();
	this.instance_83.setTransform(850.05,648.9,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_4581();
	this.instance_84.setTransform(850.05,648.9,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_4582();
	this.instance_85.setTransform(850.05,648.9,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_4583();
	this.instance_86.setTransform(850.05,648.9,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_4584();
	this.instance_87.setTransform(850.05,648.9,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_4585();
	this.instance_88.setTransform(850.05,648.9,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_4586();
	this.instance_89.setTransform(850.05,648.9,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_4587();
	this.instance_90.setTransform(850.05,648.9,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_4588();
	this.instance_91.setTransform(850.05,648.9,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_4589();
	this.instance_92.setTransform(850.05,648.9,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_4590();
	this.instance_93.setTransform(850.05,648.9,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_4591();
	this.instance_94.setTransform(850.05,648.9,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_4592();
	this.instance_95.setTransform(850.05,648.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_65}]},539).to({state:[{t:this.instance_66}]},1).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[{t:this.instance_69}]},1).to({state:[{t:this.instance_70}]},1).to({state:[{t:this.instance_71}]},1).to({state:[{t:this.instance_72}]},1).to({state:[{t:this.instance_73}]},1).to({state:[{t:this.instance_74}]},1).to({state:[{t:this.instance_75}]},1).to({state:[{t:this.instance_76}]},1).to({state:[{t:this.instance_77}]},1).to({state:[{t:this.instance_78}]},1).to({state:[{t:this.instance_79}]},1).to({state:[{t:this.instance_80}]},1).to({state:[{t:this.instance_81}]},1).to({state:[{t:this.instance_82}]},1).to({state:[{t:this.instance_83}]},1).to({state:[{t:this.instance_84}]},1).to({state:[{t:this.instance_85}]},1).to({state:[{t:this.instance_86}]},1).to({state:[{t:this.instance_87}]},1).to({state:[{t:this.instance_88}]},1).to({state:[{t:this.instance_89}]},1).to({state:[{t:this.instance_90}]},1).to({state:[{t:this.instance_91}]},1).to({state:[{t:this.instance_92}]},1).to({state:[{t:this.instance_93}]},1).to({state:[{t:this.instance_94}]},1).to({state:[{t:this.instance_95}]},1).wait(849));

	// Dot
	this.instance_96 = new lib.circlepink("synched",0);
	this.instance_96.setTransform(960.65,430.6,3.375,3.375,0,0,0,2.9,2.9);
	this.instance_96._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_96).wait(449).to({_off:false},0).to({scaleX:1,scaleY:1,x:581.05,y:584.9},60,cjs.Ease.get(1)).to({scaleX:2.25,scaleY:2.25,y:584.95},11).to({scaleX:1,scaleY:1,y:584.9},9).wait(889));

	// Img_Fibo
	this.instance_97 = new lib.fibo("synched",0);
	this.instance_97.setTransform(577.8,587.05,0.2,0.2,-90,0,0,247.3,247);
	this.instance_97._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_97).wait(421).to({_off:false},0).to({scaleX:1,scaleY:1,rotation:0,x:577.75},20,cjs.Ease.get(0.5)).wait(977));

	// Layer_290
	this.instance_98 = new lib.cashbackmatrix("synched",0);
	this.instance_98.setTransform(402.95,447.25,1,1,0,0,0,421.3,619.3);
	this.instance_98.alpha = 0;
	this.instance_98._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_98).wait(441).to({_off:false},0).to({alpha:0.3984},8).wait(969));

	// Layer_291 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_401 = new cjs.Graphics().p("EA4bAt/IT4reIAoBFIz4Leg");
	var mask_graphics_402 = new cjs.Graphics().p("AquEVIT5rdIBkCzIz3Leg");
	var mask_graphics_403 = new cjs.Graphics().p("ArNDbIT7rZICgEgIz3Ldg");
	var mask_graphics_404 = new cjs.Graphics().p("ArrCjIT7rYIDcGNIz2Leg");
	var mask_graphics_405 = new cjs.Graphics().p("AsKBrIT9rWIEYH6Iz3Ldg");
	var mask_graphics_406 = new cjs.Graphics().p("AspAyIT/rUIFUJoIz3Ldg");
	var mask_graphics_407 = new cjs.Graphics().p("AtIgGIUArSIGRLUIz3Leg");
	var mask_graphics_408 = new cjs.Graphics().p("Atng+IUCrRIHNNBIz3Leg");
	var mask_graphics_409 = new cjs.Graphics().p("AuGh2IUDrQIIJOuIz2Lfg");
	var mask_graphics_410 = new cjs.Graphics().p("AukivIUErOIJFQcIz3Lfg");
	var mask_graphics_411 = new cjs.Graphics().p("AvDjoIUGrLIKBSJIz3Leg");
	var mask_graphics_412 = new cjs.Graphics().p("AvikgIUIrKIK9T2Iz3Lfg");
	var mask_graphics_413 = new cjs.Graphics().p("AwBlYIUKrIIL5VjIz3Leg");
	var mask_graphics_414 = new cjs.Graphics().p("AwgmRIULrGIM1XRIz2Leg");
	var mask_graphics_415 = new cjs.Graphics().p("Aw/nKIUNrDINxY9Iz2Lfg");
	var mask_graphics_416 = new cjs.Graphics().p("EAp/AT8IUPrCIOtasIz4Leg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(401).to({graphics:mask_graphics_401,x:492.3,y:301.225}).wait(1).to({graphics:mask_graphics_402,x:915.925,y:556.8}).wait(1).to({graphics:mask_graphics_403,x:912.825,y:551.35}).wait(1).to({graphics:mask_graphics_404,x:909.75,y:545.875}).wait(1).to({graphics:mask_graphics_405,x:906.675,y:540.425}).wait(1).to({graphics:mask_graphics_406,x:903.6,y:534.95}).wait(1).to({graphics:mask_graphics_407,x:900.5,y:529.5}).wait(1).to({graphics:mask_graphics_408,x:897.425,y:524.025}).wait(1).to({graphics:mask_graphics_409,x:894.35,y:518.575}).wait(1).to({graphics:mask_graphics_410,x:891.275,y:513.1}).wait(1).to({graphics:mask_graphics_411,x:888.175,y:507.65}).wait(1).to({graphics:mask_graphics_412,x:885.1,y:502.175}).wait(1).to({graphics:mask_graphics_413,x:882.025,y:496.725}).wait(1).to({graphics:mask_graphics_414,x:878.95,y:491.25}).wait(1).to({graphics:mask_graphics_415,x:875.85,y:485.8}).wait(1).to({graphics:mask_graphics_416,x:492.3,y:301.225}).wait(1002));

	// Layer_292
	this.instance_99 = new lib.CachedBmp_4593();
	this.instance_99.setTransform(803.75,427.15,0.5,0.5);
	this.instance_99._off = true;

	var maskedShapeInstanceList = [this.instance_99];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_99).wait(401).to({_off:false},0).wait(1017));

	// Layer_293 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_401 = new cjs.Graphics().p("EAxvAslIW8gnIAAAnI28Ajg");
	var mask_1_graphics_402 = new cjs.Graphics().p("ArsBCIV3iuIBiAhI1wC4g");
	var mask_1_graphics_403 = new cjs.Graphics().p("Ar7CBIU0k1IDDAcI0lFNg");
	var mask_1_graphics_404 = new cjs.Graphics().p("AsKDCITvm/IEmAYIzaHjg");
	var mask_1_graphics_405 = new cjs.Graphics().p("AsZEBISspGIGHARIyPJ6g");
	var mask_1_graphics_406 = new cjs.Graphics().p("AsoFBIRorOIHpAMIxEMPg");
	var mask_1_graphics_407 = new cjs.Graphics().p("As3GBIQktXIJLAIIv5Olg");
	var mask_1_graphics_408 = new cjs.Graphics().p("AtGHCIPgvgIKtADIuuQ6g");
	var mask_1_graphics_409 = new cjs.Graphics().p("AtVICIOcxnIMPgDItiTRg");
	var mask_1_graphics_410 = new cjs.Graphics().p("AtkJFINZzwINwgIIsYVmg");
	var mask_1_graphics_411 = new cjs.Graphics().p("AtzKIIMW15IPRgMIrNX8g");
	var mask_1_graphics_412 = new cjs.Graphics().p("AuCLKILS4BIQzgRIqCaRg");
	var mask_1_graphics_413 = new cjs.Graphics().p("AuRMNIKO6JISVgYIo3cog");
	var mask_1_graphics_414 = new cjs.Graphics().p("AugNPIJK8RIT3gcInse9g");
	var mask_1_graphics_415 = new cjs.Graphics().p("AuwORIII+ZIVYghMgGhAhTg");
	var mask_1_graphics_416 = new cjs.Graphics().p("EAqsA73MAHDggiIW8gnMgFWAjqg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(401).to({graphics:mask_1_graphics_401,x:465.125,y:288.8}).wait(1).to({graphics:mask_1_graphics_402,x:855.35,y:581.4}).wait(1).to({graphics:mask_1_graphics_403,x:853.85,y:588.9}).wait(1).to({graphics:mask_1_graphics_404,x:852.35,y:596.375}).wait(1).to({graphics:mask_1_graphics_405,x:850.825,y:603.9}).wait(1).to({graphics:mask_1_graphics_406,x:849.325,y:611.375}).wait(1).to({graphics:mask_1_graphics_407,x:847.825,y:618.875}).wait(1).to({graphics:mask_1_graphics_408,x:846.325,y:626.35}).wait(1).to({graphics:mask_1_graphics_409,x:844.825,y:633.725}).wait(1).to({graphics:mask_1_graphics_410,x:843.325,y:640.95}).wait(1).to({graphics:mask_1_graphics_411,x:841.825,y:648.2}).wait(1).to({graphics:mask_1_graphics_412,x:840.325,y:655.425}).wait(1).to({graphics:mask_1_graphics_413,x:838.8,y:662.65}).wait(1).to({graphics:mask_1_graphics_414,x:837.3,y:669.875}).wait(1).to({graphics:mask_1_graphics_415,x:835.8,y:677.125}).wait(1).to({graphics:mask_1_graphics_416,x:465.125,y:399.225}).wait(1002));

	// Layer_294
	this.instance_100 = new lib.CachedBmp_4594();
	this.instance_100.setTransform(803.75,587.45,0.5,0.5);
	this.instance_100._off = true;

	var maskedShapeInstanceList = [this.instance_100];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_100).wait(401).to({_off:false},0).wait(1017));

	// Layer_295
	this.instance_101 = new lib.CachedBmp_4595();
	this.instance_101.setTransform(964.2,523.25,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_4596();
	this.instance_102.setTransform(958.75,523.25,0.5,0.5);

	this.instance_103 = new lib.CachedBmp_4597();
	this.instance_103.setTransform(953.35,523.25,0.5,0.5);

	this.instance_104 = new lib.CachedBmp_4598();
	this.instance_104.setTransform(947.9,523.25,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_4599();
	this.instance_105.setTransform(942.45,523.25,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_4600();
	this.instance_106.setTransform(937.05,523.25,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_4601();
	this.instance_107.setTransform(931.6,523.25,0.5,0.5);

	this.instance_108 = new lib.CachedBmp_4602();
	this.instance_108.setTransform(926.15,523.25,0.5,0.5);

	this.instance_109 = new lib.CachedBmp_4603();
	this.instance_109.setTransform(920.75,523.25,0.5,0.5);

	this.instance_110 = new lib.CachedBmp_4604();
	this.instance_110.setTransform(915.3,523.25,0.5,0.5);

	this.instance_111 = new lib.CachedBmp_4605();
	this.instance_111.setTransform(909.9,523.25,0.5,0.5);

	this.instance_112 = new lib.CachedBmp_4606();
	this.instance_112.setTransform(904.45,523.25,0.5,0.5);

	this.instance_113 = new lib.CachedBmp_4607();
	this.instance_113.setTransform(899,523.25,0.5,0.5);

	this.instance_114 = new lib.CachedBmp_4608();
	this.instance_114.setTransform(893.6,523.25,0.5,0.5);

	this.instance_115 = new lib.CachedBmp_4609();
	this.instance_115.setTransform(888.15,523.25,0.5,0.5);

	this.instance_116 = new lib.CachedBmp_4610();
	this.instance_116.setTransform(882.7,523.25,0.5,0.5);

	this.instance_117 = new lib.CachedBmp_4611();
	this.instance_117.setTransform(877.3,523.25,0.5,0.5);

	this.instance_118 = new lib.CachedBmp_4612();
	this.instance_118.setTransform(871.85,523.25,0.5,0.5);

	this.instance_119 = new lib.CachedBmp_4613();
	this.instance_119.setTransform(866.4,523.25,0.5,0.5);

	this.instance_120 = new lib.CachedBmp_4614();
	this.instance_120.setTransform(861,523.25,0.5,0.5);

	this.instance_121 = new lib.CachedBmp_4615();
	this.instance_121.setTransform(855.55,523.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_101}]},381).to({state:[{t:this.instance_102}]},1).to({state:[{t:this.instance_103}]},1).to({state:[{t:this.instance_104}]},1).to({state:[{t:this.instance_105}]},1).to({state:[{t:this.instance_106}]},1).to({state:[{t:this.instance_107}]},1).to({state:[{t:this.instance_108}]},1).to({state:[{t:this.instance_109}]},1).to({state:[{t:this.instance_110}]},1).to({state:[{t:this.instance_111}]},1).to({state:[{t:this.instance_112}]},1).to({state:[{t:this.instance_113}]},1).to({state:[{t:this.instance_114}]},1).to({state:[{t:this.instance_115}]},1).to({state:[{t:this.instance_116}]},1).to({state:[{t:this.instance_117}]},1).to({state:[{t:this.instance_118}]},1).to({state:[{t:this.instance_119}]},1).to({state:[{t:this.instance_120}]},1).to({state:[{t:this.instance_121}]},1).wait(1017));

	// Layer_296
	this.instance_122 = new lib.CachedBmp_4616();
	this.instance_122.setTransform(947.3,510.9,0.5,0.5);

	this.instance_123 = new lib.CachedBmp_4617();
	this.instance_123.setTransform(947.3,510.9,0.5,0.5);

	this.instance_124 = new lib.CachedBmp_4618();
	this.instance_124.setTransform(947.3,510.9,0.5,0.5);

	this.instance_125 = new lib.CachedBmp_4619();
	this.instance_125.setTransform(947.3,510.9,0.5,0.5);

	this.instance_126 = new lib.CachedBmp_4620();
	this.instance_126.setTransform(947.3,510.9,0.5,0.5);

	this.instance_127 = new lib.CachedBmp_4621();
	this.instance_127.setTransform(947.3,510.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_122}]},376).to({state:[{t:this.instance_123}]},1).to({state:[{t:this.instance_124}]},1).to({state:[{t:this.instance_125}]},1).to({state:[{t:this.instance_126}]},1).to({state:[{t:this.instance_127}]},1).wait(1037));

	// Img_Cashback
	this.instance_128 = new lib.mccashback("synched",0);
	this.instance_128.setTransform(955.25,494.65,0.72,0.72,0,0,0,71.6,75);
	this.instance_128.alpha = 0;
	this.instance_128._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_128).wait(355).to({_off:false},0).to({y:461.3,alpha:0.6719},15,cjs.Ease.get(0.5)).to({y:474.65,alpha:1},5,cjs.Ease.get(0.5)).wait(1043));

	// Text_Banks
	this.instance_129 = new lib.textbanks("synched",0);
	this.instance_129.setTransform(1551.8,330.45,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_129.alpha = 0;
	this.instance_129._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_129).wait(323).to({_off:false},0).to({alpha:1},12).wait(1083));

	// Img_Banks
	this.instance_130 = new lib.banks("synched",0);
	this.instance_130.setTransform(1526.2,288.1,0.722,0.722,0,0,0,94.5,91.5);
	this.instance_130.alpha = 0;
	this.instance_130._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_130).wait(314).to({_off:false},0).to({y:297.8,alpha:1},16).to({y:294.95},5).wait(1083));

	// Line_Pink
	this.instance_131 = new lib.CachedBmp_4622();
	this.instance_131.setTransform(1480.3,289.4,0.5,0.5);

	this.instance_132 = new lib.CachedBmp_4623();
	this.instance_132.setTransform(1474.6,289.4,0.5,0.5);

	this.instance_133 = new lib.CachedBmp_4624();
	this.instance_133.setTransform(1468.85,289.4,0.5,0.5);

	this.instance_134 = new lib.CachedBmp_4625();
	this.instance_134.setTransform(1463.15,289.4,0.5,0.5);

	this.instance_135 = new lib.CachedBmp_4626();
	this.instance_135.setTransform(1457.45,289.4,0.5,0.5);

	this.instance_136 = new lib.CachedBmp_4627();
	this.instance_136.setTransform(1451.75,289.4,0.5,0.5);

	this.instance_137 = new lib.CachedBmp_4628();
	this.instance_137.setTransform(1446.05,289.4,0.5,0.5);

	this.instance_138 = new lib.CachedBmp_4629();
	this.instance_138.setTransform(1440.3,289.4,0.5,0.5);

	this.instance_139 = new lib.CachedBmp_4630();
	this.instance_139.setTransform(1434.6,289.4,0.5,0.5);

	this.instance_140 = new lib.CachedBmp_4631();
	this.instance_140.setTransform(1428.9,289.4,0.5,0.5);

	this.instance_141 = new lib.CachedBmp_4632();
	this.instance_141.setTransform(1423.2,289.4,0.5,0.5);

	this.instance_142 = new lib.CachedBmp_4633();
	this.instance_142.setTransform(1417.45,289.4,0.5,0.5);

	this.instance_143 = new lib.CachedBmp_4634();
	this.instance_143.setTransform(1411.75,289.4,0.5,0.5);

	this.instance_144 = new lib.CachedBmp_4635();
	this.instance_144.setTransform(1402.3,289.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_131}]},301).to({state:[{t:this.instance_132}]},1).to({state:[{t:this.instance_133}]},1).to({state:[{t:this.instance_134}]},1).to({state:[{t:this.instance_135}]},1).to({state:[{t:this.instance_136}]},1).to({state:[{t:this.instance_137}]},1).to({state:[{t:this.instance_138}]},1).to({state:[{t:this.instance_139}]},1).to({state:[{t:this.instance_140}]},1).to({state:[{t:this.instance_141}]},1).to({state:[{t:this.instance_142}]},1).to({state:[{t:this.instance_143}]},1).to({state:[{t:this.instance_144}]},1).wait(1104));

	// Text_LP_s
	this.instance_145 = new lib.textlp("synched",0);
	this.instance_145.setTransform(1431.8,215.7,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_145.alpha = 0;
	this.instance_145._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_145).wait(289).to({_off:false},0).to({alpha:1},12).wait(1117));

	// Img_LP_s
	this.instance_146 = new lib.liquidityproviders("synched",0);
	this.instance_146.setTransform(1458.3,244.55,0.722,0.722,0,0,0,154.5,187.6);
	this.instance_146.alpha = 0;
	this.instance_146._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_146).wait(281).to({_off:false},0).to({regY:187.4,y:250.9,alpha:1},15).to({regY:187.6,y:248.15},5).wait(1117));

	// Text_Cashback
	this.instance_147 = new lib.textcashback("synched",0);
	this.instance_147.setTransform(1350.85,482.05,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_147.alpha = 0;
	this.instance_147._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_147).wait(250).to({_off:false},0).to({alpha:1},10).wait(1158));

	// Line_Orange
	this.instance_148 = new lib.CachedBmp_4636();
	this.instance_148.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_149 = new lib.CachedBmp_4637();
	this.instance_149.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_150 = new lib.CachedBmp_4638();
	this.instance_150.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_151 = new lib.CachedBmp_4639();
	this.instance_151.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_152 = new lib.CachedBmp_4640();
	this.instance_152.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_153 = new lib.CachedBmp_4641();
	this.instance_153.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_154 = new lib.CachedBmp_4642();
	this.instance_154.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_155 = new lib.CachedBmp_4643();
	this.instance_155.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_156 = new lib.CachedBmp_4644();
	this.instance_156.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_157 = new lib.CachedBmp_4645();
	this.instance_157.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_158 = new lib.CachedBmp_4646();
	this.instance_158.setTransform(1360.9,490.4,0.5,0.5);

	this.instance_159 = new lib.CachedBmp_4647();
	this.instance_159.setTransform(1360.9,490.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_148}]},240).to({state:[{t:this.instance_149}]},1).to({state:[{t:this.instance_150}]},1).to({state:[{t:this.instance_151}]},1).to({state:[{t:this.instance_152}]},1).to({state:[{t:this.instance_153}]},1).to({state:[{t:this.instance_154}]},1).to({state:[{t:this.instance_155}]},1).to({state:[{t:this.instance_156}]},1).to({state:[{t:this.instance_157}]},1).to({state:[{t:this.instance_158}]},1).to({state:[{t:this.instance_159}]},1).wait(1167));

	// Line_Orange
	this.instance_160 = new lib.CachedBmp_4648();
	this.instance_160.setTransform(1385.1,474.75,0.5,0.5);

	this.instance_161 = new lib.CachedBmp_4649();
	this.instance_161.setTransform(1380.25,474.75,0.5,0.5);

	this.instance_162 = new lib.CachedBmp_4650();
	this.instance_162.setTransform(1375.4,474.75,0.5,0.5);

	this.instance_163 = new lib.CachedBmp_4651();
	this.instance_163.setTransform(1370.6,474.75,0.5,0.5);

	this.instance_164 = new lib.CachedBmp_4652();
	this.instance_164.setTransform(1365.75,474.75,0.5,0.5);

	this.instance_165 = new lib.CachedBmp_4653();
	this.instance_165.setTransform(1360.9,474.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_160}]},235).to({state:[{t:this.instance_161}]},1).to({state:[{t:this.instance_162}]},1).to({state:[{t:this.instance_163}]},1).to({state:[{t:this.instance_164}]},1).to({state:[{t:this.instance_165}]},1).wait(1178));

	// Icon_Logo
	this.instance_166 = new lib.logoicon("synched",0);
	this.instance_166.setTransform(1424.75,462,0.06,0.06,0,0,0,189.2,186.7);
	this.instance_166.alpha = 0;
	this.instance_166._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_166).wait(209).to({_off:false},0).to({regX:189,regY:186.5,scaleX:0.3,scaleY:0.3,alpha:1},16).wait(1193));

	// Text_Rebates
	this.instance_167 = new lib.textrebates("synched",0);
	this.instance_167.setTransform(1319.2,437.85,0.9025,0.9025,0,0,0,98.9,39.9);
	this.instance_167.alpha = 0;
	this.instance_167._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_167).wait(209).to({_off:false},0).to({alpha:1},16).wait(1193));

	// Line_Pink
	this.instance_168 = new lib.CachedBmp_4654();
	this.instance_168.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_169 = new lib.CachedBmp_4655();
	this.instance_169.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_170 = new lib.CachedBmp_4656();
	this.instance_170.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_171 = new lib.CachedBmp_4657();
	this.instance_171.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_172 = new lib.CachedBmp_4658();
	this.instance_172.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_173 = new lib.CachedBmp_4659();
	this.instance_173.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_174 = new lib.CachedBmp_4660();
	this.instance_174.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_175 = new lib.CachedBmp_4661();
	this.instance_175.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_176 = new lib.CachedBmp_4662();
	this.instance_176.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_177 = new lib.CachedBmp_4663();
	this.instance_177.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_178 = new lib.CachedBmp_4664();
	this.instance_178.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_179 = new lib.CachedBmp_4665();
	this.instance_179.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_180 = new lib.CachedBmp_4666();
	this.instance_180.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_181 = new lib.CachedBmp_4667();
	this.instance_181.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_182 = new lib.CachedBmp_4668();
	this.instance_182.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_183 = new lib.CachedBmp_4669();
	this.instance_183.setTransform(1327.25,407.3,0.5,0.5);

	this.instance_184 = new lib.CachedBmp_4670();
	this.instance_184.setTransform(1327.25,407.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_168}]},189).to({state:[{t:this.instance_169}]},1).to({state:[{t:this.instance_170}]},1).to({state:[{t:this.instance_171}]},1).to({state:[{t:this.instance_172}]},1).to({state:[{t:this.instance_173}]},1).to({state:[{t:this.instance_174}]},1).to({state:[{t:this.instance_175}]},1).to({state:[{t:this.instance_176}]},1).to({state:[{t:this.instance_177}]},1).to({state:[{t:this.instance_178}]},1).to({state:[{t:this.instance_179}]},1).to({state:[{t:this.instance_180}]},1).to({state:[{t:this.instance_181}]},1).to({state:[{t:this.instance_182}]},1).to({state:[{t:this.instance_183}]},1).to({state:[{t:this.instance_184}]},1).wait(1213));

	// Layer_309
	this.instance_185 = new lib.CachedBmp_4671();
	this.instance_185.setTransform(1249.05,423.4,0.5,0.5);

	this.instance_186 = new lib.CachedBmp_4672();
	this.instance_186.setTransform(1249.05,420.4,0.5,0.5);

	this.instance_187 = new lib.CachedBmp_4673();
	this.instance_187.setTransform(1249.05,417.4,0.5,0.5);

	this.instance_188 = new lib.CachedBmp_4674();
	this.instance_188.setTransform(1249.05,414.4,0.5,0.5);

	this.instance_189 = new lib.CachedBmp_4675();
	this.instance_189.setTransform(1249.05,411.4,0.5,0.5);

	this.instance_190 = new lib.CachedBmp_4676();
	this.instance_190.setTransform(1249.05,408.45,0.5,0.5);

	this.instance_191 = new lib.CachedBmp_4677();
	this.instance_191.setTransform(1249.05,405.45,0.5,0.5);

	this.instance_192 = new lib.CachedBmp_4678();
	this.instance_192.setTransform(1249.05,402.45,0.5,0.5);

	this.instance_193 = new lib.CachedBmp_4679();
	this.instance_193.setTransform(1249.05,399.45,0.5,0.5);

	this.instance_194 = new lib.CachedBmp_4680();
	this.instance_194.setTransform(1249.05,396.45,0.5,0.5);

	this.instance_195 = new lib.CachedBmp_4681();
	this.instance_195.setTransform(1249.05,393.45,0.5,0.5);

	this.instance_196 = new lib.CachedBmp_4682();
	this.instance_196.setTransform(1249.05,389.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_185}]},154).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_187}]},1).to({state:[{t:this.instance_188}]},1).to({state:[{t:this.instance_189}]},1).to({state:[{t:this.instance_190}]},1).to({state:[{t:this.instance_191}]},1).to({state:[{t:this.instance_192}]},1).to({state:[{t:this.instance_193}]},1).to({state:[{t:this.instance_194}]},1).to({state:[{t:this.instance_195}]},1).to({state:[{t:this.instance_196}]},1).wait(1253));

	// Layer_310
	this.instance_197 = new lib.CachedBmp_4683();
	this.instance_197.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_198 = new lib.CachedBmp_4684();
	this.instance_198.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_199 = new lib.CachedBmp_4685();
	this.instance_199.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_200 = new lib.CachedBmp_4686();
	this.instance_200.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_201 = new lib.CachedBmp_4687();
	this.instance_201.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_202 = new lib.CachedBmp_4688();
	this.instance_202.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_203 = new lib.CachedBmp_4689();
	this.instance_203.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_204 = new lib.CachedBmp_4690();
	this.instance_204.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_205 = new lib.CachedBmp_4691();
	this.instance_205.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_206 = new lib.CachedBmp_4692();
	this.instance_206.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_207 = new lib.CachedBmp_4693();
	this.instance_207.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_208 = new lib.CachedBmp_4694();
	this.instance_208.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_209 = new lib.CachedBmp_4695();
	this.instance_209.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_210 = new lib.CachedBmp_4696();
	this.instance_210.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_211 = new lib.CachedBmp_4697();
	this.instance_211.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_212 = new lib.CachedBmp_4698();
	this.instance_212.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_213 = new lib.CachedBmp_4699();
	this.instance_213.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_214 = new lib.CachedBmp_4700();
	this.instance_214.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_215 = new lib.CachedBmp_4701();
	this.instance_215.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_216 = new lib.CachedBmp_4702();
	this.instance_216.setTransform(1079.75,327.3,0.5,0.5);

	this.instance_217 = new lib.CachedBmp_4703();
	this.instance_217.setTransform(1079.75,327.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_197}]},134).to({state:[{t:this.instance_198}]},1).to({state:[{t:this.instance_199}]},1).to({state:[{t:this.instance_200}]},1).to({state:[{t:this.instance_201}]},1).to({state:[{t:this.instance_202}]},1).to({state:[{t:this.instance_203}]},1).to({state:[{t:this.instance_204}]},1).to({state:[{t:this.instance_205}]},1).to({state:[{t:this.instance_206}]},1).to({state:[{t:this.instance_207}]},1).to({state:[{t:this.instance_208}]},1).to({state:[{t:this.instance_209}]},1).to({state:[{t:this.instance_210}]},1).to({state:[{t:this.instance_211}]},1).to({state:[{t:this.instance_212}]},1).to({state:[{t:this.instance_213}]},1).to({state:[{t:this.instance_214}]},1).to({state:[{t:this.instance_215}]},1).to({state:[{t:this.instance_216}]},1).to({state:[{t:this.instance_217}]},1).wait(1264));

	// Img_Broker
	this.instance_218 = new lib.broker("synched",0);
	this.instance_218.setTransform(1362.1,314.3,0.722,0.722,0,0,0,61.9,82.8);
	this.instance_218.alpha = 0;
	this.instance_218._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_218).wait(154).to({_off:false},0).to({y:321.6,alpha:1},10).to({x:1360.4,y:321.25},5).wait(1249));

	// Dots_Pink
	this.instance_219 = new lib.dotpink("synched",0);
	this.instance_219.setTransform(1418.15,588.4,0.1733,0.1733,0,0,0,7.5,4.4);
	this.instance_219._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_219).wait(85).to({_off:false},0).to({regX:7.6,scaleX:1.012,scaleY:1.012,y:588.45},10).wait(1323));

	// Line_Pink
	this.instance_220 = new lib.CachedBmp_4704();
	this.instance_220.setTransform(1359.55,618.15,0.5,0.5);

	this.instance_221 = new lib.CachedBmp_4705();
	this.instance_221.setTransform(1359.55,615.1,0.5,0.5);

	this.instance_222 = new lib.CachedBmp_4706();
	this.instance_222.setTransform(1359.55,612.1,0.5,0.5);

	this.instance_223 = new lib.CachedBmp_4707();
	this.instance_223.setTransform(1359.55,609.05,0.5,0.5);

	this.instance_224 = new lib.CachedBmp_4708();
	this.instance_224.setTransform(1359.55,606.05,0.5,0.5);

	this.instance_225 = new lib.CachedBmp_4709();
	this.instance_225.setTransform(1359.55,603.05,0.5,0.5);

	this.instance_226 = new lib.CachedBmp_4710();
	this.instance_226.setTransform(1359.55,600,0.5,0.5);

	this.instance_227 = new lib.CachedBmp_4711();
	this.instance_227.setTransform(1359.55,597,0.5,0.5);

	this.instance_228 = new lib.CachedBmp_4712();
	this.instance_228.setTransform(1359.55,593.95,0.5,0.5);

	this.instance_229 = new lib.CachedBmp_4713();
	this.instance_229.setTransform(1359.55,590.95,0.5,0.5);

	this.instance_230 = new lib.CachedBmp_4714();
	this.instance_230.setTransform(1359.55,587.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_220}]},75).to({state:[{t:this.instance_221}]},1).to({state:[{t:this.instance_222}]},1).to({state:[{t:this.instance_223}]},1).to({state:[{t:this.instance_224}]},1).to({state:[{t:this.instance_225}]},1).to({state:[{t:this.instance_226}]},1).to({state:[{t:this.instance_227}]},1).to({state:[{t:this.instance_228}]},1).to({state:[{t:this.instance_229}]},1).to({state:[{t:this.instance_230}]},1).wait(1333));

	// Line_Pink
	this.instance_231 = new lib.CachedBmp_4715();
	this.instance_231.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_232 = new lib.CachedBmp_4716();
	this.instance_232.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_233 = new lib.CachedBmp_4717();
	this.instance_233.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_234 = new lib.CachedBmp_4718();
	this.instance_234.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_235 = new lib.CachedBmp_4719();
	this.instance_235.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_236 = new lib.CachedBmp_4720();
	this.instance_236.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_237 = new lib.CachedBmp_4721();
	this.instance_237.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_238 = new lib.CachedBmp_4722();
	this.instance_238.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_239 = new lib.CachedBmp_4723();
	this.instance_239.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_240 = new lib.CachedBmp_4724();
	this.instance_240.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_241 = new lib.CachedBmp_4725();
	this.instance_241.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_242 = new lib.CachedBmp_4726();
	this.instance_242.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_243 = new lib.CachedBmp_4727();
	this.instance_243.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_244 = new lib.CachedBmp_4728();
	this.instance_244.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_245 = new lib.CachedBmp_4729();
	this.instance_245.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_246 = new lib.CachedBmp_4730();
	this.instance_246.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_247 = new lib.CachedBmp_4731();
	this.instance_247.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_248 = new lib.CachedBmp_4732();
	this.instance_248.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_249 = new lib.CachedBmp_4733();
	this.instance_249.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_250 = new lib.CachedBmp_4734();
	this.instance_250.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_251 = new lib.CachedBmp_4735();
	this.instance_251.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_252 = new lib.CachedBmp_4736();
	this.instance_252.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_253 = new lib.CachedBmp_4737();
	this.instance_253.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_254 = new lib.CachedBmp_4738();
	this.instance_254.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_255 = new lib.CachedBmp_4739();
	this.instance_255.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_256 = new lib.CachedBmp_4740();
	this.instance_256.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_257 = new lib.CachedBmp_4741();
	this.instance_257.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_258 = new lib.CachedBmp_4742();
	this.instance_258.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_259 = new lib.CachedBmp_4743();
	this.instance_259.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_260 = new lib.CachedBmp_4744();
	this.instance_260.setTransform(1117.1,479.55,0.5,0.5);

	this.instance_261 = new lib.CachedBmp_4745();
	this.instance_261.setTransform(1117.1,479.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_231}]},45).to({state:[{t:this.instance_232}]},1).to({state:[{t:this.instance_233}]},1).to({state:[{t:this.instance_234}]},1).to({state:[{t:this.instance_235}]},1).to({state:[{t:this.instance_236}]},1).to({state:[{t:this.instance_237}]},1).to({state:[{t:this.instance_238}]},1).to({state:[{t:this.instance_239}]},1).to({state:[{t:this.instance_240}]},1).to({state:[{t:this.instance_241}]},1).to({state:[{t:this.instance_242}]},1).to({state:[{t:this.instance_243}]},1).to({state:[{t:this.instance_244}]},1).to({state:[{t:this.instance_245}]},1).to({state:[{t:this.instance_246}]},1).to({state:[{t:this.instance_247}]},1).to({state:[{t:this.instance_248}]},1).to({state:[{t:this.instance_249}]},1).to({state:[{t:this.instance_250}]},1).to({state:[{t:this.instance_251}]},1).to({state:[{t:this.instance_252}]},1).to({state:[{t:this.instance_253}]},1).to({state:[{t:this.instance_254}]},1).to({state:[{t:this.instance_255}]},1).to({state:[{t:this.instance_256}]},1).to({state:[{t:this.instance_257}]},1).to({state:[{t:this.instance_258}]},1).to({state:[{t:this.instance_259}]},1).to({state:[{t:this.instance_260}]},1).to({state:[{t:this.instance_261}]},1).wait(1343));

	// Line_Pink
	this.instance_262 = new lib.CachedBmp_4746();
	this.instance_262.setTransform(1129.7,292.1,0.5,0.5);

	this.instance_263 = new lib.CachedBmp_4747();
	this.instance_263.setTransform(1124.6,289.25,0.5,0.5);

	this.instance_264 = new lib.CachedBmp_4748();
	this.instance_264.setTransform(1119.5,286.45,0.5,0.5);

	this.instance_265 = new lib.CachedBmp_4749();
	this.instance_265.setTransform(1114.45,283.6,0.5,0.5);

	this.instance_266 = new lib.CachedBmp_4750();
	this.instance_266.setTransform(1109.35,280.8,0.5,0.5);

	this.instance_267 = new lib.CachedBmp_4751();
	this.instance_267.setTransform(1104.25,278,0.5,0.5);

	this.instance_268 = new lib.CachedBmp_4752();
	this.instance_268.setTransform(1099.15,275.15,0.5,0.5);

	this.instance_269 = new lib.CachedBmp_4753();
	this.instance_269.setTransform(1094.05,272.35,0.5,0.5);

	this.instance_270 = new lib.CachedBmp_4754();
	this.instance_270.setTransform(1089,269.5,0.5,0.5);

	this.instance_271 = new lib.CachedBmp_4755();
	this.instance_271.setTransform(1083.9,266.7,0.5,0.5);

	this.instance_272 = new lib.CachedBmp_4756();
	this.instance_272.setTransform(1078.8,263.85,0.5,0.5);

	this.instance_273 = new lib.CachedBmp_4757();
	this.instance_273.setTransform(1080.65,263.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_262}]},109).to({state:[{t:this.instance_263}]},1).to({state:[{t:this.instance_264}]},1).to({state:[{t:this.instance_265}]},1).to({state:[{t:this.instance_266}]},1).to({state:[{t:this.instance_267}]},1).to({state:[{t:this.instance_268}]},1).to({state:[{t:this.instance_269}]},1).to({state:[{t:this.instance_270}]},1).to({state:[{t:this.instance_271}]},1).to({state:[{t:this.instance_272}]},1).to({state:[{t:this.instance_273}]},1).wait(1298));

	// Line_Pink
	this.instance_274 = new lib.CachedBmp_4758();
	this.instance_274.setTransform(959.15,393.5,0.5,0.5);

	this.instance_275 = new lib.CachedBmp_4759();
	this.instance_275.setTransform(959.15,390.1,0.5,0.5);

	this.instance_276 = new lib.CachedBmp_4760();
	this.instance_276.setTransform(959.15,386.7,0.5,0.5);

	this.instance_277 = new lib.CachedBmp_4761();
	this.instance_277.setTransform(959.15,383.3,0.5,0.5);

	this.instance_278 = new lib.CachedBmp_4762();
	this.instance_278.setTransform(959.15,379.95,0.5,0.5);

	this.instance_279 = new lib.CachedBmp_4763();
	this.instance_279.setTransform(959.15,376.55,0.5,0.5);

	this.instance_280 = new lib.CachedBmp_4764();
	this.instance_280.setTransform(959.15,373.15,0.5,0.5);

	this.instance_281 = new lib.CachedBmp_4765();
	this.instance_281.setTransform(959.15,369.75,0.5,0.5);

	this.instance_282 = new lib.CachedBmp_4766();
	this.instance_282.setTransform(959.15,366.35,0.5,0.5);

	this.instance_283 = new lib.CachedBmp_4767();
	this.instance_283.setTransform(959.15,362.95,0.5,0.5);

	this.instance_284 = new lib.CachedBmp_4768();
	this.instance_284.setTransform(959.15,359.55,0.5,0.5);

	this.instance_285 = new lib.CachedBmp_4769();
	this.instance_285.setTransform(959.15,356.2,0.5,0.5);

	this.instance_286 = new lib.CachedBmp_4770();
	this.instance_286.setTransform(959.15,352.8,0.5,0.5);

	this.instance_287 = new lib.CachedBmp_4771();
	this.instance_287.setTransform(959.15,349.4,0.5,0.5);

	this.instance_288 = new lib.CachedBmp_4772();
	this.instance_288.setTransform(959.15,346,0.5,0.5);

	this.instance_289 = new lib.CachedBmp_4773();
	this.instance_289.setTransform(959.15,342.6,0.5,0.5);

	this.instance_290 = new lib.CachedBmp_4774();
	this.instance_290.setTransform(959.15,339.2,0.5,0.5);

	this.instance_291 = new lib.CachedBmp_4775();
	this.instance_291.setTransform(959.15,335.8,0.5,0.5);

	this.instance_292 = new lib.CachedBmp_4776();
	this.instance_292.setTransform(959.15,332.4,0.5,0.5);

	this.instance_293 = new lib.CachedBmp_4777();
	this.instance_293.setTransform(959.15,329.05,0.5,0.5);

	this.instance_294 = new lib.CachedBmp_4778();
	this.instance_294.setTransform(959.15,325.65,0.5,0.5);

	this.instance_295 = new lib.CachedBmp_4779();
	this.instance_295.setTransform(959.15,322.25,0.5,0.5);

	this.instance_296 = new lib.CachedBmp_4780();
	this.instance_296.setTransform(959.15,318.85,0.5,0.5);

	this.instance_297 = new lib.CachedBmp_4781();
	this.instance_297.setTransform(959.15,315.45,0.5,0.5);

	this.instance_298 = new lib.CachedBmp_4782();
	this.instance_298.setTransform(959.15,312.05,0.5,0.5);

	this.instance_299 = new lib.CachedBmp_4783();
	this.instance_299.setTransform(959.15,308.65,0.5,0.5);

	this.instance_300 = new lib.CachedBmp_4784();
	this.instance_300.setTransform(959.15,305.3,0.5,0.5);

	this.instance_301 = new lib.CachedBmp_4785();
	this.instance_301.setTransform(959.15,301.9,0.5,0.5);

	this.instance_302 = new lib.CachedBmp_4786();
	this.instance_302.setTransform(959.15,298.5,0.5,0.5);

	this.instance_303 = new lib.CachedBmp_4787();
	this.instance_303.setTransform(959.15,295.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_274}]},80).to({state:[{t:this.instance_275}]},1).to({state:[{t:this.instance_276}]},1).to({state:[{t:this.instance_277}]},1).to({state:[{t:this.instance_278}]},1).to({state:[{t:this.instance_279}]},1).to({state:[{t:this.instance_280}]},1).to({state:[{t:this.instance_281}]},1).to({state:[{t:this.instance_282}]},1).to({state:[{t:this.instance_283}]},1).to({state:[{t:this.instance_284}]},1).to({state:[{t:this.instance_285}]},1).to({state:[{t:this.instance_286}]},1).to({state:[{t:this.instance_287}]},1).to({state:[{t:this.instance_288}]},1).to({state:[{t:this.instance_289}]},1).to({state:[{t:this.instance_290}]},1).to({state:[{t:this.instance_291}]},1).to({state:[{t:this.instance_292}]},1).to({state:[{t:this.instance_293}]},1).to({state:[{t:this.instance_294}]},1).to({state:[{t:this.instance_295}]},1).to({state:[{t:this.instance_296}]},1).to({state:[{t:this.instance_297}]},1).to({state:[{t:this.instance_298}]},1).to({state:[{t:this.instance_299}]},1).to({state:[{t:this.instance_300}]},1).to({state:[{t:this.instance_301}]},1).to({state:[{t:this.instance_302}]},1).to({state:[{t:this.instance_303}]},1).wait(1309));

	// Line_Pink
	this.instance_304 = new lib.CachedBmp_4788();
	this.instance_304.setTransform(959.1,423.9,0.5,0.5);

	this.instance_305 = new lib.CachedBmp_4789();
	this.instance_305.setTransform(959.1,418.25,0.5,0.5);

	this.instance_306 = new lib.CachedBmp_4790();
	this.instance_306.setTransform(959.1,412.55,0.5,0.5);

	this.instance_307 = new lib.CachedBmp_4791();
	this.instance_307.setTransform(959.1,406.9,0.5,0.5);

	this.instance_308 = new lib.CachedBmp_4792();
	this.instance_308.setTransform(959.1,401.2,0.5,0.5);

	this.instance_309 = new lib.CachedBmp_4793();
	this.instance_309.setTransform(959.1,395.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_304}]},75).to({state:[{t:this.instance_305}]},1).to({state:[{t:this.instance_306}]},1).to({state:[{t:this.instance_307}]},1).to({state:[{t:this.instance_308}]},1).to({state:[{t:this.instance_309}]},1).wait(1338));

	// Img_Couple
	this.instance_310 = new lib.imgcouple("synched",0);
	this.instance_310.setTransform(1583.3,519.95,0.8,0.8,0,0,0,53.7,109);
	this.instance_310._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_310).wait(19).to({_off:false},0).to({regX:53.6,regY:108.9,scaleX:1,scaleY:1,x:1573.25,y:499.9},15).wait(1384));

	// Img_Pig
	this.instance_311 = new lib.imgpig("synched",0);
	this.instance_311.setTransform(1464.95,562.7,0.162,0.162,0,0,0,45.7,48.1);
	this.instance_311.alpha = 0;
	this.instance_311._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_311).wait(9).to({_off:false},0).to({regX:45.6,regY:48,scaleX:0.81,scaleY:0.81,x:1460.95,y:545.75,alpha:1},15).wait(1394));

	// Img_Trading_Account
	this.instance_312 = new lib.tradingaccount("synched",0);
	this.instance_312.setTransform(1041.35,409.2,0.9025,0.9025,0,0,0,145.7,119.7);
	this.instance_312.alpha = 0;
	this.instance_312._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_312).wait(9).to({_off:false},0).to({x:1031.45,y:399.3,alpha:1},15).wait(1394));

	// Bg Grid
	this.instance_313 = new lib.grid("synched",0);
	this.instance_313.setTransform(865.05,575.9,0.9927,0.9927,0,0,0,960.1,510.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_313).wait(1418));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(872,600.5,988.0999999999999,482.29999999999995);
// library properties:
lib.properties = {
	id: 'EA5571A2295DF7458D9934B992E3E739',
	width: 1920,
	height: 1080,
	fps: 90,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"step2-buycashbacklicenses/images/imgbggrid.png", id:"imgbggrid"},
		{src:"step2-buycashbacklicenses/images/step2_buycashbacklicenses_atlas_.png", id:"step2_buycashbacklicenses_atlas_"},
		{src:"step2-buycashbacklicenses/images/step2_buycashbacklicenses_atlas_2.png", id:"step2_buycashbacklicenses_atlas_2"},
		{src:"step2-buycashbacklicenses/images/step2_buycashbacklicenses_atlas_3.png", id:"step2_buycashbacklicenses_atlas_3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EA5571A2295DF7458D9934B992E3E739'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;