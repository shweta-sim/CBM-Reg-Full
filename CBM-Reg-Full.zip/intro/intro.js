(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"intro_atlas_", frames: [[1202,366,587,179],[1627,547,357,118],[0,1833,1783,186],[0,1202,885,629],[887,1202,826,518],[1986,366,52,222],[1202,963,416,52],[1404,763,175,71],[1404,836,97,47],[1581,763,25,31],[1503,836,97,47],[1581,796,25,31],[1791,366,97,47],[887,1722,423,106],[1312,1722,423,106],[1202,547,423,106],[1202,0,806,181],[1202,655,423,106],[1202,183,806,181],[0,0,1200,1200],[1627,667,200,198],[1202,763,200,198]]}
];


// symbols:



(lib.CachedBmp_101 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(img.CachedBmp_100);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3045,173);


(lib.CachedBmp_99 = function() {
	this.initialize(img.CachedBmp_99);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3093,267);


(lib.CachedBmp_98 = function() {
	this.initialize(img.CachedBmp_98);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3100,482);


(lib.CachedBmp_97 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(img.CachedBmp_76);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3840,2160);


(lib.CachedBmp_75 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["intro_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.txtwelcome = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_101();
	this.instance.setTransform(103.1,-13.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(103.1,-13.5,293.5,89.5);


(lib.txtthiswizard = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_100();
	this.instance.setTransform(-128.9,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128.9,0,1522.5,86.5);


(lib.txtthiswilltake = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_99();
	this.instance.setTransform(-11.85,0,0.1692,0.1692);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,0,523.3,45.2);


(lib.txtregistering = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_98();
	this.instance.setTransform(-245.4,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.4,0,1550,241);


(lib.txthithere = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_97();
	this.instance.setTransform(43.6,15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(43.6,15,178.5,59);


(lib.txtcbmglobal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_96();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,891.5,93);


(lib.speechbubble = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_95();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_94();
	this.instance_1.setTransform(42.05,55.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,455.1,314.5);


(lib.logoiconlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(89,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89,88,200,198);


(lib.logoicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap10();
	this.instance.setTransform(89,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89,88,200,198);


(lib.clockhandsm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_93();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,26,111);


(lib.clockhandbig = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_92();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,208,26);


(lib.btnreplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay.svg
	this.instance = new lib.CachedBmp_86();
	this.instance.setTransform(132.55,72,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_85();
	this.instance_1.setTransform(81.1,68.05,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_90();
	this.instance_2.setTransform(132.55,72,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_87();
	this.instance_3.setTransform(81.1,68.05,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_89();
	this.instance_4.setTransform(81.1,68.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_91();
	this.instance_5.setTransform(68.5,62.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_4},{t:this.instance_2}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68.5,62.7,87.5,35.5);


(lib.btnletsstart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.CachedBmp_78();
	this.instance.setTransform(-9.6,63.55,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_83();
	this.instance_1.setTransform(-107.05,44.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_80();
	this.instance_2.setTransform(-9.6,63.55,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_81();
	this.instance_3.setTransform(-107.05,44.1,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_82();
	this.instance_4.setTransform(-9.6,63.55,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_84();
	this.instance_5.setTransform(-9.6,63.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_3},{t:this.instance_4}]},1).to({state:[{t:this.instance_1},{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-107,44.1,403,90.5);


(lib.bgintro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_76();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,1080);


(lib.animclock = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_159 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(159).call(this.frame_159).wait(41));

	// Layer_3
	this.instance = new lib.clockhandbig("synched",0);
	this.instance.setTransform(302.75,300.8,1,1,0,0,0,208,12.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:90,x:302.8,y:300.85},39).to({rotation:180,x:302.75,y:300.9},40).to({rotation:270,x:302.7,y:300.85},40).to({rotation:360,x:302.75,y:300.8},40).wait(41));

	// Layer_2
	this.instance_1 = new lib.clockhandsm("synched",0);
	this.instance_1.setTransform(299.85,300.9,1,1,0,0,0,12.8,111);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:110.9,rotation:135.0006,x:299.95},199).wait(1));

	// Layer_1
	this.instance_2 = new lib.CachedBmp_75();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(200));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600,600);


// stage content:
(lib.intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_634 = function() {
		this.stop();
		
		this.replayBtn.addEventListener("click", fl_ClickToGoToAndPlayAtFrame1.bind(this));
		function fl_ClickToGoToAndPlayAtFrame1()
		{
			this.gotoAndPlay(0);
		}
		
		this.letsstartBtn.addEventListener("click", fl_ClickToGoToWebPage_1);
		
		function fl_ClickToGoToWebPage_1() {
			window.open("step1-registration-demo.php", "_self");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(634).call(this.frame_634).wait(16));

	// Btn_Replay
	this.replayBtn = new lib.btnreplay();
	this.replayBtn.name = "replayBtn";
	this.replayBtn.setTransform(1817,72.75,1,1,0,0,0,112,80.3);
	this.replayBtn.alpha = 0;
	this.replayBtn._off = true;
	new cjs.ButtonHelper(this.replayBtn, 0, 1, 2, false, new lib.btnreplay(), 3);

	this.timeline.addTween(cjs.Tween.get(this.replayBtn).wait(619).to({_off:false},0).to({x:1827,alpha:1},15).wait(16));

	// Layer_1
	this.letsstartBtn = new lib.btnletsstart();
	this.letsstartBtn.name = "letsstartBtn";
	this.letsstartBtn.setTransform(960,692.25,1,1,0,0,0,94.4,89.4);
	this.letsstartBtn.alpha = 0;
	this.letsstartBtn._off = true;
	new cjs.ButtonHelper(this.letsstartBtn, 0, 1, 2, false, new lib.btnletsstart(), 3);

	this.timeline.addTween(cjs.Tween.get(this.letsstartBtn).wait(599).to({_off:false},0).to({y:672.25,alpha:1},15).wait(36));

	// Txt___This_will_take
	this.instance = new lib.txtthiswilltake("synched",0);
	this.instance.setTransform(959.85,540.15,2.9548,2.9548,0,0,0,249.8,22.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(549).to({_off:false},0).to({scaleX:1.9699,scaleY:1.9699,x:959.95,y:540.05,alpha:1},15,cjs.Ease.get(0.5)).wait(86));

	// Clock
	this.instance_1 = new lib.animclock();
	this.instance_1.setTransform(960,540,1,1,0,0,0,300,300);
	this.instance_1.alpha = 0.4883;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(549).to({_off:false},0).wait(101));

	// Txt___Registering
	this.instance_2 = new lib.txtregistering("synched",0);
	this.instance_2.setTransform(960,679,1,1,0,0,0,529.6,120.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(344).to({_off:false},0).to({y:659,alpha:1},15).wait(60).to({startPosition:0},0).to({y:679,alpha:0},15).to({_off:true},1).wait(215));

	// Txt___This_wizard
	this.instance_3 = new lib.txtthiswizard("synched",0);
	this.instance_3.setTransform(960.05,543.6,1,1,0,0,0,632.5,43.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(254).to({_off:false},0).to({y:523.6,alpha:1},15).wait(150).to({startPosition:0},0).to({y:543.6,alpha:0},15).to({_off:true},1).wait(215));

	// Txt___Welcome
	this.instance_4 = new lib.txtwelcome("synched",0);
	this.instance_4.setTransform(959.95,423.45,1,1,0,0,0,249.8,43.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(0.5)).wait(60).to({startPosition:0},0).to({y:403.45,alpha:0},15,cjs.Ease.get(0.5)).to({_off:true},1).wait(460));

	// Txt___Hi
	this.instance_5 = new lib.txthithere("synched",0);
	this.instance_5.setTransform(960.05,343.95,1,1,0,0,0,132.8,43.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(84).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(0.5)).wait(60).to({startPosition:0},0).to({y:326.95,alpha:0},15,cjs.Ease.get(0.5)).to({_off:true},1).wait(475));

	// Speech_Bubble1
	this.instance_6 = new lib.speechbubble("synched",0);
	this.instance_6.setTransform(738.8,567.3,1,1,-5.7167,0,0,0,314.6);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(69).to({_off:false},0).to({rotation:0,alpha:1},15,cjs.Ease.get(0.5)).wait(106).to({startPosition:0},0).to({rotation:-5.7167,alpha:0},14,cjs.Ease.get(0.5)).to({_off:true},1).wait(445));

	// Txt___CBM_Global
	this.instance_7 = new lib.txtcbmglobal("synched",0);
	this.instance_7.setTransform(960,648,1,1,0,0,0,445.7,46.4);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(439).to({_off:false},0).to({y:630,alpha:1},20,cjs.Ease.get(0.5)).wait(60).to({startPosition:0},0).to({y:648,alpha:0},15).to({_off:true},1).wait(115));

	// Logo_Icon
	this.instance_8 = new lib.logoicon("synched",0);
	this.instance_8.setTransform(962.9,537.15,0.5,0.5,0,0,0,191.8,183.6);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(14).to({_off:false},0).to({regY:183.7,scaleX:1.2,scaleY:1.2,x:962.85,y:537.25,alpha:1},30,cjs.Ease.get(0.5)).to({regY:183.6,scaleX:1,scaleY:1,x:962.9,y:537.15},10,cjs.Ease.get(0.5)).to({y:697.15},40,cjs.Ease.get(0.5)).to({y:677.15},10,cjs.Ease.get(0.5)).wait(110).to({startPosition:0},0).to({y:277.15},40,cjs.Ease.get(0.5)).to({y:297.15},15).wait(170).to({startPosition:0},0).to({y:437.15},20,cjs.Ease.get(0.5)).wait(60).to({startPosition:0},0).to({y:417.15,alpha:0},15).to({_off:true},1).wait(115));

	// Logo_Icon___Light
	this.instance_9 = new lib.logoiconlight("synched",0);
	this.instance_9.setTransform(973.4,526.8,3.4696,3.4696,0,0,0,191.8,183.6);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;
	this.instance_9.filters = [new cjs.ColorFilter(0, 0, 0, 1, 183, 233, 246, 0)];
	this.instance_9.cache(87,86,204,202);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(14).to({_off:false},0).to({scaleX:4.6261,scaleY:4.6261,x:973.45,y:526.85,alpha:0.3008},30,cjs.Ease.get(1)).wait(475).to({startPosition:0},0).to({scaleX:6.9391,scaleY:6.9391,x:973.4,y:526.8,alpha:0},15).to({_off:true},1).wait(115));

	// Bg___Intro
	this.instance_10 = new lib.bgintro("synched",0);
	this.instance_10.setTransform(960,540,1,1,0,0,0,960,540);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(650));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(960,403.5,960,833.9000000000001);
// library properties:
lib.properties = {
	id: 'EA5571A2295DF7458D9934B992E3E739',
	width: 1920,
	height: 1080,
	fps: 90,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"intro/images/CachedBmp_100.png", id:"CachedBmp_100"},
		{src:"intro/images/CachedBmp_99.png", id:"CachedBmp_99"},
		{src:"intro/images/CachedBmp_98.png", id:"CachedBmp_98"},
		{src:"intro/images/CachedBmp_76.png", id:"CachedBmp_76"},
		{src:"intro/images/intro_atlas_.png", id:"intro_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EA5571A2295DF7458D9934B992E3E739'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;